/* ============================================================
 * 英语词汇通 - 核心学习逻辑
 * 功能：新学 / 复习(艾宾浩斯) / 生词本 / 统计
 * 题型：英译汉（看单词选释义）
 * 数据：localStorage 持久化，双击 index.html 即可使用
 * ============================================================ */

/* ---------------- 艾宾浩斯复习间隔(天) ----------------
 * 一个单词每复习正确一次，升一级，下一次复习间隔按此表放大。
 * 达到最高级(5)且答对 → 判定"完全记住"，移出复习循环。
 */
const INTERVALS = [1, 2, 4, 7, 15]; // 升到 stage1..5 后的间隔天数
const STAGE_MASTERED = INTERVALS.length; // 5 = 已掌握
const LEECH_THRESHOLD = 5; // 复习答错(lapse)累计到该次数 → 自动标记顽固词(Anki Leech 思路)

const STATE_KEY = 'cet4_study_state_v1';
const DAY_MS = 24 * 60 * 60 * 1000;

/* 设置缺省值(旧存档缺字段时合并;自由拼写/听写配置也存这里) */
const DEFAULT_SETTINGS = {
  dailyNew: 20, dailyReview: 30, autoSpeak: true, lib: 'cet4',
  spellScope: 'all', spellCount: 20, spellWords: [],      // 自由拼写:范围 + 数量 + 自选词单
  spellDate: '',                                          // 自由拼写:「按日期」范围选的日期(YYYY-MM-DD,空=未选)
  dictScope: 'all', dictCount: 10, dictMode: 'judge',     // 听力练习:范围 + 数量 + 听音写词的作答方式(judge判分/listen自查/auto自动轮播)
  dictDate: '',                                           // 听写:「按日期」范围选的日期
  dictWords: [],                                          // 听写自选词单
  dictKind: 'write',                                      // 听力练习类型:write 听音写词 / pick 听音辨义(两类共用范围/数量/自选词单)
  dictPause: 1, dictRate: 0.9, dictOrder: 'random', dictLoop: false,  // 轮间停顿秒/语速/顺序/循环
  quickScope: 'all', quickWords: [],                      // 快速复习/重建:范围 + 自选词单(两模式共用)
  voiceSrc: 'edge',                                       // 音源:'edge'Edge朗读(默认) / 'tts'设备TTS
  edgePack: null,                                         // Edge发音离线包元数据 {lib,voice,rate,words,ts},null=未下载(音频本体在 IndexedDB)
  ttsEngVoiceName: '', ttsZhVoiceName: '',                // 设备TTS声音(空=自动优选),音源降级时用
  edgeVoiceEn: 'en-US-AriaNeural', edgeVoiceZh: 'zh-CN-XiaoxiaoNeural',  // Edge 朗读音色(男女声自选)
  reviewAlgo: 'ebbinghaus',                               // 复习调度算法:'ebbinghaus'固定间隔 / 'fsrs'自适应
  fsrsRetention: 0.9,                                     // FSRS 目标记忆保持率(0.85/0.9/0.95)
};

/* 自定义拼写/听写/听音辨义的取词范围('custom' 为用户自选词单,取词表由 ui 层按模式提供) */
const SCOPES = [
  { key: 'all', label: '全部' },
  { key: 'unseen', label: '未学习' },
  { key: 'learning', label: '学习中' },
  { key: 'mastered', label: '已掌握' },
  { key: 'book', label: '生词本' },
  { key: 'hard', label: '顽固词' },
  { key: 'date', label: '按日期' },
];

/* ---------------- 词库注册 ----------------
 * 内置四级词库：VOCAB 定义在 vocab-data.js：[单词, 释义]
 * 扩展词库：VOCAB_LIBS 定义在 vocab-libs.js（build-libs.js 从 lib-sources/*.json 生成）
 * VOCAB_EXTRA 定义在 vocab-extra.js：{ 单词: "巧记" }（按单词查，各词库通用）
 * 巧记只覆盖四级难词，其他词库查不到会静默降级为无巧记
 */
const LIBS = Object.assign(
  { cet4: { name: '四级词汇', words: (typeof VOCAB !== 'undefined' ? VOCAB : []) } },
  (typeof VOCAB_LIBS !== 'undefined' ? VOCAB_LIBS : {})
);

/* 每个词库的单词集合（导入进度时过滤用） */
const LIB_WORD_SETS = {};
for (const k of Object.keys(LIBS)) {
  LIB_WORD_SETS[k] = new Set(LIBS[k].words.map(([w]) => w));
}

/* 每个词库的释义表（学习记录按归属词库查释义，避免跨库显示空释义） */
const LIB_DEF_MAPS = {};
for (const k of Object.keys(LIBS)) {
  LIB_DEF_MAPS[k] = new Map(LIBS[k].words);
}

/* 词库分组（设置页两级选择 UI：先选系列，再选具体词库）。
 * 只影响展示布局，词库本身互不合并；分组里没列到的词库不显示 */
const LIB_GROUPS = [
  { label: '四六级',   libs: ['cet4', 'cet6'] },
  { label: '学段词汇', libs: ['primary', 'junior', 'senior'] },
  { label: '蝶变系列', libs: ['diebian', 'diebian_junior'] },
];

/* 在指定词库里查单词释义 */
function defInLib(lib, word) {
  const m = LIB_DEF_MAPS[lib];
  return m ? (m.get(word) || '') : '';
}

/* 听写播报用的汉译:剥离全部词性标记(多词性释义如 "adv. 在下面 prep. 在..下面 n. 底部"
 * 只读中文部分,避免 TTS 读出 "adv"/"prep"/"n" */
function speakableDef(word) {
  const raw = WORD_MAP.get(word) || '';
  const def = raw
    .replace(/(adj\.|adv\.|n\.|v\.|vt\.|vi\.|prep\.|conj\.|pron\.|int\.|num\.|art\.|abbr\.)/g, '，')
    .replace(/[;；/]/g, '，')
    .replace(/\s*，\s*/g, '，')
    .replace(/，+/g, '，')
    .replace(/^，|，$/g, '')
    .trim();
  return def || raw.trim();
}

/* ---------------- Edge 朗读音源(微软,2026-08-30 方案C) ----------------
 * wss 直连 speech.platform.bing.com,作为第三音源,男女音色可自选。
 * 实测结论(2026-08-30,排查时别绕弯):
 * - Sec-MS-GEC token 必须用 float64 运算生成:ticks≈1.3e17 超出 2^53,浮点舍入后的值
 *   才是服务端期望值;用 BigInt 精确计算反而 403
 * - 服务端校验浏览器真实 User-Agent:须含 Edg/(桌面) EdgA/(安卓) EdgiOS/(iOS) 且
 *   主版本 ≥135(实测 130 被拒);UA 是浏览器自动带的、网页伪造不了,所以本音源
 *   只在 Edge 浏览器里可用,其他浏览器 isEdgeBrowser() 直接判不可用,自动回落在线真人
 * - Origin/Cookie/ConnectionId 都不校验,token 走查询参数(浏览器 WS 设不了自定义头)
 */
const EDGE_TRUSTED_TOKEN = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
const EDGE_WSS_BASE = 'wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1';

/* 从 UA 提取 Edge 版本号(如 "143.0.7204.99");非 Edge 返回空串 */
function edgeUaVersion(ua) {
  const m = /Edg(?:A|iOS)?\/([\d.]+)/.exec(ua || '');
  return m ? m[1] : '';
}

/* 是否为可用版本的 Edge 浏览器(服务端拒绝 <135 的旧版本) */
function isEdgeBrowser(ua) {
  const ver = edgeUaVersion(ua);
  const major = parseInt(ver, 10);
  return !!(ver && !isNaN(major) && major >= 135);
}

/* Sec-MS-GEC token 的时间刻度:Windows FILETIME 100ns 刻度,向下取整到 5 分钟。
 * 必须保持 float64 运算语义(见上方说明),禁止换成 BigInt 精确计算 */
function edgeGecTicks(nowMs) {
  let t = nowMs / 1000 + 11644473600;
  t -= t % 300;
  t *= 1e7;
  return BigInt(Math.round(t)).toString();
}

/* Edge TTS WebSocket 地址(token/版本走查询参数;版本号用 UA 里的真实版本,缺失时兜底) */
function edgeTtsUrl(gec, ver) {
  return EDGE_WSS_BASE
    + '?TrustedClientToken=' + EDGE_TRUSTED_TOKEN
    + '&Sec-MS-GEC=' + gec
    + '&Sec-MS-GEC-Version=1-' + (ver || '143.0.3650.75');
}

/* 语速 0.5~1.5 → SSML rate 百分比(如 0.9 → '-10%') */
function edgeRate(rate) {
  const pct = Math.round(((rate || 1) - 1) * 100);
  return (pct >= 0 ? '+' : '') + pct + '%';
}

/* SSML 报文(text 做 XML 转义) */
function edgeSsml(text, voice, rate) {
  const esc = String(text || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>"
    + "<voice name='" + voice + "'>"
    + "<prosody pitch='+0Hz' rate='" + edgeRate(rate) + "' volume='+0%'>"
    + esc
    + '</prosody></voice></speak>';
}

/* 精选音色表(ShortName 已对照官方 voices/list 校验存在,2026-08-30):
 * zh 中文名 + 性别(g) + 口音标签(tag,仅英语有);中文表顺序即下拉顺序 */
const EDGE_VOICES = [
  { id: 'zh-CN-XiaoxiaoNeural', zh: '晓晓', g: 'f' },
  { id: 'zh-CN-XiaoyiNeural',   zh: '晓伊', g: 'f' },
  { id: 'zh-CN-YunxiNeural',    zh: '云希', g: 'm' },
  { id: 'zh-CN-YunjianNeural',  zh: '云健', g: 'm' },
  { id: 'zh-CN-YunyangNeural',  zh: '云扬', g: 'm' },
  { id: 'zh-CN-YunxiaNeural',   zh: '云夏', g: 'm' },
  { id: 'en-US-AriaNeural',      zh: '艾莉雅',   g: 'f', tag: '美音' },
  { id: 'en-US-JennyNeural',     zh: '珍妮',     g: 'f', tag: '美音' },
  { id: 'en-US-MichelleNeural',  zh: '米歇尔',   g: 'f', tag: '美音' },
  { id: 'en-GB-SoniaNeural',     zh: '索尼娅',   g: 'f', tag: '英音' },
  { id: 'en-GB-LibbyNeural',     zh: '利比',     g: 'f', tag: '英音' },
  { id: 'en-US-AndrewNeural',    zh: '安德鲁',   g: 'm', tag: '美音' },
  { id: 'en-US-GuyNeural',       zh: '盖伊',     g: 'm', tag: '美音' },
  { id: 'en-US-ChristopherNeural', zh: '克里斯托弗', g: 'm', tag: '美音' },
  { id: 'en-GB-RyanNeural',      zh: '瑞安',     g: 'm', tag: '英音' },
  { id: 'en-GB-ThomasNeural',    zh: '托马斯',   g: 'm', tag: '英音' },
];

function edgeVoiceById(id) {
  return EDGE_VOICES.find(v => v.id === id) || null;
}
/* 音色缺省(设置值为空或非法时回落) */
function edgeVoiceDefault(lang) {
  return /^zh/.test(lang) ? 'zh-CN-XiaoxiaoNeural' : 'en-US-AriaNeural';
}
function edgeVoiceOf(lang) {
  const saved = /^zh/.test(lang) ? state.settings.edgeVoiceZh : state.settings.edgeVoiceEn;
  return edgeVoiceById(saved) ? saved : edgeVoiceDefault(lang);
}

/* 设备TTS声音优选(纯函数):同语言里挑高质量音色
 * 英语优先带 Natural/Enhanced/Premium/Google/Siri 标记的;中文只收 zh-CN(普通话),排除 zh-HK/zh-TW
 * 语言不匹配返回 NaN;加分后总分可为负,不能用 >=0 判语言归属 */
function pickBestTTSVoice(voices, lang) {
  const wantZh = /^zh/i.test(lang || '');
  const score = (v) => {
    const l = (v.lang || '').replace('_', '-').toLowerCase();
    let s;
    if (wantZh) {
      if (l === 'zh-cn') s = 0;
      else if (l === 'zh-hans' || l === 'zh') s = 2;
      else return NaN;
    } else {
      if (l === 'en-us') s = 0;
      else if (l.indexOf('en') === 0) s = 3;
      else return NaN;
    }
    if (/(natural|enhanced|premium|neural|google|siri)/i.test(v.name || '')) s -= 1.5;
    if (wantZh && /(普通话|mandarin|xiaoxiao|xiaoyi|yunxi)/i.test(v.name || '')) s -= 1;
    return s;
  };
  let best = null, bestS = Infinity;
  for (const v of (voices || [])) {
    const s = score(v);
    if (!isNaN(s) && s < bestS) { bestS = s; best = v; }
  }
  return best;
}

/* 常见TTS声音的中文显示名与性别对照(名称按小写匹配;顺序敏感,先具体后一般)
 * 浏览器拿不到系统音色的性别,只能按知名声音名单标注;
 * 未收录的声音返回空 zh/g,UI 显示原名并归入「其他」组 */
const VOICE_META = [
  // 中文声音(Windows 简中 / 微软自然语音 / iOS 简中)
  { re: /huihui/, zh: '晓慧', g: 'f' },
  { re: /yaoyao/, zh: '瑶瑶', g: 'f' },
  { re: /kangkang/, zh: '康康', g: 'm' },
  { re: /xiaoxiao/, zh: '晓晓', g: 'f' },
  { re: /xiaoyi/, zh: '晓伊', g: 'f' },
  { re: /yunxi/, zh: '云希', g: 'm' },
  { re: /yunyang/, zh: '云扬', g: 'm' },
  { re: /xiaoxuan/, zh: '晓萱', g: 'f' },
  { re: /yunfeng/, zh: '云枫', g: 'm' },
  // 英语及其他声音(Windows / iOS&macOS / 谷歌系)
  { re: /google uk english female/, zh: '谷歌英语·英式', g: 'f' },
  { re: /google uk english male/, zh: '谷歌英语·英式', g: 'm' },
  { re: /google us english/, zh: '谷歌英语·美式', g: 'f' },
  { re: /\bmicrosoft david|david\b/, zh: '大卫', g: 'm' },
  { re: /\bzira\b/, zh: '吉拉', g: 'f' },
  { re: /\bhazel\b/, zh: '海泽尔', g: 'f' },
  { re: /\baria\b/, zh: '艾莉雅', g: 'f' },
  { re: /\bjenny\b/, zh: '珍妮', g: 'f' },
  { re: /\bguy\b/, zh: '盖伊', g: 'm' },
  { re: /\beric\b/, zh: '埃里克', g: 'm' },
  { re: /\bryan\b/, zh: '瑞安', g: 'm' },
  { re: /\bsonia\b/, zh: '索尼娅', g: 'f' },
  { re: /\blibby\b/, zh: '利比', g: 'f' },
  { re: /\bsamantha\b/, zh: '萨曼莎', g: 'f' },
  { re: /\bting-?ting\b/, zh: '婷婷', g: 'f' },
  { re: /\bmeijia\b/, zh: '美佳', g: 'f' },
  { re: /\bsin-?ji\b/, zh: '善怡', g: 'f' },
  { re: /\bdaniel\b/, zh: '丹尼尔', g: 'm' },
  { re: /\balex\b/, zh: '亚历克斯', g: 'm' },
  { re: /\bfred\b/, zh: '弗雷德', g: 'm' },
  { re: /\baaron\b/, zh: '亚伦', g: 'm' },
  { re: /\bkaren\b/, zh: '凯伦', g: 'f' },
  { re: /\btessa\b/, zh: '特莎', g: 'f' },
  { re: /\bfiona\b/, zh: '菲奥娜', g: 'f' },
  { re: /\bmoira\b/, zh: '莫伊拉', g: 'f' },
];

/* 查声音的中文显示名与性别;未收录返回 { zh:'', g:'' } */
function voiceMeta(voice) {
  const name = ((voice && voice.name) || '').toLowerCase();
  for (const m of VOICE_META) {
    if (m.re.test(name)) return { zh: m.zh, g: m.g };
  }
  return { zh: '', g: '' };
}

let WORD_MAP = new Map();
let WORD_LIST = [];

/* 按当前词库重建 WORD_MAP / WORD_LIST（启动和切换词库时调用） */
function rebuildWordData() {
  const lib = LIBS[libKey()];
  WORD_MAP = new Map();
  WORD_LIST = lib.words.map(([w, m]) => { WORD_MAP.set(w, m); return w; });
}

const EXTRA_MAP = new Map(typeof VOCAB_EXTRA !== 'undefined' ? Object.entries(VOCAB_EXTRA) : []);

/* 巧记查询：无数据的词（简单词）返回空串 */
function memoOf(word) {
  const m = EXTRA_MAP.get(word);
  return (typeof m === 'string' && m.trim()) ? m.trim() : '';
}

/* ---------------- 全局状态 ----------------
 * 学习进度按词库隔离：state.libs[libKey].words[word] = {
 *   stage: 0新词, 1-5复习级, 5已掌握
 *   due:   下次复习时间戳(仅 stage>=1 使用)
 *   right: 累计答对
 *   wrong: 累计答错
 *   inBook: 是否在生词本
 *   created: 首次学习时间戳
 * }
 * 学习进度与每日计数（今日已学/今日已复习）按词库隔离；学习记录(history)是全局的，条目带词库归属
 */
const defaultState = () => ({
  settings: Object.assign({}, DEFAULT_SETTINGS),
  libs: {},      // libs[libKey] = { words: { 单词: 学习记录 }, learnedToday: [], reviewedToday: [] }
  today: todayStr(),
  history: {},   // history['YYYY-MM-DD'] = { learned:[], reviewed:[], wrongs:[] }，条目为 [词库key, 单词]
});

let state = loadState();

/* 当前词库 key（存档里没有或已失效时回落到内置四级） */
function libKey() {
  const k = state.settings && state.settings.lib;
  return (k && LIBS[k]) ? k : 'cet4';
}

/* 当前词库的学习记录表（懒创建） */
function curWords() {
  const k = libKey();
  if (!state.libs) state.libs = {};
  if (!state.libs[k]) state.libs[k] = { words: {} };
  if (!state.libs[k].words) state.libs[k].words = {};
  return state.libs[k].words;
}

/* 词库的每日计数容器（今日已学/今日已复习，按词库隔离；懒创建） */
function libDaily(k) {
  if (!state.libs) state.libs = {};
  if (!state.libs[k]) state.libs[k] = { words: {} };
  if (!Array.isArray(state.libs[k].learnedToday)) state.libs[k].learnedToday = [];
  if (!Array.isArray(state.libs[k].reviewedToday)) state.libs[k].reviewedToday = [];
  return state.libs[k];
}
const curDaily = () => libDaily(libKey());

/* 切换词库：仅切设置，进度天然隔离；调用方负责清掉进行中的会话 */
function setLibrary(key) {
  if (!LIBS[key] || key === libKey()) return;
  state.settings.lib = key;
  saveState();
  rebuildWordData();
}

function todayStr() {
  return new Date().toDateString();
}

/* 日期 key：YYYY-MM-DD（用于 history） */
function dateKey(ts) {
  const d = ts ? new Date(ts) : new Date();
  const p = n => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}

/* 当日 history 记录（懒创建） */
function todayRecord() {
  const k = dateKey();
  if (!state.history) state.history = {};
  if (!state.history[k]) state.history[k] = { learned: [], reviewed: [], wrongs: [] };
  return state.history[k];
}

/* ---------------- 学习记录（history） ----------------
 * 条目格式 [词库key, 单词]：各词库的词在记录里可区分、释义按归属词库查。
 * 旧版条目是纯字符串，渲染时用 normHistEntry 兼容归属。
 */
function histHas(list, word, lib) {
  return list.some(e => Array.isArray(e) ? (e[1] === word && e[0] === lib) : e === word);
}
function histAdd(list, word) {
  const lib = libKey();
  if (!histHas(list, word, lib)) list.push([lib, word]);
}

/* 学习记录条目规范化 → [lib, word]；无法归属返回 null */
function normHistEntry(e) {
  if (Array.isArray(e) && LIBS[e[0]] && typeof e[1] === 'string' && e[1]) return e;
  if (typeof e === 'string' && e) {
    const cur = libKey();
    if (LIB_WORD_SETS[cur] && LIB_WORD_SETS[cur].has(e)) return [cur, e];
    for (const k of Object.keys(LIB_WORD_SETS)) {
      if (LIB_WORD_SETS[k].has(e)) return [k, e];
    }
  }
  return null;
}

function recordLearned(word) {
  histAdd(todayRecord().learned, word);
  saveState();
}
function recordReviewed(word) {
  histAdd(todayRecord().reviewed, word);
  saveState();
}
function recordWrong(word) {
  histAdd(todayRecord().wrongs, word);
  saveState();
}

/* 连续学习天数(streak)：从今天往回数连续有学习活动的日子，全词库合计；
 * 今天还没学不打断(Duolingo 规则，避免晚上打开时显示已断签) */
function streakInfo() {
  const h = state.history || {};
  const hasAct = dk => {
    const r = h[dk];
    return !!(r && ((r.learned && r.learned.length) || (r.reviewed && r.reviewed.length)));
  };
  let n = 0;
  let t = Date.now();
  if (!hasAct(dateKey(t))) t -= DAY_MS;
  while (hasAct(dateKey(t))) {
    n++;
    t -= DAY_MS;
  }
  return n;
}

/* 每日计数对账：以当天 history 为权威，重建各词库的 learnedToday/reviewedToday。
 * history 条目自带词库归属，且 learnWord/reviewCorrect/reviewWrong 写计数时必同步写 history
 * （计数 ⊆ history，重建不丢数）。自愈旧版混库迁移造成的污染——2026-08-31 实测 bug：
 * 首页「新学 20/20」vs 按日期「当天新学 3 词」，根因是旧档顶层混库计数被整体迁进了 cet4 */
function reconcileDailyFromHistory(s) {
  const libs = s.libs || (s.libs = {});
  for (const k of Object.keys(libs)) {
    libs[k].learnedToday = [];
    libs[k].reviewedToday = [];
  }
  const rec = s.history && s.history[dateKey()];
  if (!rec) return;
  const fill = (list, field) => {
    for (const e of (list || [])) {
      const p = normHistEntry(e);
      if (!p) continue;
      if (!libs[p[0]]) libs[p[0]] = { words: {} };
      if (!Array.isArray(libs[p[0]][field])) libs[p[0]][field] = [];
      if (!libs[p[0]][field].includes(p[1])) libs[p[0]][field].push(p[1]);
    }
  };
  fill(rec.learned, 'learnedToday');
  fill(rec.reviewed, 'reviewedToday');
}

function loadState() {
  let raw = null;
  try { raw = localStorage.getItem(STATE_KEY); } catch (e) { /* 存储不可用 */ }
  if (!raw) return defaultState();
  let s;
  try { s = JSON.parse(raw); } catch (e) {
    // JSON 真损坏才重建;把损坏原文留一份备份,给手工抢救留余地
    try { localStorage.setItem(STATE_KEY + '_backup', raw); } catch (e2) { /* 忽略 */ }
    return defaultState();
  }
  if (!s || typeof s !== 'object' || Array.isArray(s)) return defaultState();
  // 迁移失败时保留原始数据——绝不能用空档覆盖用户进度!
  // (2026-10-02 教训:迁移代码曾引用文件后段才初始化的 const,老用户冷启动触发 TDZ 异常,
  //  旧写法整体 catch 后回退 defaultState,表现为"学习进度被清空")
  try {
    // 跨天重置当日计数（所有词库一起清——各库共用同一个日历日）
    if (s.today !== todayStr()) {
      s.today = todayStr();
      s.learnedToday = [];
      s.reviewedToday = [];
      for (const k of Object.keys(s.libs || {})) {
        if (s.libs[k] && Array.isArray(s.libs[k].learnedToday)) s.libs[k].learnedToday = [];
        if (s.libs[k] && Array.isArray(s.libs[k].reviewedToday)) s.libs[k].reviewedToday = [];
      }
    }
    // 设置项缺省合并（旧存档没有 autoSpeak/lib 及自由拼写/听写配置等新字段）
    const hadDictMode = s.settings && s.settings.dictMode != null;
    const legacyJudge = s.settings ? s.settings.dictJudge : undefined;
    const hadVoiceSrc = s.settings && s.settings.voiceSrc != null;
    const legacyOnlineVoice = s.settings ? s.settings.onlineVoice : undefined;
    s.settings = Object.assign({}, DEFAULT_SETTINGS, s.settings);
    if (!LIBS[s.settings.lib]) s.settings.lib = 'cet4';
    // 旧存档只有 dictJudge(bool):迁移为 dictMode 三态(judge/listen/auto)
    if (!hadDictMode || !['judge', 'listen', 'auto'].includes(s.settings.dictMode)) {
      s.settings.dictMode = legacyJudge === false ? 'listen' : 'judge';
    }
    // 旧存档 onlineVoice(bool)/voiceSrc 三态 → voiceSrc 二态(edge/tts,在线真人已移除)
    if (!hadVoiceSrc) s.settings.voiceSrc = legacyOnlineVoice === false ? 'tts' : 'edge';
    delete s.settings.onlineVoice;
    delete s.settings.audioAcc;
    // 听音辨义并入听力练习(dictKind),独立 listen* 配置字段废弃(两类共用 dict*)
    delete s.settings.listenScope;
    delete s.settings.listenCount;
    delete s.settings.listenWords;
    delete s.settings.listenDate;
    if (!['edge', 'tts'].includes(s.settings.voiceSrc)) s.settings.voiceSrc = 'edge';
    // 复习算法与 FSRS 保持率缺省校验
    if (!['ebbinghaus', 'fsrs'].includes(s.settings.reviewAlgo)) s.settings.reviewAlgo = 'ebbinghaus';
    if (![0.85, 0.9, 0.95].includes(s.settings.fsrsRetention)) s.settings.fsrsRetention = 0.9;
    // 按日期的内容分类(拼写/听力各自记忆,非法值回落'全部')。
    // 注意:这里必须用字面量数组,不能引用文件后段(line ~770)的 DATE_CATS——
    // 冷启动时它还没初始化,引用即 TDZ 异常,而本函数在带存档时必然执行
    const DATE_CAT_KEYS = ['all', 'learn', 'review', 'wrong'];
    s.settings.spellDateCat = DATE_CAT_KEYS.includes(s.settings.spellDateCat) ? s.settings.spellDateCat : 'all';
    s.settings.dictDateCat = DATE_CAT_KEYS.includes(s.settings.dictDateCat) ? s.settings.dictDateCat : 'all';
      if (!Array.isArray(s.settings.spellWords)) s.settings.spellWords = [];
      if (!Array.isArray(s.settings.dictWords)) s.settings.dictWords = [];
      if (!Array.isArray(s.settings.quickWords)) s.settings.quickWords = [];
    // 旧版存档迁移：state.words（单一词库）→ state.libs.cet4.words（按词库隔离）
    if (s.words && !s.libs) {
      s.libs = { cet4: { words: s.words } };
      delete s.words;
    }
    if (!s.libs) s.libs = {};
    // 旧档顶层每日计数（各词库混在一起）直接废弃：每日计数一律按当天 history 重建
    // （history 条目自带词库归属，是权威数据源，见 reconcileDailyFromHistory）
    delete s.learnedToday;
    delete s.reviewedToday;
    reconcileDailyFromHistory(s);
  } catch (e) { /* 迁移失败:保留原始数据继续,宁可带病运行也不清档 */ }
  return s;
}

function saveState() {
  try {
    localStorage.setItem(STATE_KEY, JSON.stringify(state));
  } catch (e) { /* 存储满/不可用，忽略 */ }
}

/* ---------------- 进度导出 / 导入（跨设备同步） ---------------- */
const EXPORT_VERSION = 2;

function exportProgress() {
  const data = { app: 'cet4-vocab', version: EXPORT_VERSION, exportedAt: Date.now(), state: state };
  return JSON.stringify(data);
}

function wordInAnyLib(w) {
  return Object.keys(LIB_WORD_SETS).some(k => LIB_WORD_SETS[k].has(w));
}

/* 导入文件的单词记录消毒:只接受预期字段和类型,防止恶意文件注入异常数据 */
function sanitizeWordRecord(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) return null;
  const num = (v) => (typeof v === 'number' && isFinite(v) ? v : 0);
  const stage = Math.max(0, Math.min(STAGE_MASTERED, Math.floor(num(r.stage))));
  const out = {
    stage,
    // 已掌握词 due 恒为 Infinity(JSON 序列化成 null),其余用数值
    due: stage >= STAGE_MASTERED ? Infinity : num(r.due),
    right: num(r.right),
    wrong: num(r.wrong),
    inBook: r.inBook === true,
    created: num(r.created) || Date.now(),
    // 顽固词字段(可选,旧档/导入缺省即无标记)
    lapses: num(r.lapses),
    leech: r.leech === true,
  };
  // FSRS 记忆状态(可选,s 为正数、d 为数值才保留,防止导入档注入畸形状态)
  const fs = r.fsrs;
  if (fs && typeof fs === 'object' && !Array.isArray(fs)
      && typeof fs.s === 'number' && isFinite(fs.s) && fs.s > 0
      && typeof fs.d === 'number' && isFinite(fs.d)) {
    out.fsrs = { s: fs.s, d: fs.d, last: num(fs.last), due: num(fs.due) };
  }
  return out;
}

// 合并导入的数据；返回本次实际导入的单词数
// v2 存档按词库合并；v1 旧档（扁平 state.words）当作四级词库处理
function importProgress(json) {
  let data;
  try { data = JSON.parse(json); } catch (e) { throw new Error('文件内容不是有效的 JSON'); }
  if (!data || data.app !== 'cet4-vocab' || !data.state) throw new Error('这不是英语词汇通的进度文件');
  const incoming = data.state;
  const incLibs = incoming.libs || { cet4: { words: incoming.words || {} } };

  // 逐词库逐词合并：目标设备没有记录才写入
  let importedCount = 0;
  if (!state.libs) state.libs = {};
  for (const k of Object.keys(incLibs)) {
    if (!LIBS[k]) continue;   // 本地没有这个词库（版本过旧），跳过
    const incWords = incLibs[k].words || {};
    if (typeof incWords !== 'object') continue;
    if (!state.libs[k]) state.libs[k] = { words: {} };
    if (!state.libs[k].words) state.libs[k].words = {};
    const localWords = state.libs[k].words;
    for (const w of Object.keys(incWords)) {
      if (!LIB_WORD_SETS[k].has(w)) continue;   // 过滤该词库不存在的词
      if (localWords[w]) continue;              // 本地已有 → 不覆盖
      const rec = sanitizeWordRecord(incWords[w]);
      if (!rec) continue;                       // 记录形状不对 → 丢弃
      localWords[w] = rec;
      importedCount++;
    }
  }
  // 合并设置：保留两者较大值，避免覆盖用户已调好的计划；词库选择以本地为准
  if (incoming.settings) {
    state.settings = {
      dailyNew: Math.max(state.settings.dailyNew, incoming.settings.dailyNew || 0),
      dailyReview: Math.max(state.settings.dailyReview, incoming.settings.dailyReview || 0),
      autoSpeak: state.settings.autoSpeak,
      lib: libKey(),
    };
  }
  // 合并历史记录
  if (incoming.history) {
    if (!state.history) state.history = {};
    for (const day of Object.keys(incoming.history)) {
      if (!state.history[day]) state.history[day] = { learned: [], reviewed: [], wrongs: [] };
      for (const cat of ['learned', 'reviewed', 'wrongs']) {
        const list = incoming.history[day][cat] || [];
        for (const e of list) {
          // 条目兼容两种格式:[词库key, 单词] / 旧版纯字符串;拒绝超长垃圾项
          const isPair = Array.isArray(e);
          const w = isPair ? e[1] : e;
          const lib = isPair ? e[0] : null;
          if (typeof w !== 'string' || w.length > 64) continue;
          if (isPair && (!LIBS[lib] || !LIB_WORD_SETS[lib].has(w))) continue;
          if (!wordInAnyLib(w)) continue;
          if (!state.history[day][cat].some(x => Array.isArray(x) ? x[1] === w : x === w)) {
            state.history[day][cat].push(isPair ? e : w);
          }
        }
      }
    }
  }
  saveState();
  return importedCount;
}

/* ---------------- 工具函数 ---------------- */
function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function todayStart() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

function pickRandom(arr, n) {
  return shuffle(arr).slice(0, n);
}

function daysBetween(fromTs, toTs) {
  return Math.floor((toTs - fromTs) / DAY_MS);
}

/* ---------------- 词汇池 ---------------- */
function unseenWords() {
  return WORD_LIST.filter(w => !curWords()[w] || curWords()[w].stage === 0);
}

/* ---------------- FSRS 自适应复习 ----------------
 * 开关 settings.reviewAlgo='fsrs' 时调度交给 fsrs.js(记忆模型 S/D/R)，
 * stage 仍按经典规则升降，只作为「掌握判定/进度展示」；到期时间由 FSRS 给出。
 * 旧进度不批量迁移：首次在 FSRS 下复习到某词时惰性换算(migrateFsrs)。
 */
function useFsrs() {
  return state.settings.reviewAlgo === 'fsrs';
}

/* 生效的下次复习时间：FSRS 模式且已有 fsrs 状态用 fsrs.due，否则用经典 r.due */
function effectiveDue(r) {
  if (useFsrs() && r.fsrs && isFinite(r.fsrs.due)) return r.fsrs.due;
  return r.due;
}

/* 经典进度 → FSRS 初值(粗略换算，复习一次后即被真实模型接管)：
 * 稳定性取当前间隔天数，难度按答对/答错比例估计，last 假定为完整间隔前(到期才来复习) */
function migrateFsrs(r) {
  const stage = Math.min(Math.max(r.stage || 1, 1), STAGE_MASTERED - 1);
  const s = Math.max(0.1, INTERVALS[stage - 1]);
  const d = Math.min(10, Math.max(1, 5 + (r.wrong || 0) * 1.2 - (r.right || 0) * 0.4));
  return { s, d, last: Date.now() - INTERVALS[stage - 1] * DAY_MS, due: Date.now() };
}

/* FSRS 模式下一次复习(答对 rating=3 / 答错 rating=1)后的状态与到期时间 */
function fsrsApply(r, rating, now) {
  const f = r.fsrs || migrateFsrs(r);
  const nf = fsrsReview(f, rating, f.last, now);
  nf.last = now;
  nf.due = now + fsrsInterval(nf.s, state.settings.fsrsRetention) * DAY_MS;
  r.fsrs = nf;
  return nf;
}

function dueWords() {
  const now = Date.now();
  return WORD_LIST.filter(w => {
    const r = curWords()[w];
    return r && r.stage >= 1 && r.stage < STAGE_MASTERED && effectiveDue(r) <= now;
  });
}

function bookWords() {
  return WORD_LIST.filter(w => curWords()[w] && curWords()[w].inBook);
}

function masteredWords() {
  return WORD_LIST.filter(w => {
    const r = curWords()[w];
    return r && r.stage >= STAGE_MASTERED;
  });
}

/* 学习中：已学过、未掌握（stage 1-4，含待复习） */
function learningWords() {
  return WORD_LIST.filter(w => {
    const r = curWords()[w];
    return r && r.stage >= 1 && r.stage < STAGE_MASTERED;
  });
}

/* 顽固词：复习答错累计达 LEECH_THRESHOLD 自动标记(重置单词即清除) */
function leechWords() {
  return WORD_LIST.filter(w => {
    const r = curWords()[w];
    return r && r.leech;
  });
}

/* 分类：unlearned / learning / due / mastered / leech */
function wordsByClass(cls) {
  if (cls === 'unlearned') return unseenWords();
  if (cls === 'mastered') return masteredWords();
  if (cls === 'due') return dueWords();
  if (cls === 'leech') return leechWords();
  return learningWords();
}

/* 自由拼写/听写的取词范围('custom' 为用户自选词单,取词表由 ui 层按模式提供) */
function normScope(v) {
  return (v === 'custom' || SCOPES.some(s => s.key === v)) ? v : 'all';
}

/* 指定日期的学习活动统计（当前词库）：新学/复习/答错各多少。
 * history 条目为 [词库key, 单词]，兼容旧版纯字符串条目（按词库归属） */
function dayTouchCounts(dk) {
  const rec = state.history && state.history[dk];
  const cnt = (list) => {
    let n = 0;
    for (const e of (list || [])) {
      const pair = normHistEntry(e);
      if (pair && pair[0] === libKey()) n++;
    }
    return n;
  };
  return {
    learned: rec ? cnt(rec.learned) : 0,
    reviewed: rec ? cnt(rec.reviewed) : 0,
    wrongs: rec ? cnt(rec.wrongs) : 0,
  };
}

/* 指定日期「接触过」的单词（当前词库）。cat 缺省/all=新学+复习+答错合并去重;
 * 也可单取一类:learn=新学 / review=复习 / wrong=答错 */
function wordsTouchedOn(dk, cat) {
  const rec = state.history && state.history[dk];
  if (!rec) return [];
  const cats = cat === 'learn' ? ['learned']
    : cat === 'review' ? ['reviewed']
    : cat === 'wrong' ? ['wrongs']
    : ['learned', 'reviewed', 'wrongs'];
  const set = LIB_WORD_SETS[libKey()];
  const out = [];
  for (const c of cats) {
    for (const e of (rec[c] || [])) {
      const pair = normHistEntry(e);
      if (pair && pair[0] === libKey() && set.has(pair[1]) && !out.includes(pair[1])) out.push(pair[1]);
    }
  }
  return out;
}

/* scope='date' 时按模式读各自选的日期（spellDate/dictDate）与当天内容分类（spellDateCat/dictDateCat） */
function practiceDateOf(kind) {
  return state.settings[(kind || 'spell') + 'Date'] || '';
}

/* 按日期范围的当天内容分类:all全部(默认)/learn新学/review复习/wrong答错 */
const DATE_CATS = [
  { key: 'all', label: '全部' },
  { key: 'learn', label: '新学' },
  { key: 'review', label: '复习' },
  { key: 'wrong', label: '答错' },
];
function normDateCat(v) {
  return DATE_CATS.some(c => c.key === v) ? v : 'all';
}
function practiceDateCatOf(kind) {
  return normDateCat(state.settings[(kind || 'spell') + 'DateCat']);
}

function wordsInScope(scope, kind) {
  if (scope === 'unseen') return unseenWords();
  if (scope === 'learning') return learningWords();
  if (scope === 'mastered') return masteredWords();
  if (scope === 'book') return bookWords();
  if (scope === 'hard') return leechWords();
  if (scope === 'date') return wordsTouchedOn(practiceDateOf(kind), practiceDateCatOf(kind));
  return WORD_LIST.slice();
}

function classCount(cls) {
  return wordsByClass(cls).length;
}

/* 单个单词的掌握状态描述 */
function wordStatus(word) {
  const r = curWords()[word];
  if (!r || r.stage === 0) {
    return { cls: 'unlearned', label: '未学习', stage: 0, right: 0, wrong: 0, due: null };
  }
  if (r.stage >= STAGE_MASTERED) {
    return { cls: 'mastered', label: '已掌握', stage: r.stage, right: r.right, wrong: r.wrong, due: null };
  }
  const dueNow = effectiveDue(r) <= Date.now();
  return {
    cls: dueNow ? 'due' : 'learning',
    label: dueNow ? '待复习' : '学习中',
    stage: r.stage,
    right: r.right,
    wrong: r.wrong,
    due: r.due,
  };
}

/* 重置单个单词：删除记录，回到未学习 */
function resetWord(word) {
  delete curWords()[word];
  saveState();
}

/* 重置某分类全部单词 */
function resetWordsByClass(cls) {
  const list = wordsByClass(cls);
  for (const w of list) delete curWords()[w];
  saveState();
}

/* ---------------- 状态变更 ---------------- */

// 学习新词：识别阶段答对达标后记为已学
function learnWord(word) {
  let r = curWords()[word] || { stage: 0, right: 0, wrong: 0, inBook: false, created: Date.now() };
  if (!r.created) r.created = Date.now();
  r.right++;
  r.stage = 1;
  r.due = Date.now() + INTERVALS[0] * DAY_MS;
  if (useFsrs()) {
    // FSRS：首学按 Good 评级初始化记忆状态，间隔由保持率推出(替代经典 1 天)
    const f = fsrsInit(3);
    f.last = Date.now();
    f.due = f.last + fsrsInterval(f.s, state.settings.fsrsRetention) * DAY_MS;
    r.fsrs = f;
    r.due = f.due;
  }
  curWords()[word] = r;
  const L = curDaily();
  if (!L.learnedToday.includes(word)) L.learnedToday.push(word);
  recordLearned(word);
  saveState();
}

// 复习答对：经典=艾宾浩斯升级 / FSRS=更新记忆状态并按模型排期
function reviewCorrect(word) {
  const r = curWords()[word] || { stage: 0, right: 0, wrong: 0, inBook: false, created: Date.now() };
  r.right++;
  if (r.stage < STAGE_MASTERED) r.stage++;
  if (r.stage >= STAGE_MASTERED) {
    // 完全记住，移出复习循环
    r.due = Infinity;
  } else {
    r.due = Date.now() + INTERVALS[r.stage - 1] * DAY_MS;
    if (useFsrs()) r.due = fsrsApply(r, 3, Date.now()).due;
  }
  curWords()[word] = r;
  const L = curDaily();
  if (!L.reviewedToday.includes(word)) L.reviewedToday.push(word);
  recordReviewed(word);
  saveState();
}

// 复习答错：降级；addBook 决定是否进生词本
function reviewWrong(word, addBook) {
  const r = curWords()[word] || { stage: 1, right: 0, wrong: 0, inBook: false, created: Date.now() };
  r.wrong++;
  // 最低降到 1 级：stage 0 会被 dueWords 排除，导致「10 分钟后再复习」永远不出现
  r.stage = Math.max(1, r.stage - 2);
  r.due = Date.now() + 10 * 60 * 1000; // 10 分钟后重试
  if (useFsrs()) {
    // FSRS：答错更新记忆状态；到期仍是 10 分钟后当天重试(同日走短评公式)
    const nf = fsrsApply(r, 1, Date.now());
    nf.due = r.due;
  }
  if (addBook !== false) r.inBook = true;
  // 顽固词计数：只统计复习答错(lapse)，拼写/识别答错不污染(拼写是纯练习不写状态)
  r.lapses = (r.lapses || 0) + 1;
  if (r.lapses >= LEECH_THRESHOLD) r.leech = true;
  curWords()[word] = r;
  const L = curDaily();
  if (!L.reviewedToday.includes(word)) L.reviewedToday.push(word);
  recordReviewed(word);
  recordWrong(word);
  saveState();
}

function toggleBook(word) {
  const r = curWords()[word] || { stage: 0, right: 0, wrong: 0, inBook: false, created: Date.now() };
  r.inBook = !r.inBook;
  curWords()[word] = r;
  saveState();
}

// 会话中答错：累计错误次数，addBook 决定是否加入生词本
function noteWrong(word, addBook) {
  let r = curWords()[word] || { stage: 0, right: 0, wrong: 0, inBook: false, created: Date.now() };
  r.wrong++;
  if (addBook) r.inBook = true;
  curWords()[word] = r;
  recordWrong(word);
  saveState();
}

/* 进度快速重建(清档补救):对没有记录的词快速重标——认识按第2级排期,不认识明天再来。
 * 不动每日目标/学习记录 history,纯重建调度数据 */
function quickMark(word, known) {
  let r = curWords()[word] || { stage: 0, right: 0, wrong: 0, inBook: false, created: Date.now() };
  if (!r.created) r.created = Date.now();
  r.right++;
  if (useFsrs()) {
    const f = fsrsInit(known ? 3 : 1);
    f.last = Date.now();
    f.due = f.last + fsrsInterval(f.s, state.settings.fsrsRetention) * DAY_MS;
    r.fsrs = f;
    r.due = f.due;
  } else {
    r.due = Date.now() + (known ? INTERVALS[1] : 1) * DAY_MS;
  }
  r.stage = known ? 2 : 1;
  curWords()[word] = r;
  saveState();
}

/* ---------------- 出题 ----------------
 * 英译汉：看单词选释义
 * 汉译英：看释义选单词（复习模式增强提取练习）
 */

/* 从释义提取词性标记，如 "adj." / "n." / "v." */
function posOf(def) {
  const m = /^(adj\.|adv\.|n\.|v\.|vt\.|vi\.|prep\.|conj\.|pron\.|int\.|num\.|art\.|abbr\.)/.exec(def || '');
  return m ? m[1] : '';
}

/* 抽优质干扰项：优先同词性、词长相近；排除与答案同释义的词，
 * 且干扰项之间释义也互不相同（74 组同释义词，两个同义干扰项会出重复选项） */
function pickDistractors(word, n) {
  const answerDef = WORD_MAP.get(word);
  const pool = WORD_LIST.filter(w => w !== word && WORD_MAP.get(w) !== answerDef);
  const myPos = posOf(answerDef);
  const myLen = word.length;
  const samePos = shuffle(pool.filter(w => posOf(WORD_MAP.get(w)) === myPos))
    .sort((a, b) => Math.abs(a.length - myLen) - Math.abs(b.length - myLen));
  const rest = shuffle(pool.filter(w => posOf(WORD_MAP.get(w)) !== myPos));
  const candidates = samePos.concat(rest);
  const picked = [];
  const usedDefs = new Set([answerDef]);
  for (const w of candidates) {
    const d = WORD_MAP.get(w);
    if (usedDefs.has(d)) continue;
    usedDefs.add(d);
    picked.push(w);
    if (picked.length >= n) break;
  }
  return picked;
}

/* 释义反查单词（答错提示/错误选项点看用）：优先跳过 excludeWord，避免同释义提示自己 */
function reverseDefToWord(def, excludeWord) {
  let found = null;
  for (const [w, d] of WORD_MAP) {
    if (d === def && w !== excludeWord) { found = w; break; }
  }
  if (!found) {
    for (const [w, d] of WORD_MAP) {
      if (d === def) { found = w; break; }
    }
  }
  return found;
}

function makeQuestion(word, reverse) {
  const answerDef = WORD_MAP.get(word);
  const distractorWords = pickDistractors(word, 3);
  if (reverse) {
    // 汉译英：看释义选单词（干扰项是英文单词）
    const texts = [word, ...distractorWords];
    return {
      type: '汉译英',
      prompt: answerDef,
      answer: word,
      speakWord: word,
      options: shuffle(texts.map(t => ({ text: t, isAnswer: t === word }))),
    };
  }
  // 英译汉：看单词选释义（干扰项是中文释义）
  const texts = [answerDef, ...distractorWords.map(w => WORD_MAP.get(w))];
  return {
    type: '英译汉',
    prompt: word,
    answer: answerDef,
    speakWord: word,
    options: shuffle(texts.map(t => ({ text: t, isAnswer: t === answerDef }))),
  };
}

/* ---------------- 统计 ---------------- */
function stats() {
  const total = WORD_LIST.length;
  const seen = Object.keys(curWords()).length;
  const mastered = masteredWords().length;
  const inBook = bookWords().length;
  const due = dueWords().length;
  const unseen = total - seen;
  const L = curDaily();
  return { total, seen, mastered, inBook, due, unseen, learning: classCount('learning'), learnedToday: L.learnedToday.length, reviewedToday: L.reviewedToday.length };
}

/* ---------------- 每日目标 ----------------
 * 每日新学/复习的计数与目标达成判定都按当前词库独立：
 * 四级学满不影响其他词库，切换后各算各的（目标数值仍是全局一份设置）
 */
function goalInfo() {
  const target = state.settings.dailyNew;
  const L = curDaily();
  const learned = L.learnedToday.length;
  const dueToday = dueWords().length;
  const allDone = learned >= target && unseenWords().length === 0;
  return {
    target,
    learned,
    remaining: Math.max(0, target - learned),
    done: learned >= target,
    allDone,
    dueToday,
    reviewedToday: L.reviewedToday.length,
  };
}

/* ---------------- 启动 ---------------- */
/* 按存档里的词库设置初始化词表（ui.js 加载后 refreshHome 依赖 WORD_LIST） */
rebuildWordData();
