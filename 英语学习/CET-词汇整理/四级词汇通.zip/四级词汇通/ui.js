/* ============================================================
 * 英语词汇通 - 界面交互层
 * 依赖：app.js（逻辑）+ vocab-data.js（数据）
 * ============================================================ */

/* ---------------- 导航与页面切换 ---------------- */
const SCREEN_TITLES = {
  'screen-home': '学习',
  'screen-study': '学习新词',
  'screen-review': '复习单词',
  'screen-spell': '自由拼写',
  'screen-quick': '快速复习',
  'screen-dictate': '听力练习',
  'screen-vocab': '词汇',
  'screen-dict': '词典',
  'screen-settings': '设置',
};
/* 有底部导航的页面;答题会话页隐藏底栏,沉浸作答 */
const TAB_SCREENS = ['screen-home', 'screen-vocab', 'screen-dict', 'screen-settings'];

function go(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  const t = SCREEN_TITLES[id] || '';
  document.getElementById('topTitle').textContent = t;
  const tabbed = TAB_SCREENS.includes(id);
  const tabbar = document.getElementById('tabbar');
  if (tabbar) tabbar.style.display = tabbed ? 'flex' : 'none';
  document.getElementById('topBack').style.display = tabbed ? 'none' : 'inline';
  // 离开拼写/听力页时选词器必然已关闭(防状态残留导致返回箭头误判层级)
  if (id !== 'screen-spell' && id !== 'screen-dictate') pickerOpen = false;
  document.querySelectorAll('#tabbar button').forEach(b => b.classList.toggle('active', b.dataset.tab === id));
  // 学习页顶栏右侧显示当前词库名
  document.getElementById('topSub').textContent = (id === 'screen-home') ? LIBS[libKey()].name : '';
  // 离开听写页时停止播报
  if (id !== 'screen-dictate') stopDictPlayback();
  if (id === 'screen-home') refreshHome();
  if (id === 'screen-vocab') renderVocab();
  if (id === 'screen-settings') refreshSettings();
  if (id === 'screen-spell') renderSpellConfig();
  if (id === 'screen-quick') renderQuickConfig();
  if (id === 'screen-dictate') renderDictConfig();
}

function goHome() { go('screen-home'); }

/* ---------------- 首页（学习 Tab） ---------------- */
function refreshHome() {
  const s = stats();
  document.getElementById('statTotal').textContent = s.total;
  document.getElementById('statMastered').textContent = s.mastered;
  document.getElementById('statDue').textContent = s.due;
  document.getElementById('statUnseen').textContent = s.unseen;
  document.getElementById('badgeNew').textContent = Math.min(s.unseen, state.settings.dailyNew);
  document.getElementById('badgeReview').textContent = s.due;
  // tab 徽章:待复习数 / 生词本数
  setTabBadge('tabBadgeStudy', s.due);
  setTabBadge('tabBadgeBook', s.inBook);
  // 听力练习(听写+听音辨义)依赖发音能力:Edge朗读/在线音源(音频元素)/系统 TTS 任一即可;微信/QQ 内置等无 TTS 仍可用在线音源
  const dictEntry = document.getElementById('dictationEntry');
  if (dictEntry) dictEntry.style.display = canSpeakHere() ? 'flex' : 'none';
  renderLibPicker();
  renderGoalCard();
}

function setTabBadge(id, n) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = n > 0 ? (n > 99 ? '99+' : n) : '';
  el.style.display = n > 0 ? 'block' : 'none';
}

function renderGoalCard() {
  const g = goalInfo();
  const d = new Date();
  document.getElementById('goalDate').textContent = `${d.getMonth() + 1}月${d.getDate()}日`;
  const newNum = document.getElementById('goalNewNum');
  const newBar = document.getElementById('goalNewBar');
  const newStatus = document.getElementById('goalNewStatus');
  newNum.textContent = `${Math.min(g.learned, g.target)}/${g.target}`;
  const pct = Math.min(100, (g.learned / g.target) * 100);
  newBar.style.width = pct + '%';
  if (g.allDone) {
    newStatus.textContent = '全部学完';
    newStatus.className = 'goal-status done';
  } else if (g.done) {
    newStatus.textContent = '已完成 ✓';
    newStatus.className = 'goal-status done';
  } else {
    newStatus.textContent = `还差 ${g.remaining} 个`;
    newStatus.className = 'goal-status';
  }
  const revNum = document.getElementById('goalReviewNum');
  const revStatus = document.getElementById('goalReviewStatus');
  const revBar = document.getElementById('goalReviewBar');
  revNum.textContent = `${g.dueToday} 词`;
  if (revBar) {
    // 复习目标进度：今日已复习 / 每日复习计划
    const revPct = Math.min(100, (g.reviewedToday / Math.max(1, state.settings.dailyReview)) * 100);
    revBar.style.width = revPct + '%';
  }
  if (g.reviewedToday >= state.settings.dailyReview) {
    revStatus.textContent = '复习目标达成 ✓';
    revStatus.className = 'goal-status done';
  } else if (g.dueToday > 0) {
    revStatus.textContent = `有到期复习 · 已复习 ${g.reviewedToday}/${state.settings.dailyReview}`;
    revStatus.className = 'goal-status';
  } else {
    revStatus.textContent = g.reviewedToday > 0
      ? `今日已复习 ${g.reviewedToday} 词`
      : '今日无待复习';
    revStatus.className = 'goal-status';
  }
}

/* 未完成会话不再弹首页横幅提示:快照静默保留当天,跨天自动失效(loadSessionSnapshot 里重置) */

/* ---------------- 设置 ---------------- */
function refreshSettings() {
  document.getElementById('setNew').textContent = state.settings.dailyNew;
  document.getElementById('setReview').textContent = state.settings.dailyReview;
  const speakBtn = document.getElementById('setSpeak');
  if (speakBtn) speakBtn.textContent = !canSpeakHere() ? '不支持' : (state.settings.autoSpeak ? '开' : '关');
  renderAlgoSettings();
  renderVoiceSettings();
  renderLibPicker();
  renderDiag();
  renderQuickEntry();
}

/* 快速重建入口的剩余词数 */
function renderQuickEntry() {
  const el = document.getElementById('quickEntryCount');
  if (el) el.textContent = quickRemaining();
}

/* 复习算法卡片:算法高亮 + 说明文案 + FSRS 保持率行显隐 */
function renderAlgoSettings() {
  const fsrs = state.settings.reviewAlgo === 'fsrs';
  document.querySelectorAll('#algoChips button[data-algo]').forEach(b => {
    b.classList.toggle('active', b.dataset.algo === state.settings.reviewAlgo);
  });
  const note = document.getElementById('algoNote');
  if (note) {
    note.textContent = fsrs
      ? '按每个词的记忆强度自动安排：记得牢的词间隔拉长，容易忘的词早点回来，总复习量更少；切回经典间隔随时恢复原节奏。'
      : '固定节奏：答对按 1/2/4/7/15 天逐级拉长，答错降级重学。';
  }
  const row = document.getElementById('fsrsRetentionRow');
  if (row) row.style.display = fsrs ? '' : 'none';
  const ret = state.settings.fsrsRetention;
  document.querySelectorAll('#retentionChips button[data-ret]').forEach(b => {
    b.classList.toggle('active', parseFloat(b.dataset.ret) === ret);
  });
}

function setReviewAlgo(v) {
  if (!['ebbinghaus', 'fsrs'].includes(v)) return;
  state.settings.reviewAlgo = v;
  saveState();
  refreshSettings();
  refreshHome();   // 到期队列随算法立即变化
}

function setFsrsRetention(v) {
  if (![0.85, 0.9, 0.95].includes(v)) return;
  state.settings.fsrsRetention = v;
  saveState();
  refreshSettings();
}

/* ---------------- 发音设置（音源/试听/Edge音色/设备TTS声音选择器） ---------------- */
function renderVoiceSettings() {
  const src = state.settings.voiceSrc === 'tts' ? 'tts' : 'edge';
  const edgeOk = edgeTtsAvailable();
  const chips = document.getElementById('voiceSrcChips');
  if (chips) {
    chips.querySelectorAll('button[data-src]').forEach(b => {
      const v = b.dataset.src;
      b.style.display = (v === 'edge' && !edgeOk) ? 'none' : '';
      // 存档里选过 Edge 但当前浏览器不可用:高亮「设备TTS」并说明
      b.classList.toggle('active', v === src || (v === 'tts' && src === 'edge' && !edgeOk));
    });
  }
  const note = document.getElementById('voiceSrcNote');
  if (note) {
    note.textContent = src === 'tts'
      ? '仅使用设备语音，由下方两个声音下拉决定（设备没装语音包时可能无声）。'
      : edgeOk
        ? '微软 Edge 朗读引擎，英语/普通话音色可自选男女声（下方音色下拉）；合成过的词永久缓存（IndexedDB），学习/听写时自动预取后面的词，第一次听也不等网络；失败自动切设备语音。'
        : '当前浏览器不是 Edge（或版本过旧），Edge 朗读不可用，已自动使用设备语音。';
  }
  // Edge 音色行:仅 Edge 音源显示
  document.querySelectorAll('.edge-voice-row').forEach(r => { r.style.display = src === 'edge' ? '' : 'none'; });
  fillEdgeVoiceSelect('setEdgeVoiceEn', 'en', state.settings.edgeVoiceEn);
  fillEdgeVoiceSelect('setEdgeVoiceZh', 'zh', state.settings.edgeVoiceZh);
  fillTTSVoiceSelect('setTtsEngVoice', 'en-US', state.settings.ttsEngVoiceName);
  fillTTSVoiceSelect('setTtsZhVoice', 'zh-CN', state.settings.ttsZhVoiceName);
  updateEdgePackUI();
}

/* Edge 朗读音色下拉:按女声/男声分组,显示中文名+性别+口音 */
function fillEdgeVoiceSelect(id, lang, sel) {
  const el = document.getElementById(id);
  if (!el) return;
  const wantZh = lang === 'zh';
  const groups = { f: [], m: [] };
  for (const v of EDGE_VOICES) {
    if (wantZh !== /^zh/.test(v.id)) continue;
    const label = escapeHtml(v.zh) + '（' + (v.g === 'f' ? '女' : '男') + (v.tag ? ' · ' + v.tag : '') + '）';
    groups[v.g].push(`<option value="${v.id}"${sel === v.id ? ' selected' : ''}>${label}</option>`);
  }
  const group = (title, opts) => `<optgroup label="${title}">${opts.join('')}</optgroup>`;
  el.innerHTML = group('女声', groups.f) + group('男声', groups.m);
}

function setVoiceSrc(v) {
  if (!(v === 'edge' || v === 'tts')) return;
  if (v === 'edge' && !edgeTtsAvailable()) return;
  state.settings.voiceSrc = v;
  saveState();
  refreshSettings();
}

function onEdgeVoiceChange(which, val) {
  if (which === 'en') state.settings.edgeVoiceEn = val;
  else state.settings.edgeVoiceZh = val;
  saveState();
  updateEdgePackUI();   // 英音色变更会影响离线包匹配,立即刷新提示
}

/* 设备TTS声音下拉：首项「自动优选」+ 按女声/男声/其他分组;
 * 收录在 VOICE_META 里的声音显示中文名并标注性别,未收录的显示原名归「其他」 */
function fillTTSVoiceSelect(id, lang, sel) {
  const el = document.getElementById(id);
  if (!el) return;
  refreshTTSVoices();
  const wantZh = /^zh/.test(lang);
  const pool = ttsVoices.filter(v => {
    const l = (v.lang || '').replace('_', '-').toLowerCase();
    return wantZh ? (l === 'zh-cn' || l === 'zh-hans' || l === 'zh') : l.indexOf('en') === 0;
  });
  const groups = { f: [], m: [], o: [] };   // 女声/男声/其他
  for (const v of pool) {
    const meta = voiceMeta(v);
    const tag = meta.g === 'f' ? '（女）' : meta.g === 'm' ? '（男）' : '';
    const label = escapeHtml(meta.zh || v.name) + tag;
    const selected = sel && v.name === sel ? ' selected' : '';
    groups[meta.g === 'f' ? 'f' : meta.g === 'm' ? 'm' : 'o'].push(
      `<option value="${escapeAttr(v.name)}"${selected}>${label}</option>`
    );
  }
  const best = pickBestTTSVoice(ttsVoices, lang);
  const bm = best ? voiceMeta(best) : null;
  const autoTag = bm ? (bm.g === 'f' ? ' · 女' : bm.g === 'm' ? ' · 男' : '') : '';
  const autoLabel = '自动优选' + (best ? `（${escapeHtml(bm.zh || best.name)}${autoTag}）` : '');
  const group = (title, opts) => opts.length ? `<optgroup label="${title}">${opts.join('')}</optgroup>` : '';
  let empty = '';
  if (!pool.length) {
    empty = `<option value="" disabled>${ttsSupported() ? '未检测到本机声音（指手机系统的文字转语音引擎，与在线发音无关；用 Edge 朗读音源不受影响）' : '本浏览器不支持设备语音'}</option>`;
  }
  el.innerHTML = `<option value="">${autoLabel}</option>` + empty +
    group('女声', groups.f) + group('男声', groups.m) + group('其他', groups.o);
}

function onTTSVoiceChange(which, val) {
  if (which === 'en') state.settings.ttsEngVoiceName = val;
  else state.settings.ttsZhVoiceName = val;
  saveState();
}

/* 试听：走真实播放链（音源优先，TTS 兜底） */
function previewVoice(kind) {
  unlockPlayback();
  if (kind === 'zh') speakDictText('你好，这是标准普通话发音测试', 'zh-CN', 1);
  else speakWord('vocabulary');
}

/* 词库选择器（设置页）：两级结构——先展示系列分组行，点开分组再选具体词库。
 * libGroupOpen：当前展开的分组；undefined=自动（展开当前词库所在组），''=用户手动全部收起 */
let libGroupOpen;

function toggleLibGroup(label) {
  libGroupOpen = (libGroupOpen === label) ? '' : label;
  renderLibPicker();
}

function renderLibPicker() {
  const el = document.getElementById('libList');
  if (!el) return;
  const cur = libKey();
  const groupOf = {};
  LIB_GROUPS.forEach(g => g.libs.forEach(k => { groupOf[k] = g.label; }));
  const curGroup = groupOf[cur];
  const open = (libGroupOpen === undefined) ? curGroup : libGroupOpen;
  el.innerHTML = LIB_GROUPS.filter(g => g.libs.some(k => LIBS[k])).map(g => {
    const isCurGroup = g.label === curGroup;
    const isOpen = g.label === open;
    const chips = g.libs.filter(k => LIBS[k]).map(k => `
      <button class="master-tab ${k === cur ? 'active' : ''}" data-lib="${k}" onclick="confirmSwitchLib('${k}')">
        ${escapeHtml(LIBS[k].name)} <span class="mt-cnt">${LIB_WORD_SETS[k].size}</span>
      </button>`).join('');
    return `<div class="lib-group">
      <button class="lib-group-head ${isCurGroup ? 'current' : ''}" onclick="toggleLibGroup('${g.label}')">
        <span class="lib-group-name">${escapeHtml(g.label)}</span>
        ${isCurGroup ? `<span class="lib-group-cur">${escapeHtml(LIBS[cur].name)}</span>` : ''}
        <span class="lib-group-arrow ${isOpen ? 'open' : ''}">${icon('chevron-left')}</span>
      </button>
      ${isOpen ? `<div class="lib-group-chips">${chips}</div>` : ''}
    </div>`;
  }).join('');
  const note = document.getElementById('libNote');
  if (note) note.textContent = `当前词库：${LIBS[cur].name}（${WORD_LIST.length} 词）。各词库的学习进度与每日新学/复习目标都独立保存，可随时切换。`;
  // 题卡右上角角标跟随当前词库（CSS content 用 --lib-badge 变量）
  const root = document.documentElement;
  if (root && root.style) root.style.setProperty('--lib-badge', JSON.stringify(LIBS[cur].name));
}

/* ---------------- 词汇 Tab（生词本/掌握情况/学习记录 分段） ---------------- */
let vocabSeg = 'book';

function setVocabSeg(seg) {
  vocabSeg = seg;
  renderVocab();
}

function renderVocab() {
  document.querySelectorAll('#vocabSegs button').forEach(b => b.classList.toggle('active', b.dataset.seg === vocabSeg));
  ['book', 'master', 'history'].forEach(s => {
    const el = document.getElementById('seg-' + s);
    if (el) el.style.display = s === vocabSeg ? 'block' : 'none';
  });
  if (vocabSeg === 'book') renderBook();
  else if (vocabSeg === 'master') renderMaster();
  else renderHistory();
}

/* ---------------- 词典 Tab ---------------- */
let dictQ = '';   // 保留搜索词，答题等操作返回后可恢复结果

function onDictInput(v) {
  dictQ = v;
  renderDictResults();
}

function renderDictResults() {
  const el = document.getElementById('dictList');
  const hint = document.getElementById('dictHint');
  if (!el) return;
  const q = dictQ.trim().toLowerCase();
  const input = document.getElementById('dictInput');
  if (input && input.value !== dictQ) input.value = dictQ;
  if (!q) {
    el.innerHTML = '';
    hint.textContent = '跨全部词库查询 · 点小喇叭听发音';
    return;
  }
  // 全词库顺序扫描(约1.6万词,毫秒级);同一单词只保留最先命中的词库
  const rows = [];
  const seen = new Set();
  for (const k of Object.keys(LIBS)) {
    for (const [w, def] of LIBS[k].words) {
      if (seen.has(w)) continue;
      const wl = w.toLowerCase();
      let score = -1;
      if (wl === q) score = 0;
      else if (wl.startsWith(q)) score = 1;
      else if (wl.includes(q)) score = 2;
      else if (def.toLowerCase().includes(q)) score = 3;
      if (score < 0) continue;
      seen.add(w);
      rows.push({ w, def, lib: k, score });
    }
  }
  rows.sort((a, b) => a.score - b.score || a.w.localeCompare(b.w));
  const shown = rows.slice(0, 50);
  hint.textContent = rows.length
    ? `匹配 ${rows.length} 个单词${rows.length > 50 ? '，显示前 50 个' : ''}`
    : '没有匹配的单词';
  if (!shown.length) { el.innerHTML = ''; return; }
  const cur = libKey();
  el.innerHTML = shown.map(r => {
    const inCur = LIB_WORD_SETS[cur].has(r.w);
    const inBookNow = !!(curWords()[r.w] && curWords()[r.w].inBook);
    const libTag = LIBS[r.lib].name.replace('词汇', '');
    return `<div class="list-card"><div class="list-item">
      <span class="list-word">${escapeHtml(r.w)}</span>
      <span class="dict-lib">${escapeHtml(libTag)}</span>
      <span class="list-def">${escapeHtml(r.def)}</span>
      ${memoOf(r.w) ? `<button class="list-memo-btn" title="巧记" onclick="toggleMemoRow('${escapeAttr(r.w)}', this)">${icon('lightbulb')}</button>` : ''}
      <button class="list-speak" title="发音" onclick="speakWord('${escapeAttr(r.w)}')">${icon('volume-2')}</button>
      ${inCur ? `<button class="list-del ${inBookNow ? 'in-book' : ''}" title="${inBookNow ? '从生词本移除' : '加入生词本'}" onclick="toggleDictBook('${escapeAttr(r.w)}')">${inBookNow ? icon('bookmark-check') : icon('bookmark-plus')}</button>` : ''}
    </div></div>`;
  }).join('');
}

function toggleDictBook(word) {
  toggleBook(word);
  renderDictResults();
}

let pendingLib = null;
function confirmSwitchLib(key) {
  if (key === libKey() || !LIBS[key]) return;
  pendingLib = key;
  const hasSession = hasSnapshot();
  document.getElementById('switchLibTitle').textContent = `切换到「${LIBS[key].name}」？`;
  document.getElementById('switchLibDesc').textContent = hasSession
    ? '进行中的学习会话将被放弃。各词库进度独立，切换后原词库进度保留，可随时切回。'
    : '各词库学习进度独立保存，切换后原词库进度保留，可随时切回。';
  document.getElementById('switchLibModal').classList.add('show');
}
function closeSwitchLib() {
  pendingLib = null;
  document.getElementById('switchLibModal').classList.remove('show');
}
function doSwitchLib() {
  if (pendingLib && LIBS[pendingLib]) {
    // 放弃进行中的会话（队列属于旧词库，切过去无法继续）
    session = null;
    clearSessionSnapshot();
    setLibrary(pendingLib);
    refreshSettings();   // 设置页 chips 高亮与说明刷新
    refreshHome();       // 首页统计与 tab 徽章同步
  }
  closeSwitchLib();
}

function adjSetting(key, delta) {
  const v = state.settings[key] + delta;
  state.settings[key] = Math.max(1, Math.min(100, v));
  saveState();
  refreshSettings();
}

function toggleAutoSpeak() {
  if (!canSpeakHere()) return;   // 无任何发声途径时按钮显示「不支持」，不可切换
  state.settings.autoSpeak = !state.settings.autoSpeak;
  saveState();
  refreshSettings();
}

function confirmReset() { document.getElementById('resetModal').classList.add('show'); }
function closeReset() { document.getElementById('resetModal').classList.remove('show'); }
function doReset() {
  if (lastResetWord) {
    resetWord(lastResetWord);
    lastResetWord = null;
    closeReset();
    renderMaster();
    refreshHome();
    return;
  }
  state = defaultState();
  saveState();
  rebuildWordData();   // 重置回到默认四级词库
  closeReset();
  go('screen-home');
}

/* ---------------- 导出 / 导入进度 ---------------- */
function exportProgressFile() {
  const json = exportProgress();
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  a.href = url;
  a.download = `英语词汇通_进度_${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  setImportMsg('已导出进度文件，把它发到另一台设备即可', 'ok');
}

function handleImport(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  // 安全限制:进度文件最大 10MB,拒绝异常巨大的文件
  if (file.size > 10 * 1024 * 1024) {
    setImportMsg('文件超过 10MB，不是有效的进度文件', 'err');
    event.target.value = '';
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const n = importProgress(String(reader.result));
      setImportMsg(`导入成功，同步了 ${n} 个单词的学习记录`, 'ok');
      refreshHome();
      if (masterTab) renderMaster();
      renderBook();
    } catch (e) {
      setImportMsg('导入失败：' + e.message, 'err');
    }
  };
  reader.onerror = () => setImportMsg('读取文件失败', 'err');
  reader.readAsText(file, 'utf-8');
  event.target.value = ''; // 允许重复选择同一文件
}

function setImportMsg(text, kind) {
  const el = document.getElementById('importMsg');
  if (!el) return;
  el.textContent = text;
  el.style.color = kind === 'ok' ? 'var(--green)' : 'var(--pen-red)';
  setTimeout(() => { el.textContent = ''; }, 6000);
}

/* ============================================================
 * 答题会话（学习 / 复习 共用）
 * ============================================================
 * 三段式流程（学习与复习逻辑一致）：
 *   1. 识别阶段：英译汉（看单词选释义），逐词出题
 *      答错/不会 → 不卡住，刷新下一个词，该词进入「错词池」
 *      （记几次错，延迟到本阶段收尾才重新出现，须再答对多次）
 *   2. 全部识别完后，询问是否进入拼写阶段（可拒绝）
 *   3. 拼写阶段：看释义拼写，连对达标才完成
 *   拼写答错时不卡住：进拼写错词池，先出下一个词，稍后穿插重现
 *   答错时：可自选是否加入生词本
 */
let session = null;
/* 会话状态: { mode, queue, pending(识别队列), idx, correct, wrong,
 *   records: Map(word -> { errors, corrects, spellCorrects, done }),
 *   spellOn(是否进入拼写), phase('recognize'|'spell'|'done'),
 *   retries(识别错词池), spellRetries(拼写错词池), sinceSpellRetry(拼写穿插计数) }
 */
const RECOG_REQUIRED = 3;   // 错词重新出现后需累计答对次数（多次）
const SPELL_REQUIRED = 2;   // 拼写需连续答对次数
const ERROR_POOL = 3;       // 错词延迟：约每3个新词后重新出现一次

function makeRecord() { return { errors: 0, corrects: 0, spellCorrects: 0, done: false }; }

/* ---------------- 会话快照（断点续学） ----------------
 * 每次答题后把当前 session 进度存入 localStorage，
 * 刷新/关闭后可从上次中断处继续。
 */
const SESSION_KEY = 'cet4_session_snapshot_v1';

function saveSessionSnapshot() {
  if (!session) return;
  try {
    const snap = {
      mode: session.mode,
      day: dateKey(),          // 快照归属日:跨天自动失效(次日重置)
      queue: session.queue,
      pending: session.pending || [],
      retries: session.retries || [],
      sinceRetry: session.sinceRetry || 0,
      idx: session.idx || 0,
      correct: session.correct || 0,
      wrong: session.wrong || 0,
      spellOn: !!session.spellOn,
      phase: session.phase || 'recognize',
      spellRetries: session.spellRetries || [],
      sinceSpellRetry: session.sinceSpellRetry || 0,
      records: Array.from((session.records || new Map()).entries()).map(([w, r]) => [w, {
        errors: r.errors, corrects: r.corrects, spellCorrects: r.spellCorrects, done: !!r.done,
      }]),
    };
    localStorage.setItem(SESSION_KEY, JSON.stringify(snap));
  } catch (e) { /* 忽略 */ }
}

function clearSessionSnapshot() {
  try { localStorage.removeItem(SESSION_KEY); } catch (e) { /* 忽略 */ }
}

function loadSessionSnapshot() {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const snap = JSON.parse(raw);
    if (!snap || !Array.isArray(snap.queue) || !snap.queue.length) return null;
    // 跨天快照失效:未完成的会话只保留当天,第二天自动清除重置
    if (snap.day && snap.day !== dateKey()) {
      clearSessionSnapshot();
      return null;
    }
    // 恢复 records
    const records = new Map();
    (snap.records || []).forEach(([w, r]) => {
      records.set(w, {
        errors: r.errors || 0, corrects: r.corrects || 0,
        spellCorrects: r.spellCorrects || 0, done: !!r.done,
      });
    });
    snap.records = records;
    return snap;
  } catch (e) { return null; }
}

function hasSnapshot() {
  return !!loadSessionSnapshot();
}

function startStudy() {
  const g = goalInfo();
  if (g.allDone) {
    const el = document.getElementById('studyQuiz');
    el.innerHTML = allLearnedHtml();
    go('screen-study');
    return;
  }
  if (g.done) {
    const el = document.getElementById('studyQuiz');
    el.innerHTML = goalDoneHtml();
    go('screen-study');
    return;
  }
  const unseen = unseenWords();
  const n = Math.min(g.remaining, unseen.length);
  const picked = pickRandom(unseen, n);
  const records = new Map();
  picked.forEach(w => records.set(w, makeRecord()));
  session = {
    mode: 'study',
    queue: picked,             // 全部新学单词
    pending: picked.slice(),   // 待识别队列
    retries: [],               // 答错待重记队列
    sinceRetry: 0,             // 距上次穿插错词的间隔
    idx: 0,
    correct: 0, wrong: 0,
    records, spellOn: false, phase: 'recognize',
  };
  clearSessionSnapshot();
  go('screen-study');
  renderStudyRecognize();
}

function goalDoneHtml() {
  const g = goalInfo();
  return `
    <div class="quiz-card session-done">
      <div class="icon">${icon("target")}</div>
      <h2>今日新学目标已完成！</h2>
      <p>「${escapeHtml(LIBS[libKey()].name)}」今天已学 <b>${g.learned}</b> 个新词，目标 ${g.target} 个。<br>各词库目标独立，切换词库可以继续学。<br>坚持就是胜利，明天再来吧。</p>
      <div class="modal-btns" style="max-width:320px;margin:0 auto;flex-direction:column;gap:10px">
        <button class="next-btn" onclick="goHome()">回到首页</button>
        <button class="btn-ghost" onclick="go('screen-settings')">调整每日目标，继续学习</button>
      </div>
    </div>
  `;
}

function allLearnedHtml() {
  return `
    <div class="quiz-card session-done">
      <div class="icon">${icon("trophy")}</div>
      <h2>全部单词已学完！</h2>
      <p>当前词库 ${WORD_LIST.length} 个单词你已经全部学过了，太棒了！<br>去「掌握情况」看看你的成果吧。</p>
      <div class="modal-btns" style="max-width:320px;margin:0 auto;flex-direction:column;gap:10px">
        <button class="next-btn" onclick="goHome()">回到首页</button>
      </div>
    </div>
  `;
}

function startReview() {
  const due = dueWords();
  if (!due.length) {
    // 无到期复习：给出友好提示，不创建空会话
    const el = document.getElementById('reviewQuiz');
    el.innerHTML = noReviewHtml();
    go('screen-review');
    return;
  }
  const n = Math.min(state.settings.dailyReview, due.length);
  const picked = pickRandom(due, n);
  const records = new Map();
  picked.forEach(w => records.set(w, makeRecord()));
  session = {
    mode: 'review',
    queue: picked,
    pending: picked.slice(),
    retries: [],
    sinceRetry: 0,
    idx: 0,
    correct: 0, wrong: 0,
    records, spellOn: false, phase: 'recognize',
  };
  clearSessionSnapshot();
  go('screen-review');
  renderStudyRecognize();
}

function noReviewHtml() {
  const g = goalInfo();
  return `
    <div class="quiz-card session-done">
      <div class="icon">${icon("coffee")}</div>
      <h2>暂无到期复习</h2>
      <p>今天没有待复习的单词。<br>新学的词会从明天起按记忆曲线陆续到期（今日已复习 ${g.reviewedToday} 词）。</p>
      <div class="modal-btns" style="max-width:320px;margin:0 auto;flex-direction:column;gap:10px">
        <button class="next-btn" onclick="goHome()">回到首页</button>
      </div>
    </div>
  `;
}

/* ---------- 识别阶段（学习/复习共用） ----------
 * 队列模型：
 *   session.pending  尚未完成识别的词（新词，答对一次即过）
 *   session.retries  答错过需重记的词（须再答对 RECOG_REQUIRED 次）
 * 交杂规则：每学 3 个新词，穿插 1 个错词重现
 */
const RETRY_INTERVAL = 3;   // 每学几个新词穿插一个错词

function renderStudyRecognize() {
  const el = document.getElementById(session.mode === 'study' ? 'studyQuiz' : 'reviewQuiz');
  const pending = session.pending || [];
  const retries = session.retries || [];

  // 识别全部完成 → 询问拼写
  if (!pending.length && !retries.length) {
    session.phase = 'spellAsk';
    el.innerHTML = spellAskHtml();
    return;
  }

  let word;
  if (pending.length) {
    // 有未学新词：学满 RETRY_INTERVAL 个后穿插重现一个错词
    if (retries.length && (session.sinceRetry || 0) >= RETRY_INTERVAL) {
      word = retries[0];
      session.sinceRetry = 0;
      rotateRetries();
    } else {
      word = pending[0];
      session.sinceRetry = (session.sinceRetry || 0) + 1;
    }
  } else {
    // 新词学完只剩错词：轮转重现，避免同一个错词连续重复
    word = retries[0];
    rotateRetries();
  }
  session.word = word;
  session.answered = false;
  renderRecognizeOne(word);
}

/* 轮转错词队列：把刚出题的错词移到队尾，让多个错词交替重现 */
function rotateRetries() {
  if (session.retries && session.retries.length > 1) {
    session.retries.push(session.retries.shift());
  }
}

function renderRecognizeOne(word) {
  const el = document.getElementById(session.mode === 'study' ? 'studyQuiz' : 'reviewQuiz');
  // 学习/复习识别阶段固定英译汉；汉译英考察由拼写阶段承担（看释义写单词）
  const q = makeQuestion(word);
  session.q = q;
  session.answered = false;
  prefetchUpcomingAudio();
  const rec = session.records.get(word) || makeRecord();
  const isRelearn = rec.errors > 0;
  const typeLabel = (isRelearn ? '重记' : session.mode === 'study' ? '学习' : '复习') + ' · ' + q.type;
  const promptCls = 'quiz-prompt';
  const speakBtn = canSpeakHere() ? `<button class="speak-btn" title="发音" onclick="speakCurrent()">${icon('volume-2')}</button>` : '';
  const optionsHtml = q.options.map((o, i) =>
    `<button class="opt" data-ans="${o.isAnswer}" onclick="recognizeAnswer(${i}, this)">${escapeHtml(o.text)}</button>`
  ).join('');
  const retryNote = isRelearn ? `<div class="retry-note">重记词 · 还需答对 ${Math.max(0, RECOG_REQUIRED - rec.corrects)} 次</div>` : '';
  el.innerHTML = `
    <div class="quiz-card">
      <span class="quiz-type${session.mode === 'review' ? ' rev' : ''}">${typeLabel}</span>
      <div class="${promptCls}">${escapeHtml(q.prompt)}${speakBtn}</div>
      <div class="progress-line">${session.mode === 'study' ? '学习新词' : '复习'}　·　✓ ${session.correct} ✗ ${session.wrong}</div>
      <div class="options">${optionsHtml}</div>
      ${retryNote}
      <div class="show-ans-wrap">
        <button class="show-ans-btn" onclick="showAnswer()">${icon('eye')} 不会，看答案</button>
      </div>
      <div id="feedbackZone"></div>
    </div>
  `;
  if (state.settings.autoSpeak) speakWord(word);
}

function recognizeAnswer(idx, btnEl) {
  if (session.answered) return;
  session.answered = true;
  const word = session.word;
  const isCorrect = session.q.options[idx].isAnswer;
  const rec = session.records.get(word) || makeRecord();

  document.querySelectorAll('.opt').forEach(b => {
    if (b.dataset.ans === 'true') b.classList.add('correct');
  });
  if (!isCorrect) btnEl.classList.add('wrong');

  if (isCorrect) {
    session.correct++;
    rec.corrects++;
    session.records.set(word, rec);
    const need = rec.errors > 0 ? RECOG_REQUIRED : 1;
    if (rec.corrects >= need) {
      // 已达标 → 从待识别队列移除，并在此刻正式提交学习/复习结果
      removeFromQueue(word);
      if (session.mode === 'study') learnWord(word);
      else reviewCorrect(word);
    }
    // 答对即刷新到下一个词，不停留
    saveSessionSnapshot();
    session.answered = false;
    renderStudyRecognize();
    return;
  }
  // 答错：不卡住，移到错词池，显示反馈（可选生词本）后刷新
  session.wrong++;
  rec.errors++;
  rec.corrects = 0;
  session.records.set(word, rec);
  // 写回学习状态（生词本由按钮控制，这里不强制加入）
  if (session.mode === 'study') noteWrong(word, false);
  else reviewWrong(word, false);
  addToRetries(word);
  session.sinceRetry = 0;  // 答错后重新开始计数，避免错词紧跟重现
  saveSessionSnapshot();
  showWrongFeedback(word, session.q.options[idx].text);
}

/* ---------------- 发音引擎 ----------------
 * 两层结构：① Edge 朗读（男女音色自选，WebSocket 实时合成，IndexedDB 永久缓存 + 预取）
 * ② 设备 speechSynthesis 兜底。Edge 失败/关闭时降级设备 TTS。
 * Edge 音频走 <audio>（Blob 流），熄屏/切后台继续播；设备TTS 的坑统一处理：
 * 1. iOS 要求首次 speak() 发生在用户手势里 → 首次触摸时用空 utterance 解锁
 * 2. 部分安卓浏览器把 cancel() 后立即 speak() 的语音静默丢弃 → 只在播报中才 cancel，
 *    且 speak 后 250ms 检查是否真的开始，没开始重试一次
 * 3. 微信/QQ 等内置浏览器可能没有 speechSynthesis → 有 Edge 朗读兜着，两者皆无才隐藏
 */
function ttsSupported() {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

/* Edge 朗读整体可用性：浏览器须为可用版本的 Edge（UA 校验，纯函数 isEdgeBrowser）
 * 且支持 WebSocket + crypto.subtle（token 要做 SHA-256，file:// 下也成立） */
function edgeTtsAvailable() {
  return typeof WebSocket !== 'undefined'
    && typeof crypto !== 'undefined' && !!crypto.subtle
    && typeof TextEncoder !== 'undefined'
    && isEdgeBrowser(typeof navigator !== 'undefined' ? navigator.userAgent : '');
}

/* 用户当前选择是否走 Edge 朗读 */
function canUseEdgeVoice() {
  return state.settings.voiceSrc === 'edge' && edgeTtsAvailable();
}

/* 当前环境是否还有任何发声途径（发音按钮/听写入口的显隐守卫） */
function canSpeakHere() {
  return ttsSupported() || edgeTtsAvailable();
}

/* 当前正在播的 <audio>（全局只有一个，新的播报顶掉旧的；stopDictPlayback 负责掐掉） */
let currentAudioEl = null;
function stopSpeakAudio() {
  if (currentAudioEl) {
    try { currentAudioEl.pause(); } catch (e) { /* 忽略 */ }
    currentAudioEl = null;
  }
}

let ttsUnlocked = false;
function unlockTTS() {
  if (ttsUnlocked || !ttsSupported()) return;
  try {
    const u = new SpeechSynthesisUtterance('');
    u.volume = 0;
    window.speechSynthesis.speak(u);
    ttsUnlocked = true;
  } catch (e) { /* 忽略 */ }
}

/* 静音 wav：首次用户手势里 play() 一次，解锁后续程序化触发的 <audio> 播放（iOS/安卓） */
const SILENT_WAV = 'data:audio/wav;base64,UklGRoQJAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YWAJAAAA';
let audioUnlocked = false;
function unlockAudio() {
  if (audioUnlocked || typeof Audio === 'undefined') return;
  try {
    const a = new Audio(SILENT_WAV);
    a.volume = 0;
    const p = a.play();
    if (p && p.catch) p.catch(() => { audioUnlocked = false; });
    audioUnlocked = true;
  } catch (e) { /* 忽略 */ }
}
function unlockPlayback() { unlockTTS(); unlockAudio(); }
document.addEventListener('pointerdown', unlockPlayback, { once: true });
document.addEventListener('touchstart', unlockPlayback, { once: true });

/* ---------------- Edge 朗读合成器 ----------------
 * 一次合成 = 一条 WebSocket：发 speech.config + SSML，收二进制帧（2 字节大端头长 +
 * 头部含 Path:audio 的 MP3 数据），Path:turn.end 结束。产物 MP3 Blob → objectURL →
 * <audio> 播放（熄屏续播/锁屏媒体信息一致）。
 * 两级缓存:内存 LRU(200 条,本会话) + IndexedDB 永久缓存(跨会话,离线可用);
 * 合成过的词以后零网络。预取(呈现在前,合成在后)让"第一次听到"也不等网络。
 * speakEpoch：停止播报（stopDictPlayback 等）时 +1，在途合成完成后发现代际变了就静默丢弃，
 * 避免停止后旧文本又通过降级层冒出来。
 */
const edgeBlobCache = new Map();   // key: voice|rate|text → objectURL（LRU，上限 200）
const EDGE_CACHE_MAX = 200;
const edgeSockets = new Set();     // 在途合成连接（stopEdgeSynth 统一掐掉；允许预取+播报并存）
let speakEpoch = 0;

function stopEdgeSynth() {
  for (const ws of edgeSockets) { try { ws.close(); } catch (e) { /* 忽略 */ } }
  edgeSockets.clear();
}

function edgeCacheGet(key) {
  const u = edgeBlobCache.get(key);
  if (u) { edgeBlobCache.delete(key); edgeBlobCache.set(key, u); }   // 触碰即刷新 LRU 位次
  return u;
}
function edgeCachePut(key, url) {
  if (edgeBlobCache.has(key)) edgeBlobCache.delete(key);
  edgeBlobCache.set(key, url);
  while (edgeBlobCache.size > EDGE_CACHE_MAX) {
    const oldest = edgeBlobCache.keys().next().value;
    const u = edgeBlobCache.get(oldest);
    try { if (u && u.indexOf('blob:') === 0) URL.revokeObjectURL(u); } catch (e) { /* 忽略 */ }
    edgeBlobCache.delete(oldest);
  }
}

/* ---------------- IndexedDB 永久缓存(第二级) ----------------
 * 内存 LRU 关掉应用就没了;IndexedDB 里存 MP3 Blob,跨会话永久有效——
 * Edge 音源的"离线积累"全靠它。任何失败都静默降级为纯内存缓存。 */
const EDGE_IDB = { db: null };
function edgeIdbOpen() {
  return new Promise(resolve => {
    if (EDGE_IDB.db) return resolve(EDGE_IDB.db);
    if (typeof indexedDB === 'undefined') return resolve(null);
    try {
      const req = indexedDB.open('cet4-edge-tts', 1);
      req.onupgradeneeded = () => { req.result.createObjectStore('audio'); };
      req.onsuccess = () => { EDGE_IDB.db = req.result; resolve(req.result); };
      req.onerror = () => resolve(null);
      req.onblocked = () => resolve(null);
    } catch (e) { resolve(null); }
  });
}
function edgeIdbGet(key) {
  return edgeIdbOpen().then(db => new Promise(resolve => {
    if (!db) return resolve(null);
    try {
      const tx = db.transaction('audio').objectStore('audio').get(key);
      tx.onsuccess = () => resolve(tx.result || null);
      tx.onerror = () => resolve(null);
    } catch (e) { resolve(null); }
  }));
}
function edgeIdbPut(key, blob) {
  return edgeIdbOpen().then(db => new Promise(resolve => {
    if (!db) return resolve();
    try {
      const tx = db.transaction('audio', 'readwrite').objectStore('audio').put(blob, key);
      tx.onsuccess = () => resolve();
      tx.onerror = () => resolve();
      tx.onabort = () => resolve();
    } catch (e) { resolve(); }
  }));
}

/* ---------------- 预取 ----------------
 * 呈现新词时把后面几个词的音频提前合成好(pending/剩余队列),串行队列避免并发连接风暴;
 * 学到哪个词,后面 4 个词已经在缓存里等着,"第一次听到"也不等网络。 */
const PREFETCH_AHEAD = 4;
let edgePrefetchChain = Promise.resolve();
function edgePrefetch(text, voice, rate) {
  const key = voice + '|' + edgeRate(rate) + '|' + text;
  if (edgeBlobCache.has(key)) return;
  edgePrefetchChain = edgePrefetchChain.then(() => edgeSynthesize(text, voice, rate)).catch(() => { /* 忽略 */ });
}
function prefetchUpcomingAudio() {
  if (!canUseEdgeVoice() || !session) return;
  const ahead = (list) => list.filter(w => w && w !== session.word).slice(0, PREFETCH_AHEAD);
  if (session.mode === 'dict') {
    const rate = state.settings.dictRate || 0.9;
    const rem = session.queue.filter(w => !(session.records.get(w) || makeRecord()).done);
    for (const w of ahead(rem)) {
      edgePrefetch(w, edgeVoiceOf('en-US'), rate);
      edgePrefetch(speakableDef(w) || w, edgeVoiceOf('zh-CN'), Math.min(1.2, rate + 0.1));
    }
  } else if (session.mode === 'listen') {
    // 听音辨义:题干是单词读音,预取后续词的单词音频
    const rem = session.queue.filter(w => !(session.records.get(w) || makeRecord()).done);
    for (const w of ahead(rem)) edgePrefetch(w, edgeVoiceOf('en-US'), 0.9);
  } else if (session.mode === 'spell' || (session.phase === 'spell')) {
    const rem = session.queue.filter(w => !(session.records.get(w) || makeRecord()).done);
    for (const w of ahead(rem)) edgePrefetch(w, edgeVoiceOf('en-US'), 0.9);
  } else {
    // 学习/复习识别阶段:自动发音只读单词
    for (const w of ahead(session.pending || [])) edgePrefetch(w, edgeVoiceOf('en-US'), 0.9);
  }
}

/* ---------------- Edge 发音离线包（设置页批量预热） ----------------
 * 把当前词库全部单词用当前英音色预合成一遍,产物落 IndexedDB 永久缓存 →
 * 之后所有模块的单词发音零网络等待(秒播),离线可用。
 * 批量经验(来自 rany2/edge-tts issue 区):约 5-10% 请求会随机失败(NoAudioReceived),
 * 重试即成功 → 每词最多重试 3 次(1s/2s/4s 指数退避+抖动);并发压到 2 防撞 IP 级限流。
 * 已缓存的词走三级查找秒过,中断/失败后再点 = 断点续传只补缺的。
 * 元数据存 settings.edgePack:{lib,voice,rate,words,ts},换音色/词库后提示重新下载(旧包保留)。 */
const EDGE_PACK_RATE = 0.9;        // 包内语速:与 speakWord 缺省一致(播放端 playbackRate 还可再变速)
const EDGE_PACK_RETRIES = 3;       // 单词最大重试次数
const EDGE_PACK_LIMIT_START = 3;   // 起步并发数
const EDGE_PACK_LIMIT_MAX = 6;     // 并发上限:连续成功逐步爬到这一档
const EDGE_PACK_RAMP_EVERY = 8;    // 每连续成功 N 词升一档并发
let edgePackJob = null;            // 进行中的下载任务,null=空闲

/* 包内缓存键:必须与播放链路的键完全一致(音色|edgeRate|文本),否则白下 */
function edgePackKeyOf(word, voice) {
  return voice + '|' + edgeRate(EDGE_PACK_RATE) + '|' + word;
}

/* 包元数据是否与当前(词库,音色)匹配 */
function edgePackMetaMatches(meta, lib, voice) {
  return !!meta && meta.lib === lib && meta.voice === voice;
}

/* 第 attempt 次重试前的等待:1s/2s/4s 基础 + 0~0.4s 抖动(打散重试风暴) */
function edgePackBackoffMs(attempt) {
  return Math.pow(2, attempt - 1) * 1000 + Math.floor(Math.random() * 400);
}

function edgePackSleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

/* 数当前词库在当前英音色下已缓存多少个单词音频(一个事务批量 get,几千词几百毫秒) */
function edgePackCachedCount() {
  return edgeIdbOpen().then(db => new Promise(resolve => {
    const total = WORD_LIST.length;
    if (!db || !total) return resolve(0);
    const voice = edgeVoiceOf('en-US');
    try {
      const store = db.transaction('audio').objectStore('audio');
      let done = 0, hit = 0;
      const step = () => { if (++done === total) resolve(hit); };
      for (const w of WORD_LIST) {
        const r = store.get(edgePackKeyOf(w, voice));
        r.onsuccess = () => { if (r.result) hit++; step(); };
        r.onerror = step;
      }
    } catch (e) { resolve(0); }
  }));
}

/* 空闲态状态行文案(纯函数,cached=当前词库已缓存词数) */
function edgePackIdleStatus(cached) {
  if (!canUseEdgeVoice()) return '当前浏览器不支持 Edge 朗读，离线包不可用。';
  const total = WORD_LIST.length;
  const libName = (LIBS[libKey()] || LIBS.cet4).name;
  const vm = edgeVoiceById(edgeVoiceOf('en-US'));
  const curVoiceName = vm ? vm.zh : edgeVoiceOf('en-US');
  const cachedTxt = `已缓存 ${cached}/${total} 词`;
  const mb = Math.max(1, Math.round(total * 6 / 1000));
  const meta = state.settings.edgePack;
  if (!meta) {
    return `未下载（${cachedTxt}）· 把本词库 ${total} 个单词的发音预存到本地（约 ${mb} MB），下载后单词发音零等待、离线可用。`;
  }
  const pm = edgeVoiceById(meta.voice);
  const changed = [];
  if (meta.lib !== libKey()) changed.push('词库已切到「' + libName + '」');
  if (meta.voice !== edgeVoiceOf('en-US')) changed.push('英音色已改为「' + curVoiceName + '」');
  if (changed.length) {
    const packName = (LIBS[meta.lib] || {}).name || meta.lib;
    return `${changed.join('，')}，包内是「${pm ? pm.zh : meta.voice} × ${packName}」的音频（${cachedTxt}）→ 重新下载后全库秒播；旧包保留，切回不用重下。`;
  }
  if (cached >= total) return `已就绪（${cachedTxt}）· 音色 ${curVoiceName} × ${libName} · 发音零等待，离线可用。`;
  return `包内音色/词库未变（${cachedTxt}）→ 点「补漏」把没下完的补齐。`;
}

/* 空闲态按钮文案(纯函数) */
function edgePackBtnLabel(cached) {
  if (!canUseEdgeVoice()) return '不可用';
  const total = WORD_LIST.length;
  if (cached >= total) return '重新下载';
  return state.settings.edgePack ? '补漏 ' + (total - cached) + ' 词' : '下载发音包';
}

/* 下载中状态行文案(纯函数,now 可显式传入便于测试):含实时速率与剩余时间预估 */
function edgePackRunStatus(job, now) {
  let s = `下载中 ${job.done}/${job.list.length}`;
  if (typeof now !== 'number') now = Date.now();
  const rate = job.done / Math.max(1, (now - job.t0) / 1000);
  if (rate >= 0.25) {
    const remain = (job.list.length - job.done) / rate;
    s += ` · ${rate.toFixed(1)} 词/秒 · 剩约 ${remain >= 90 ? Math.round(remain / 60) + ' 分钟' : Math.round(remain) + ' 秒'}`;
  }
  if (job.paused) s += '（已暂停，点「继续」接着下）';
  if (job.failed.length) s += ` · 失败 ${job.failed.length}（结束后可补漏）`;
  return s;
}

/* 按 job 现状刷一遍设置页 UI(状态行/进度条/按钮) */
function edgePackRender() {
  const job = edgePackJob;
  const st = document.getElementById('edgePackStatus');
  const bar = document.getElementById('edgePackBar');
  const btn = document.getElementById('edgePackBtn');
  const stop = document.getElementById('edgePackStopBtn');
  if (bar) bar.style.width = job ? Math.round((job.done / Math.max(1, job.list.length)) * 100) + '%' : '0%';
  if (btn) btn.textContent = job ? (job.paused ? '继续' : '暂停') : '下载发音包';
  if (stop) stop.style.display = job ? '' : 'none';
  if (st) st.textContent = job ? edgePackRunStatus(job) : '';
}

/* 设置页发音卡的离线包区块:空闲查缓存计数,下载中显示进度。renderVoiceSettings/收尾时调用 */
function updateEdgePackUI() {
  const st = document.getElementById('edgePackStatus');
  if (!st) return Promise.resolve();
  if (edgePackJob) { edgePackRender(); return Promise.resolve(); }
  return edgePackCachedCount().then(cached => {
    if (edgePackJob) { edgePackRender(); return; }
    st.textContent = edgePackIdleStatus(cached);
    const bar = document.getElementById('edgePackBar');
    if (bar) bar.style.width = Math.round((cached / Math.max(1, WORD_LIST.length)) * 100) + '%';
    const btn = document.getElementById('edgePackBtn');
    if (btn) btn.textContent = edgePackBtnLabel(cached);
    const stop = document.getElementById('edgePackStopBtn');
    if (stop) stop.style.display = 'none';
  });
}

/* 主按钮:空闲→开任务;下载中→暂停/继续(继续时重新触发调度泵) */
function edgePackToggle() {
  if (!edgePackJob) { edgePackStart(); return; }
  edgePackJob.paused = !edgePackJob.paused;
  if (!edgePackJob.paused) edgePackPump(edgePackJob);
  edgePackRender();
}

/* 停止并丢弃任务(在途合成自然完成并入缓存,已下的不浪费) */
function edgePackStopJob() {
  if (!edgePackJob) return;
  edgePackJob = null;
  updateEdgePackUI();
}

function edgePackStart() {
  if (edgePackJob) return;
  if (!canUseEdgeVoice()) { alert('当前浏览器不支持 Edge 朗读，无法下载发音包。'); return; }
  if (!WORD_LIST.length) return;
  edgePackJob = {
    lib: libKey(), voice: edgeVoiceOf('en-US'),
    list: WORD_LIST.slice(), i: 0, done: 0, failed: [],
    paused: false,
    active: 0, limit: EDGE_PACK_LIMIT_START, streak: 0,   // 自适应并发:在途数/当前并发档/连续成功计数
    t0: Date.now(),
  };
  edgePackRender();
  edgePackPump(edgePackJob);
}

/* 单词合成带重试:失败按 1s/2s/4s 退避重试,仍失败记入 failed 由「补漏」兜底 */
async function edgePackSynthWithRetry(word, voice, job) {
  for (let attempt = 0; attempt <= EDGE_PACK_RETRIES; attempt++) {
    if (attempt) await edgePackSleep(edgePackBackoffMs(attempt));
    if (edgePackJob !== job) return null;   // 任务已停止/重开,别再耗网络
    const url = await edgeSynthesize(word, voice, EDGE_PACK_RATE);
    if (url) return url;
  }
  return null;
}

/* 调度泵:有空位就发起新的合成(事件驱动,无轮询)。
 * 自适应并发——连续成功 EDGE_PACK_RAMP_EVERY 词升一档(至 MAX),
 * 一旦失败立即降一档归零连击,被微软限流时自动放慢不硬撞。 */
function edgePackPump(job) {
  while (edgePackJob === job && !job.paused && job.active < job.limit && job.i < job.list.length) {
    const word = job.list[job.i++];
    job.active++;
    edgePackSynthWithRetry(word, job.voice, job).then(url => {
      job.active--;
      if (edgePackJob !== job) return;      // 已停止/已重开:旧任务就地消亡
      job.done++;
      if (!url) job.failed.push(word);
      if (url) {
        job.streak++;
        if (job.streak >= EDGE_PACK_RAMP_EVERY && job.limit < EDGE_PACK_LIMIT_MAX) { job.limit++; job.streak = 0; }
      } else {
        job.streak = 0;
        if (job.limit > 1) job.limit--;
      }
      edgePackRender();
      edgePackPump(job);
      edgePackMaybeFinish(job);
    });
  }
  edgePackMaybeFinish(job);
}

/* 全部取空且在途清零(且未暂停)即收尾 */
function edgePackMaybeFinish(job) {
  if (edgePackJob === job && !job.paused && job.active === 0 && job.i >= job.list.length) edgePackFinish(job);
}

/* 全部扫完收尾:写元数据入档(断点续传的"完成"凭证),UI 切回空闲态 */
function edgePackFinish(job) {
  if (edgePackJob !== job) return;
  edgePackJob = null;
  state.settings.edgePack = { lib: job.lib, voice: job.voice, rate: EDGE_PACK_RATE, words: job.list.length, ts: Date.now() };
  saveState();
  updateEdgePackUI();
}

/* Sec-MS-GEC token：SHA-256(时间刻度 + TrustedClientToken) 大写十六进制 */
async function edgeTtsToken() {
  const s = edgeGecTicks(Date.now()) + EDGE_TRUSTED_TOKEN;
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  let hex = '';
  for (const b of new Uint8Array(buf)) hex += (b < 16 ? '0' : '') + b.toString(16);
  return hex.toUpperCase();
}

/* 合成一段文本 → blob objectURL；失败/取消/无音频返回 null。
 * 三级查找:内存 LRU → IndexedDB 永久缓存 → 网络合成(成功后写回两级缓存)。
 * 在途去重:同一文本并行请求(预取+立即播)只发一条连接 */
const edgeInflight = new Map();
function edgeSynthesize(text, voice, rate) {
  const key = voice + '|' + edgeRate(rate) + '|' + text;
  if (edgeInflight.has(key)) return edgeInflight.get(key);
  const p = edgeSynthesizeNow(text, voice, rate, key).finally(() => edgeInflight.delete(key));
  edgeInflight.set(key, p);
  return p;
}

async function edgeSynthesizeNow(text, voice, rate, key) {
  const mem = edgeCacheGet(key);
  if (mem) return mem;
  const cachedBlob = await edgeIdbGet(key);
  if (cachedBlob) {
    const url = URL.createObjectURL(cachedBlob);
    edgeCachePut(key, url);
    return url;
  }
  return await new Promise(resolve => {
    let settled = false, timer = null, ws = null;
    const chunks = [];
    const fin = (val) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (ws) edgeSockets.delete(ws);
      try { if (ws) ws.close(); } catch (e) { /* 忽略 */ }
      resolve(val);
    };
    const makeUrl = () => {
      const blob = new Blob(chunks, { type: 'audio/mpeg' });
      edgeIdbPut(key, blob);   // 写永久缓存,火后不理
      const url = URL.createObjectURL(blob);
      edgeCachePut(key, url);
      return url;
    };
    edgeTtsToken().then(token => {
      if (settled) return;
      ws = new WebSocket(edgeTtsUrl(token, edgeUaVersion(navigator.userAgent)));
      edgeSockets.add(ws);
      ws.binaryType = 'arraybuffer';
      ws.onopen = () => {
        if (settled) return;
        const ts = new Date().toString().replace(/GMT.*$/, 'GMT+0000 (Coordinated Universal Time)');
        ws.send('X-Timestamp:' + ts + '\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n'
          + '{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false",'
          + '"wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}\r\n');
        const rb = new Uint8Array(16);
        crypto.getRandomValues(rb);
        const reqId = Array.prototype.map.call(rb, b => b.toString(16).padStart(2, '0')).join('');
        ws.send('X-RequestId:' + reqId + '\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:' + ts
          + 'Z\r\nPath:ssml\r\n\r\n' + edgeSsml(text, voice, rate));
      };
      ws.onmessage = (ev) => {
        if (settled) return;
        if (typeof ev.data === 'string') {
          if (ev.data.indexOf('Path:turn.end') >= 0) fin(chunks.length ? makeUrl() : null);
          return;
        }
        const buf = new Uint8Array(ev.data);
        if (buf.length < 2) return;
        const hLen = (buf[0] << 8) | buf[1];
        if (hLen > buf.length) return;
        const head = new TextDecoder().decode(buf.slice(2, 2 + hLen));
        if (head.indexOf('Path:audio') >= 0 && buf.length > 2 + hLen) chunks.push(buf.slice(2 + hLen));
      };
      ws.onerror = () => fin(null);
      ws.onclose = () => { if (!settled) fin(null); };
      /* 超时兜底：连接/合成慢或服务端事件不触发；已有部分音频就用部分音频 */
      timer = setTimeout(() => fin(chunks.length ? makeUrl() : null), Math.max(9000, text.length * 450));
    }).catch(() => fin(null));
  });
}

/* Edge 朗读播完一整段：true=播完 / false=失败需降级 / 'x'=期间被停止，不再降级 */
async function edgePlayAwait(text, lang, rate) {
  if (!canUseEdgeVoice()) return false;
  const epoch = speakEpoch;
  const url = await edgeSynthesize(text, edgeVoiceOf(lang), rate);
  if (epoch !== speakEpoch) return 'x';
  if (!url) return false;
  return await blobPlayAwait(url, rate, Math.max(8000, text.length * 900));
}

/* Blob 音频等待播完（形状与旧在线音源播报一致：onended 推进 + 超时兜底） */
function blobPlayAwait(url, rate, timeoutMs) {
  return new Promise(resolve => {
    try {
      stopSpeakAudio();
      const el = new Audio(url);
      el.playbackRate = rate;
      try { el.preservesPitch = true; } catch (e) { /* 老浏览器忽略 */ }
      currentAudioEl = el;
      let done = false;
      const fin = (ok) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        if (currentAudioEl === el) currentAudioEl = null;
        resolve(ok);
      };
      el.onended = () => fin(true);
      el.onerror = () => fin(false);
      const p = el.play();
      if (p && p.catch) p.catch(() => fin(false));
      const timer = setTimeout(() => { try { el.pause(); } catch (e) { /* 忽略 */ } fin(true); }, timeoutMs);
    } catch (e) { resolve(false); }
  });
}

/* 设备TTS声音列表（Chrome/安卓异步加载，监听 voiceschanged） */
let ttsVoices = [];
let voicePollTimer = null;
function refreshTTSVoices() {
  if (!ttsSupported()) return;
  try {
    const v = window.speechSynthesis.getVoices();
    if (v && v.length) {
      ttsVoices = v;   // 拿到声音了,停掉轮询
      if (voicePollTimer && typeof clearInterval === 'function') { clearInterval(voicePollTimer); voicePollTimer = null; }
      return;
    }
  } catch (e) { return; }
  /* 部分安卓机声音加载完成也不触发 voiceschanged 事件:轮询兜底(约 5 秒) */
  if (typeof setInterval === 'function' && !voicePollTimer) {
    let tries = 0;
    voicePollTimer = setInterval(() => {
      try {
        const v = window.speechSynthesis.getVoices();
        if (v && v.length) {
          ttsVoices = v;
          clearInterval(voicePollTimer);
          voicePollTimer = null;
          if (typeof renderVoiceSettings === 'function') renderVoiceSettings();   // 停在设置页则重渲染下拉
        } else if (++tries >= 12) {
          clearInterval(voicePollTimer);
          voicePollTimer = null;
        }
      } catch (e) {
        clearInterval(voicePollTimer);
        voicePollTimer = null;
      }
    }, 400);
  }
}
if (typeof window !== 'undefined' && ttsSupported()) {
  refreshTTSVoices();
  try {
    if (window.speechSynthesis.addEventListener) {
      window.speechSynthesis.addEventListener('voiceschanged', refreshTTSVoices);
    } else if ('onvoiceschanged' in window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = refreshTTSVoices;
    }
  } catch (e) { /* 忽略 */ }
}

/* 按设置解析声音：显式指定的名字优先，其次按语言自动优选 */
function resolveTTSVoice(name, lang) {
  refreshTTSVoices();
  if (name) {
    const hit = ttsVoices.find(v => v.name === name);
    if (hit) return hit;
  }
  return pickBestTTSVoice(ttsVoices, lang);
}

/* 单词播报（火后不理）：Edge 朗读（若启用）→ 设备TTS */
function speakWord(word, rate) {
  unlockPlayback();
  speakTextFireForget(word, 'en-US', rate || 0.9);
}

async function speakTextFireForget(text, lang, rate) {
  const epoch = speakEpoch;
  const edgeRes = await edgePlayAwait(text, lang, rate);
  if (edgeRes === true || edgeRes === 'x') return;
  if (epoch !== speakEpoch) return;   // 期间被停止，别再从降级层冒声
  if (/^zh/.test(lang)) {
    await speakAwait(text, lang, rate);
  } else {
    speakWordTTS(text);
  }
}

/* 设备TTS播单词（原 speechSynthesis 逻辑 + 声音优选） */
function speakWordTTS(word) {
  if (!ttsSupported()) return;
  unlockTTS();
  try {
    const synth = window.speechSynthesis;
    if (synth.speaking || synth.pending) synth.cancel();
    const u = new SpeechSynthesisUtterance(word);
    u.lang = 'en-US';
    const v = resolveTTSVoice(state.settings.ttsEngVoiceName, 'en-US');
    if (v) { u.voice = v; u.lang = v.lang; }
    u.rate = 0.9;
    let started = false;
    u.onstart = () => { started = true; };
    u.onerror = () => { started = true; };   // 出错也算已处理，避免无意义重试
    synth.speak(u);
    setTimeout(() => {
      try {
        if (!started && !synth.speaking) synth.speak(u);
      } catch (e) { /* 忽略 */ }
    }, 250);
  } catch (e) { /* 不支持则静默跳过 */ }
}

function speakCurrent() {
  if (session && session.q && session.q.speakWord) speakWord(session.q.speakWord);
}

function showWrongFeedback(word, wrongText) {
  const el = document.getElementById(session.mode === 'study' ? 'studyQuiz' : 'reviewQuiz');
  const fb = document.getElementById('feedbackZone');
  const inBook = curWords()[word] && curWords()[word].inBook;
  const def = WORD_MAP.get(word);

  // 选错选项的翻译提示（英译汉：选项是中文释义 → 反查提示它的英文单词）
  let wrongHint = '';
  if (wrongText) {
    const foundWord = reverseDefToWord(wrongText, word);
    if (foundWord) wrongHint = `<div class="wrong-hint">「${escapeHtml(wrongText)}」的英语是：${escapeHtml(foundWord)}</div>`;
  }

  // 其余错误选项可点看对应单词（点「不会」没有选错项，全部干扰项都可点）
  const chips = session.q && session.q.type === '英译汉'
    ? session.q.options.map((o, i) => ({ text: o.text, isAnswer: o.isAnswer, i }))
        .filter(o => !o.isAnswer && o.text !== wrongText)
    : [];
  const chipsHtml = chips.length ? `
    <div class="def-chips">${chips.map(o =>
      `<button class="def-chip" onclick="toggleDefChip(this, ${o.i})">${icon('eye')} ${escapeHtml(o.text)}</button>`
    ).join('')}</div>` : '';

  const card = fb.closest('.quiz-card');
  if (card) card.classList.add('with-ans');
  fb.innerHTML = `
    <div class="feedback bad">
      <div class="fb-title">${icon('circle-x')} 答错了，稍后会再考你</div>
      <div class="wrong-pair">
        <span class="wp-ans">${escapeHtml(word)}</span>
        <span class="wp-def">${escapeHtml(def)}</span>
      </div>
      ${wrongHint}
      ${chipsHtml}
      ${memoOf(word) ? `<div class="wrong-memo">${icon('lightbulb')} ${escapeHtml(memoOf(word))}</div>` : ''}
    </div>
    <div class="wrong-actions">
      <button class="book-toggle ${inBook ? 'in-book' : ''}" id="wrongBookBtn" onclick="toggleWrongBook('${escapeAttr(word)}')">
        ${inBook ? icon('bookmark-check') + ' 已在生词本' : icon('bookmark-plus') + ' 加入生词本'}
      </button>
      <button class="next-btn" onclick="advanceAfterWrong()">下一个 →</button>
    </div>
  `;
  el.querySelectorAll('.opt').forEach(b => b.disabled = true);
}

/* 点错误选项标签 → 展开该选项释义对应的英文单词（再点收起） */
function toggleDefChip(btn, optIdx) {
  if (!session || !session.q || !session.q.options[optIdx]) return;
  const def = session.q.options[optIdx].text;
  const wrap = btn.closest('.def-chips');
  const card = btn.closest('.feedback');
  if (!wrap || !card) return;
  card.querySelectorAll('.def-chip-ans').forEach(x => x.remove());
  const opened = btn.dataset.open === '1';
  wrap.querySelectorAll('.def-chip').forEach(b => b.dataset.open = '');
  if (opened) return;   // 再点同一个 = 收起
  btn.dataset.open = '1';
  const w = reverseDefToWord(def, session.word);
  const div = document.createElement('div');
  div.className = 'def-chip-ans';
  div.textContent = '「' + def + '」的英语是：' + (w || '（词库中未找到）');
  wrap.parentNode.insertBefore(div, wrap.nextSibling);
}

function toggleWrongBook(word) {
  toggleBook(word);
  const inBook = curWords()[word] && curWords()[word].inBook;
  const b = document.getElementById('wrongBookBtn');
  if (b) {
    b.innerHTML = inBook ? icon('bookmark-check') + ' 已在生词本' : icon('bookmark-plus') + ' 加入生词本';
    b.classList.toggle('in-book', inBook);
  }
}

function advanceAfterWrong() {
  session.answered = false;
  renderStudyRecognize();
}

function showAnswer() {
  if (session.answered) return;
  session.answered = true;
  const word = session.word;
  const rec = session.records.get(word) || makeRecord();
  rec.errors++;
  rec.corrects = 0;
  session.records.set(word, rec);
  session.wrong++;
  if (session.mode === 'study') noteWrong(word, false);
  else reviewWrong(word, false);
  addToRetries(word);
  session.sinceRetry = 0;  // 点「不会」同答错，重新开始穿插计数
  saveSessionSnapshot();
  showWrongFeedback(word);
}

/* 队列辅助 */
function addToRetries(word) {
  // 答错的词：从 pending 移出（不再作为"新词一次即过"），进入 retries 重记
  if (session.pending) session.pending = session.pending.filter(w => w !== word);
  if (!session.retries) session.retries = [];
  if (!session.retries.includes(word)) session.retries.push(word);
}
function removeFromQueue(word) {
  if (session.pending) session.pending = session.pending.filter(w => w !== word);
  if (session.retries) session.retries = session.retries.filter(w => w !== word);
}

/* ---------- 拼写询问（可选） ---------- */
function spellAskHtml() {
  const elId = session.mode === 'study' ? 'studyQuiz' : 'reviewQuiz';
  const total = session.queue.length;
  const hard = session.queue.filter(w => (session.records.get(w) || {}).errors > 0).length;
  const btn = session.mode === 'study' ? '开始拼写' : '开始拼写';
  return `
    <div class="quiz-card session-done">
      <div class="icon">${icon("keyboard")}</div>
      <h2>识别完成！</h2>
      <p>共 ${total} 词 · 答错 ${session.wrong} · ${hard} 个需重记</p>
      <p style="margin-top:6px;font-size:14px;color:var(--ink-soft)">要不要基于刚才的单词练习拼写？可跳过。</p>
      <div class="modal-btns" style="max-width:320px;margin:0 auto;flex-direction:column;gap:10px">
        <button class="next-btn" onclick="startSpellStage()">${icon('keyboard')} ${btn}</button>
        <button class="btn-ghost" onclick="finishSession()">跳过，直接完成</button>
      </div>
    </div>
  `;
}

function startSpellStage() {
  session.spellOn = true;
  session.phase = 'spell';
  session.idx = 0;
  renderSpellStage();
}

function renderSpellStage() {
  const el = document.getElementById(session.mode === 'study' ? 'studyQuiz' : 'reviewQuiz');
  const remaining = session.queue.filter(w => {
    const rec = session.records.get(w) || makeRecord();
    return !rec.done;
  });
  if (!remaining.length) {
    el.innerHTML = doneHtml();
    return;
  }
  // 拼写错词穿插：与识别阶段一致，每拼 RETRY_INTERVAL 个词穿插重现 1 个拼写错词
  if (session.spellRetries) {
    session.spellRetries = session.spellRetries.filter(w => !(session.records.get(w) || makeRecord()).done);
  }
  const spellRetries = session.spellRetries || [];
  let word;
  if (spellRetries.length && (session.sinceSpellRetry || 0) >= RETRY_INTERVAL) {
    word = spellRetries[0];
    session.sinceSpellRetry = 0;
    rotateSpellRetries();
  } else {
    // 优先出未拼错的词（拼错进池的稍后再出，避免紧跟重现）
    const fresh = remaining.filter(w => !spellRetries.includes(w));
    const pool = fresh.length ? fresh : remaining;
    word = pool[session.idx % pool.length];
    session.sinceSpellRetry = (session.sinceSpellRetry || 0) + 1;
  }
  session.word = word;
  session.answered = false;
  prefetchUpcomingAudio();
  const hint = WORD_MAP.get(word);
  el.innerHTML = `
    <div class="quiz-card">
      <span class="quiz-type">拼写</span>
      <div class="quiz-prompt small">${escapeHtml(hint)}</div>
      <div class="spell-input-wrap">
        <input type="text" id="spellInput" class="spell-input" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="输入英文单词">
        <button class="spell-check" onclick="checkSpell()">${icon('check')} 提交</button>
      </div>
      <div class="progress-line">剩余 ${remaining.length} 词　·　✓ ${session.correct} ✗ ${session.wrong}</div>
      <div id="spellFeedback"></div>
    </div>
  `;
  setTimeout(() => {
    const inp = document.getElementById('spellInput');
    if (inp) {
      inp.focus();
      inp.addEventListener('keydown', e => {
        if (e.key !== 'Enter') return;
        e.stopPropagation();  // 防止全局快捷键重复响应
        if (session.answered) {
          // 已出反馈：Enter 前进（答对→下一个；答错→下一个，错词稍后重现）
          const good = document.querySelector('#spellFeedback .feedback.good');
          if (good) nextSpell(); else advanceSpellAfterWrong();
        } else {
          checkSpell();
        }
      });
    }
  }, 120);
}

function checkSpell() {
  if (session.answered) return;
  session.answered = true;
  const word = session.word;
  const val = (document.getElementById('spellInput') && document.getElementById('spellInput').value || '').trim().toLowerCase();
  const isCorrect = val === word.toLowerCase();
  const rec = session.records.get(word) || makeRecord();

  const fbEl = document.getElementById('spellFeedback');
  if (isCorrect) {
    rec.spellCorrects = (rec.spellCorrects || 0) + 1;
    session.correct++;
    session.records.set(word, rec);
    if (rec.spellCorrects >= SPELL_REQUIRED) {
      rec.done = true;
      session.records.set(word, rec);
      // 已拼写达标 → 移出错词池（若在里面）
      if (session.spellRetries) session.spellRetries = session.spellRetries.filter(w => w !== word);
      // 识别阶段已提交学习/复习结果，拼写是纯练习，不再重复提交
      saveSessionSnapshot();
      if (state.settings.autoSpeak) speakWord(word);
      const card = fbEl.closest('.quiz-card');
      if (card) card.classList.add('with-ans');
      fbEl.innerHTML = `
        <div class="feedback good">
          <div class="fb-title">${icon('circle-check')} 拼写正确！</div>
          <div class="ans-word">${escapeHtml(word)}</div>
        </div>
        <button class="next-btn" onclick="nextSpell()">下一个 →</button>
      `;
    } else {
      if (state.settings.autoSpeak) speakWord(word);   // 第一次拼对也朗读，音形同步加深记忆
      const card = fbEl.closest('.quiz-card');
      if (card) card.classList.add('with-ans');
      saveSessionSnapshot();
      fbEl.innerHTML = `
        <div class="feedback good">
          <div class="fb-title">${icon('circle-check')} 拼写正确！再写一次加深记忆</div>
          <div class="ans-word">${escapeHtml(word)}</div>
        </div>
        <button class="next-btn" onclick="nextSpell()">下一个 →</button>
      `;
    }
  } else {
    rec.spellCorrects = 0;
    rec.errors++;
    session.wrong++;
    session.records.set(word, rec);
    // 拼写是纯练习，不改学习状态（识别阶段已提交）
    // 答错不卡住：进拼写错词池，稍后穿插重现
    if (!session.spellRetries) session.spellRetries = [];
    if (!session.spellRetries.includes(word)) session.spellRetries.push(word);
    session.sinceSpellRetry = 0;  // 答错后重新计数，避免错词紧跟重现
    if (state.settings.autoSpeak) speakWord(word);   // 拼错朗读正确发音，对照反馈听音纠错
    saveSessionSnapshot();
    const inBook = curWords()[word] && curWords()[word].inBook;
    const card = fbEl.closest('.quiz-card');
    if (card) card.classList.add('with-ans');
    fbEl.innerHTML = `
      <div class="feedback bad">
        <div class="fb-title">${icon('circle-x')} 拼错了，稍后会再考你</div>
        <div class="wrong-pair">
          <span class="wp-ans">${escapeHtml(word)}</span>
          <span class="wp-def">${escapeHtml(WORD_MAP.get(word))}</span>
        </div>
        ${memoOf(word) ? `<div class="wrong-memo">${icon('lightbulb')} ${escapeHtml(memoOf(word))}</div>` : ''}
      </div>
      <div class="wrong-actions">
        <button class="book-toggle ${inBook ? 'in-book' : ''}" id="wrongBookBtn" onclick="toggleWrongBook('${escapeAttr(word)}')">
          ${inBook ? icon('bookmark-check') + ' 已在生词本' : icon('bookmark-plus') + ' 加入生词本'}
        </button>
        <button class="next-btn" onclick="advanceSpellAfterWrong()">下一个 →</button>
      </div>
    `;
  }
}

function nextSpell() {
  session.idx++;
  renderSpellStage();
  // 全部拼完 → 清除快照（已完成）
  const remaining = session.queue.filter(w => {
    const rec = session.records.get(w) || makeRecord();
    return !rec.done;
  });
  if (!remaining.length) clearSessionSnapshot();
}
/* 拼写答错后前进：不卡住，先出下一个词，拼错的词稍后穿插重现 */
function advanceSpellAfterWrong() {
  session.idx++;
  renderSpellStage();
  const remaining = session.queue.filter(w => {
    const rec = session.records.get(w) || makeRecord();
    return !rec.done;
  });
  if (!remaining.length) clearSessionSnapshot();
}
/* 轮转拼写错词队列：把刚出题的错词移到队尾，让多个错词交替重现 */
function rotateSpellRetries() {
  if (session.spellRetries && session.spellRetries.length > 1) {
    session.spellRetries.push(session.spellRetries.shift());
  }
}

/* ---------- 完成页 ---------- */
function finishSession() {
  clearSessionSnapshot();
  const el = document.getElementById(session.mode === 'study' ? 'studyQuiz' : 'reviewQuiz');
  el.innerHTML = doneHtml();
}

function doneHtml() {
  const mode = session.mode === 'study' ? '学习' : '复习';
  const total = session.queue.length;
  const hardCount = session.queue.filter(w => (session.records.get(w) || {}).errors > 0).length;
  const g = goalInfo();
  const goalNote = session.mode === 'study' && g.done
    ? `<p class="goal-done-note">${icon('target')} 今日新学目标 ${g.target} 个已达成！明天继续坚持，复习会在明天自动出现。</p>`
    : '';
  const list = session.queue.map(w => {
    const rec = session.records.get(w) || {};
    const hard = rec.errors > 0;
    return `<div class="list-card"><div class="list-item">
      <span class="list-word">${escapeHtml(w)}</span>
      <span class="list-def">${escapeHtml(WORD_MAP.get(w) || '')}</span>
      ${hard ? '<span class="ms-badge ms-due">反复记</span>' : ''}
    </div></div>`;
  }).join('');
  return `
    <div class="quiz-card session-done" style="text-align:left">
      <div style="text-align:center">
        <div class="icon">${icon("party-popper")}</div>
        <h2>${mode}完成！</h2>
        <p>共 ${total} 词 · 答对 ${session.correct} · 答错 ${session.wrong} · ${hardCount} 个反复记忆</p>
        ${goalNote}
      </div>
      <div style="margin-top:18px">
        <h3 style="font-family:var(--serif);font-size:16px;color:var(--ink-blue);margin-bottom:10px">本次${mode}单词（${total}）</h3>
        ${list}
      </div>
      <button class="next-btn" style="max-width:320px;margin:18px auto 0" onclick="goHome()">回到首页</button>
    </div>
  `;
}

/* 点灯泡图标展开该词的巧记（生词本/掌握情况列表通用） */
function toggleMemoRow(word, btn) {
  const card = btn.closest('.list-card');
  const next = card.nextElementSibling;
  if (next && next.classList && next.classList.contains('memo-panel')) { next.remove(); return; }
  const div = document.createElement('div');
  div.className = 'memo-panel';
  div.innerHTML = icon('lightbulb') + ' ' + escapeHtml(memoOf(word));
  card.parentNode.insertBefore(div, card.nextSibling);
}

/* ============================================================
 * 自由拼写（自定义拼写练习，纯练习不改动学习进度）
 * 看释义输单词；答错不卡住直接跳过，错词每过 3 个词穿插重现，
 * 重现时答对 1 次即完成（比复习拼写的连对 2 次宽松）
 * ============================================================ */
/* 范围选择器的层级分组:组名小字+组内 chips,按语义分层(2026-10-02) */
const SCOPE_GROUPS = [
  { label: '学习进度', keys: ['all', 'unseen', 'learning', 'mastered'] },
  { label: '学习标记', keys: ['book', 'hard'] },
  { label: '按时间', keys: ['date'] },
  { label: '自选词单', keys: ['custom'] },
];

/* 范围选择器:层级分组(学习进度/学习标记/按时间/自选词单)+日期面板+选定具体单词入口。
 * 拼写/听力/快扫三方共用(数量块由 spellCfgHtml 自行追加) */
function scopeCfgHtml(kind) {
  const scopeKey = kind + 'Scope';
  const scope = normScope(state.settings[scopeKey]);
  const pickedN = practicePicked(kind).length;
  const scopeChip = (key, label, n) =>
    `<button class="master-tab ${key === scope ? 'active' : ''}" onclick="setPracticeCfg('${scopeKey}','${key}')">${label} <span class="mt-cnt">${n}</span></button>`;
  const groupRow = (g) => `<div class="cfg-scope-group"><span class="cfg-group-label">${g.label}</span><div class="cfg-chips">${
    g.keys.map(k => k === 'custom'
      ? scopeChip('custom', '自选', pickedN)
      : scopeChip(k, (SCOPES.find(s => s.key === k) || {}).label || k, wordsInScope(k, kind).length)
    ).join('')
  }</div></div>`;
  return `
    <div class="cfg-title">选择范围</div>
    ${SCOPE_GROUPS.map(groupRow).join('')}
    ${scope === 'date' ? practiceDateHtml(kind) : ''}
    <div style="margin:8px 0 4px"><button class="cfg-pick-btn" onclick="openWordPicker('${kind}')">${icon('list-plus')} 选定具体单词（当前词库：${escapeHtml(LIBS[libKey()].name)}）</button></div>
  `;
}

function spellCfgHtml(kind) {
  // kind: 'spell' | 'dict'，配置项存 settings.spellXxx / dictXxx
  const countKey = kind + 'Count';
  const count = state.settings[countKey] || 1;
  return scopeCfgHtml(kind) + `
    <div class="cfg-title">数量</div>
    <div class="set-ctrl" style="justify-content:flex-start">
      <button onclick="adjPracticeCount('${kind}',-1)">−</button>
      <input type="number" id="${kind}CountInput" class="count-input" inputmode="numeric" min="1" max="${WORD_LIST.length}"
        value="${count}" oninput="setPracticeCount('${kind}', this.value)" onchange="this.value = state.settings.${countKey}">
      <button onclick="adjPracticeCount('${kind}',1)">+</button>
    </div>
  `;
}

/* 数量自定义:任意整数,限制在 1 ~ 当前词库总词数 */
function setPracticeCount(kind, v) {
  let n = parseInt(v, 10);
  if (!isFinite(n) || n < 1) n = 1;
  if (n > WORD_LIST.length) n = WORD_LIST.length;
  state.settings[kind + 'Count'] = n;
  saveState();
  updatePracticeStartLabel(kind);
}

function adjPracticeCount(kind, delta) {
  setPracticeCount(kind, (state.settings[kind + 'Count'] || 1) + delta);
  const inp = document.getElementById(kind + 'CountInput');
  if (inp) inp.value = state.settings[kind + 'Count'];
}

/* 数量变化时就地更新开始栏词数(不重渲染配置页,避免输入框失焦) */
const PRACTICE_START_LABELS = { spell: '开始拼写', dict: '开始听写' };
function practiceStartLabel(kind) {
  return (kind === 'dict' && normDictKind(state.settings.dictKind) === 'pick')
    ? '开始听音辨义'
    : (PRACTICE_START_LABELS[kind] || '开始');
}
function updatePracticeStartLabel(kind) {
  const btn = document.getElementById(kind + 'StartBtn');
  if (!btn) return;
  const pool = practicePool(kind);
  const custom = normScope(state.settings[kind + 'Scope']) === 'custom';
  const n = custom ? pool.length : Math.min(state.settings[kind + 'Count'] || 1, pool.length);
  btn.textContent = practiceStartLabel(kind);
  btn.disabled = !pool.length;
  const cnt = document.getElementById(kind + 'FootCount');
  if (cnt) cnt.textContent = String(n);
}

/* 配置页固定开始栏:左侧实时词数,右侧开始按钮(参数改完随时能看到入口)。
 * 实际取词 = min(数量,池大小);自选范围取整个词单 */
function practiceFootHtml(kind) {
  const pool = practicePool(kind);
  const custom = normScope(state.settings[kind + 'Scope']) === 'custom';
  const n = custom ? pool.length : Math.min(state.settings[kind + 'Count'] || 1, pool.length);
  return `
    <div class="practice-foot">
      <span class="picker-count">共 <b id="${kind}FootCount">${n}</b> 词</span>
      <button class="next-btn" id="${kind}StartBtn" onclick="${kind === 'dict' ? 'startDictPractice()' : 'startCustomSpell()'}" ${pool.length ? '' : 'disabled'}>${practiceStartLabel(kind)}</button>
    </div>
  `;
}

/* 自选词单（按当前词库过滤，切词库后他库词自动忽略） */
function practicePicked(kind) {
  const list = state.settings[kind + 'Words'];
  const set = LIB_WORD_SETS[libKey()];
  return (Array.isArray(list) ? list : []).filter(w => set.has(w));
}

/* 某模式的实际取词池：自选范围用词单，其余按范围取（date 范围按各模式自己的日期） */
function practicePool(kind) {
  const scope = normScope(state.settings[kind + 'Scope']);
  if (scope === 'custom') {
    const picked = practicePicked(kind);
    return picked.length ? picked : [];
  }
  return wordsInScope(scope, kind);
}

/* 按练习模式把配置页渲染回各自容器(spell/dict 共用配置组件的调度中枢)。
 * 注意:key 缺省落 dict——拼写/听力之外的配置键都是听写专属(dictMode/dictPause 等) */
function renderPracticeConfig(kind) {
  if (kind === 'dict') renderDictConfig();
  else if (kind === 'quick') renderQuickConfig();
  else renderSpellConfig();
}

function setPracticeCfg(key, val) {
  state.settings[key] = val;
  // 切到「按日期」且还没选过日期：默认昨天；月历回到今天所在月
  const dateKey2 = key.replace('Scope', 'Date');
  if (val === 'date') {
    if (!state.settings[dateKey2]) state.settings[dateKey2] = dateKey(Date.now() - DAY_MS);
    calY = null;
    calM = null;
  }
  saveState();
  // 拼写专属键以 spell 开头、快扫键以 quick 开头,其余(含 dict*)归听写页
  renderPracticeConfig(key.startsWith('spell') ? 'spell' : key.startsWith('quick') ? 'quick' : 'dict');
}

/* 「按日期」范围：紧凑两块——
 * ① 日期按钮(中文日期+系统日历) + 锚点提示(当天第一个新学的词帮认日子)
 * ② 可翻页月历：学过词的日子高亮底色，‹ › 无限回翻(history 永久保留)，点任意一天即选中。
 *    原生日历无法做学过/没学过的标注，月历就是「查看哪天学过」的载体 */
let calY = null, calM = null;   // 月历浏览的年月(null = 今天所在月)

function calShift(kind, delta) {
  // 只能回翻历史;已在当前月时禁止再往后(与月历禁未来日期一致)
  if (delta > 0) {
    const t = new Date();
    if (calY === t.getFullYear() && calM >= t.getMonth()) return;
    if (calY > t.getFullYear()) return;
  }
  const base = (calY === null) ? new Date() : new Date(calY, calM, 1);
  const d = new Date(base.getFullYear(), base.getMonth() + delta, 1);
  calY = d.getFullYear();
  calM = d.getMonth();
  renderPracticeConfig(kind);
}

function practiceDateHtml(kind) {
  const cur = state.settings[kind + 'Date'] || '';
  const words = wordsTouchedOn(cur);
  const cnt = dayTouchCounts(cur);
  const fmt = (dk) => {
    const p = (dk || '').split('-');
    return p.length === 3 ? `${+p[1]}月${+p[2]}日` : '选择日期';
  };
  // 当天有学过(新学/复习/答错)就给分项统计,首词做认日子的锚点
  const parts = [];
  if (cnt.learned) parts.push('新学 ' + cnt.learned);
  if (cnt.reviewed) parts.push('复习 ' + cnt.reviewed);
  if (cnt.wrongs) parts.push('答错 ' + cnt.wrongs);
  const info = !cur ? '未选择日期'
    : parts.length ? `当天 ${parts.join(' · ')} · 从 ${words[0]} 开始`
    : '该日无学习记录';
  if (calY === null) {
    const t = new Date();
    calY = t.getFullYear();
    calM = t.getMonth();
  }
  const firstWd = new Date(calY, calM, 1).getDay();          // 1 号是周几(0=日)
  const daysInMonth = new Date(calY, calM + 1, 0).getDate();
  const today = dateKey();
  let cells = '';
  for (let i = 0; i < firstWd; i++) cells += '<span></span>';
  for (let d = 1; d <= daysInMonth; d++) {
    const dk = dateKey(new Date(calY, calM, d));
    const future = dk > today;                               // 未来日期禁点(与原生日历 max 一致)
    const n = future ? 0 : wordsTouchedOn(dk).length;
    cells += `<button type="button" class="cfg-cal-day ${n ? 'has' : ''} ${dk === cur ? 'sel' : ''} ${future ? 'dis' : ''}" title="${future ? '未来日期' : (n ? n + ' 词' : '无记录')}" ${future ? 'disabled' : `onclick="setPracticeDate('${kind}','${dk}')"`}>${d}</button>`;
  }
  const wd = ['日', '一', '二', '三', '四', '五', '六'].map(w => `<span class="cfg-cal-wd">${w}</span>`).join('');
  const now = new Date();
  const nextOff = calY > now.getFullYear() || (calY === now.getFullYear() && calM >= now.getMonth());
  // 当天内容分类(第二级筛选):全部=新学+复习+答错合并,单选,各模式独立记忆
  const catNow = practiceDateCatOf(kind);
  const catChip = (key, label, n) =>
    `<button class="master-tab ${key === catNow ? 'active' : ''}" onclick="setPracticeCfg('${kind}DateCat','${key}')">${label} <span class="mt-cnt">${n}</span></button>`;
  return `
    <div class="cfg-title">选择日期 <span class="mt-cnt">高亮 = 有学习记录的日子</span></div>
    <div class="cfg-date-row">
      <span class="cfg-date-btn">
        <input type="date" class="cfg-date-input" value="${escapeHtml(cur)}" max="${today}" aria-label="选择日期" onchange="setPracticeDate('${kind}', this.value)">
        <span class="cfg-date-label">${fmt(cur)} ${icon('chevron-left')}</span>
      </span>
      <span class="cfg-date-info">${escapeHtml(info)}</span>
    </div>
    <div class="cfg-scope-group" style="margin:10px 0 8px">
      <span class="cfg-group-label">当天内容</span>
      <div class="cfg-chips">
        ${catChip('all', '全部', words.length)}
        ${catChip('learn', '新学', cnt.learned)}
        ${catChip('review', '复习', cnt.reviewed)}
        ${catChip('wrong', '答错', cnt.wrongs)}
      </div>
    </div>
    <div class="cfg-cal">
      <div class="cfg-cal-head">
        <button type="button" class="cfg-cal-nav" aria-label="上个月" onclick="calShift('${kind}',-1)">${icon('chevron-left')}</button>
        <span class="cfg-cal-title">${calY}年${calM + 1}月</span>
        <button type="button" class="cfg-cal-nav next" aria-label="下个月" onclick="calShift('${kind}',1)" ${nextOff ? 'disabled' : ''}>${icon('chevron-left')}</button>
      </div>
      <div class="cfg-cal-grid">${wd}${cells}</div>
    </div>
  `;
}

/* 选日期：只接受 YYYY-MM-DD；清空/非法值忽略，保留原选择。
 * 选中后月历跟到该日期所在月(含原生日历跳到很早的日期的情况) */
function setPracticeDate(kind, v) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v || '')) return;
  if (v > dateKey()) return;   // 不收未来日期(与月历禁点、原生日历 max 一致)
  state.settings[kind + 'Date'] = v;
  const dt = new Date(v + 'T00:00:00');
  calY = dt.getFullYear();
  calM = dt.getMonth();
  saveState();
  renderPracticeConfig(kind);
}

/* 配置页空池提示：按范围给针对性文案 */
function practiceEmptyHtml(kind) {
  const scope = normScope(state.settings[kind + 'Scope']);
  if (scope === 'custom') return '<div class="empty-tip" style="padding:20px 0">词单还是空的，点上面「选定具体单词」去勾选</div>';
  if (scope === 'date') return '<div class="empty-tip" style="padding:20px 0">选定的日期没有符合条件的单词，换个内容类型、换一天或换个范围试试</div>';
  return '<div class="empty-tip" style="padding:20px 0">该范围暂无单词</div>';
}

function renderSpellConfig() {
  const el = document.getElementById('spellQuiz');
  if (!el) return;
  const pool = practicePool('spell');
  el.innerHTML = `
    <div class="quiz-card" style="text-align:left;margin-bottom:100px">
      <span class="quiz-type">${icon('pencil-line')} 自由拼写</span>
      <p class="cfg-note">看释义拼写单词，答错不卡住、稍后穿插重现；纯练习，不影响学习进度。</p>
      ${spellCfgHtml('spell')}
      ${pool.length ? '' : practiceEmptyHtml('spell')}
    </div>
    ${practiceFootHtml('spell')}
  `;
}

function startCustomSpell() {
  const pool = practicePool('spell');
  if (!pool.length) return;
  const custom = normScope(state.settings.spellScope) === 'custom';
  // 自选词单：全部采用（顺序随机）；其他范围：按数量抽选
  const picked = custom ? shuffle(pool) : pickRandom(pool, Math.min(state.settings.spellCount || 20, pool.length));
  session = {
    mode: 'spell',
    phase: 'cspell',          // 避开全局快捷键对复习拼写阶段的接管
    queue: picked,
    spellRetries: [],
    sinceSpellRetry: 0,
    idx: 0,
    correct: 0, wrong: 0,
    records: new Map(picked.map(w => [w, makeRecord()])),
  };
  renderCustomSpell();
}

function renderCustomSpell() {
  const el = document.getElementById('spellQuiz');
  const remaining = session.queue.filter(w => !(session.records.get(w) || makeRecord()).done);
  if (!remaining.length) {
    el.innerHTML = practiceDoneHtml('拼写练习', '自由拼写');
    return;
  }
  session.spellRetries = (session.spellRetries || []).filter(w => !(session.records.get(w) || makeRecord()).done);
  const spellRetries = session.spellRetries;
  let word;
  if (spellRetries.length && (session.sinceSpellRetry || 0) >= RETRY_INTERVAL) {
    word = spellRetries[0];
    session.sinceSpellRetry = 0;
    rotateSpellRetries();
  } else {
    const fresh = remaining.filter(w => !spellRetries.includes(w));
    const pool2 = fresh.length ? fresh : remaining;
    word = pool2[session.idx % pool2.length];
    session.sinceSpellRetry = (session.sinceSpellRetry || 0) + 1;
  }
  session.word = word;
  session.answered = false;
  prefetchUpcomingAudio();
  const rec = session.records.get(word) || makeRecord();
  const retryNote = rec.errors > 0 ? `<div class="retry-note">重记词 · 答对 1 次即完成</div>` : '';
  el.innerHTML = `
    <div class="quiz-card">
      <span class="quiz-type">${icon('pencil-line')} 自由拼写</span>
      <div class="quiz-prompt small">${escapeHtml(WORD_MAP.get(word) || '')}</div>
      <div class="spell-input-wrap">
        <input type="text" id="spellInput" class="spell-input" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="输入英文单词">
        <button class="spell-check" onclick="customSpellCheck()">${icon('check')} 提交</button>
      </div>
      <div class="progress-line">剩余 ${remaining.length} 词　·　✓ ${session.correct} ✗ ${session.wrong}</div>
      ${retryNote}
      <div id="spellFeedback"></div>
    </div>
  `;
  setTimeout(() => {
    const inp = document.getElementById('spellInput');
    if (inp) {
      inp.focus();
      inp.addEventListener('keydown', e => {
        if (e.key !== 'Enter') return;
        e.stopPropagation();
        if (session.answered) customSpellNext(); else customSpellCheck();
      });
    }
  }, 120);
}

function customSpellCheck() {
  if (session.answered) return;
  session.answered = true;
  const word = session.word;
  const val = ((document.getElementById('spellInput') && document.getElementById('spellInput').value) || '').trim().toLowerCase();
  const isCorrect = val === word.toLowerCase();
  const rec = session.records.get(word) || makeRecord();
  const fbEl = document.getElementById('spellFeedback');
  const card = fbEl.closest('.quiz-card');
  if (card) card.classList.add('with-ans');
  const inBook = curWords()[word] && curWords()[word].inBook;
  if (isCorrect) {
    rec.done = true;   // 宽松规则:重现后答对 1 次即完成
    session.records.set(word, rec);
    session.correct++;
    session.spellRetries = (session.spellRetries || []).filter(w => w !== word);
    if (state.settings.autoSpeak) speakWord(word);
    fbEl.innerHTML = `
      <div class="feedback good">
        <div class="fb-title">${icon('circle-check')} 拼写正确！</div>
        <div class="ans-word">${escapeHtml(word)}</div>
        <div class="ans-def">${escapeHtml(WORD_MAP.get(word) || '')}</div>
      </div>
      <button class="next-btn" onclick="customSpellNext()">下一个 →</button>
    `;
  } else {
    rec.errors++;
    session.wrong++;
    session.records.set(word, rec);
    if (!session.spellRetries) session.spellRetries = [];
    if (!session.spellRetries.includes(word)) session.spellRetries.push(word);
    session.sinceSpellRetry = 0;
    if (state.settings.autoSpeak) speakWord(word);   // 拼错朗读正确发音
    fbEl.innerHTML = `
      <div class="feedback bad">
        <div class="fb-title">${icon('circle-x')} 拼错了，过几个词再考你</div>
        <div class="wrong-pair">
          <span class="wp-ans">${escapeHtml(word)}</span>
          <span class="wp-def">${escapeHtml(WORD_MAP.get(word) || '')}</span>
        </div>
        ${memoOf(word) ? `<div class="wrong-memo">${icon('lightbulb')} ${escapeHtml(memoOf(word))}</div>` : ''}
      </div>
      <div class="wrong-actions">
        <button class="book-toggle ${inBook ? 'in-book' : ''}" id="wrongBookBtn" onclick="toggleWrongBook('${escapeAttr(word)}')">
          ${inBook ? icon('bookmark-check') + ' 已在生词本' : icon('bookmark-plus') + ' 加入生词本'}
        </button>
        <button class="next-btn" onclick="customSpellNext()">下一个 →</button>
      </div>
    `;
  }
}

function customSpellNext() {
  session.answered = false;
  session.idx++;
  renderCustomSpell();
}

/* 练习完成页（自由拼写 / 听写共用；纯练习不写学习状态） */
function practiceDoneHtml(title, typeName) {
  practiceMode = session.mode === 'spell' ? 'spell' : 'dict';
  const total = session.queue.length;
  const hard = session.queue.filter(w => (session.records.get(w) || {}).errors > 0).length;
  const list = session.queue.map(w => {
    const err = (session.records.get(w) || {}).errors > 0;
    return `<div class="list-card"><div class="list-item">
      <span class="list-word">${escapeHtml(w)}</span>
      <span class="list-def">${escapeHtml(WORD_MAP.get(w) || '')}</span>
      ${err ? '<span class="ms-badge ms-due">曾出错</span>' : ''}
    </div></div>`;
  }).join('');
  return `
    <div class="quiz-card session-done" style="text-align:left">
      <div style="text-align:center">
        <div class="icon">${icon('trophy')}</div>
        <h2>${title}完成！</h2>
        <p>共 ${total} 词 · 答对 ${session.correct} · 答错 ${session.wrong} · ${hard} 个曾出错</p>
      </div>
      <div style="margin-top:18px">
        <h3 style="font-family:var(--serif);font-size:16px;color:var(--ink-blue);margin-bottom:10px">本次${typeName}单词（${total}）</h3>
        ${list}
      </div>
      <div class="modal-btns" style="max-width:320px;margin:18px auto 0;flex-direction:column;gap:10px">
        <button class="next-btn" onclick="practiceAgain()">再来一组</button>
        <button class="btn-ghost" onclick="goHome()">回到首页</button>
      </div>
    </div>
  `;
}

/* 练习完成页「再来一组」：回到本次练习模式（spell/dict）的配置页(听音辨义也归听力练习页) */
let practiceMode = 'spell';
const PRACTICE_SCREENS = { spell: 'screen-spell', dict: 'screen-dictate', quick: 'screen-quick' };
function practiceAgain() {
  go(PRACTICE_SCREENS[practiceMode] || 'screen-spell');
}

/* ---------------- 自选词单选词器(自由拼写/听写共用) ----------------
 * 搜索 + 按范围筛选 + 点行勾选;词单存 settings.spellWords/dictWords,按当前词库过滤生效
 */
let pickerKind = null;      // 'spell' | 'dict'
let pickerOpen = false;     // 选词器是否打开:决定顶栏返回箭头回配置页还是主菜单
let pickerSearch = '';
let pickerFilter = 'all';   // SCOPES key | 'picked'
let pickerLimit = 100;

function openWordPicker(kind) {
  pickerKind = kind;
  pickerOpen = true;
  pickerSearch = '';
  // 带入配置页已选的范围:外面筛了哪类,进来就直接列哪类(自选→已选),不用再筛一遍
  const scope = normScope(state.settings[kind + 'Scope']);
  pickerFilter = scope === 'custom' ? 'picked' : scope;
  pickerLimit = 100;
  renderWordPicker();
  document.getElementById('topTitle').textContent = '选定单词';
}

function pickerPool() {
  let words;
  if (pickerFilter === 'picked') words = practicePicked(pickerKind);
  else if (pickerFilter !== 'all') words = wordsInScope(pickerFilter, pickerKind);
  else words = WORD_LIST.slice();
  const q = pickerSearch.toLowerCase();
  if (q) {
    words = words.filter(w => w.toLowerCase().includes(q) || (WORD_MAP.get(w) || '').toLowerCase().includes(q));
  }
  return words;
}

function renderWordPicker() {
  const el = document.getElementById(pickerKind + 'Quiz');
  if (!el || !pickerKind) return;
  const picked = practicePicked(pickerKind);
  const pickedSet = new Set(picked);
  const words = pickerPool();
  const shown = words.slice(0, pickerLimit);
  const rows = shown.map(w => {
    const sel = pickedSet.has(w);
    return `<div class="list-card picker-row ${sel ? 'picked' : ''}" data-w="${escapeHtml(w)}" onclick="pickerToggleWord('${escapeAttr(w)}', this)">
      <div class="list-item">
        <span class="list-word">${escapeHtml(w)}</span>
        <span class="list-def">${escapeHtml(WORD_MAP.get(w) || '')}</span>
        <span class="pick-check">${icon(sel ? 'circle-check' : 'circle')}</span>
      </div>
    </div>`;
  }).join('');
  const moreBtn = words.length > shown.length
    ? `<div style="text-align:center;margin:10px 0"><button class="toolbar-btn" onclick="pickerLimit += 200; renderWordPicker()">显示更多（还有 ${words.length - shown.length} 个）</button></div>`
    : '';
  el.innerHTML = `
    <div class="quiz-card" style="text-align:left">
      <span class="quiz-type">${icon('list-plus')} 选定单词</span>
      <p class="cfg-note">点行勾选/取消；<b>长按一行后往下拖</b>可连续选（拖过已选的则连续取消）；词单按当前词库（${escapeHtml(LIBS[libKey()].name)}）保存，切词库后他库词不参与。</p>
      <div class="picker-head">
        <div class="master-search-wrap"><input id="pickerSearchInput" class="master-search" placeholder="搜索单词或释义…" value="${escapeHtml(pickerSearch)}" oninput="onPickerSearch(this.value)"></div>
        <div class="cfg-chips">${SCOPES.map(s =>
          `<button class="master-tab ${pickerFilter === s.key ? 'active' : ''}" onclick="setPickerFilter('${s.key}')">${s.label}</button>`
        ).join('')}<button class="master-tab ${pickerFilter === 'picked' ? 'active' : ''}" onclick="setPickerFilter('picked')">已选 ${picked.length}</button></div>
      </div>
      <div id="pickerList">${rows || '<div class="empty-tip" style="padding:24px 0">没有匹配的单词</div>'}${moreBtn}</div>
    </div>
    <div class="picker-foot">
      <span class="picker-count">已选 <b id="pickerCount">${picked.length}</b> 个</span>
      <button class="btn-ghost" onclick="pickerSelectAll()">全选</button>
      <button class="btn-ghost" onclick="pickerClear()">清空</button>
      <button class="next-btn" onclick="pickerDone()">完成</button>
    </div>
  `;
  attachPickerGestures(el);
}

/* ---------------- 长按拖动连续选择 ----------------
 * 长按一行(350ms)进入连续模式:以该行的反向状态为基准,手指滑过哪些行就统一设成该状态;
 * 拖到屏幕上/下边缘时列表自动滚屏(越贴边越快),手指不动行也会从指下滑过并保持选中,
 * 拖到底自动加载下一批——一路拖到底可连选整个词库。松手结束,点按仍是单个切换。
 * 事件委托挂在选词器容器上:重渲染列表(加载更多)不丢监听、不打断进行中的拖选。
 */
let pickerDrag = null;        // {x0,y0 起点 | x,y 手指当前坐标 | apply 目标状态 | active 连选中}
let pickerDragTimer = null;
let pickerSuppressClick = false;
let pickerRaf = 0;
const PICKER_EDGE = 90;       // 距屏幕上/下边缘多少像素内触发自动滚屏

function attachPickerGestures(el) {
  if (!el || el._pickerGestures) return;
  el._pickerGestures = true;
  el.addEventListener('pointerdown', e => {
    const row = e.target.closest('.picker-row');
    if (!row || !row.dataset.w) return;
    pickerDrag = { x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY, apply: !pickerRowPicked(row), active: false };
    pickerDragTimer = setTimeout(() => {
      if (!pickerDrag) return;
      pickerDrag.active = true;
      pickerSuppressClick = true;   // 长按松手后的 click 不再当点按处理
      pickerApplyRow(row, pickerDrag.apply);
      if (navigator.vibrate) { try { navigator.vibrate(15); } catch (err) { /* 忽略 */ } }
      pickerStartAutoScroll();
    }, 350);
  });
  el.addEventListener('pointermove', e => {
    if (!pickerDrag) return;
    pickerDrag.x = e.clientX;
    pickerDrag.y = e.clientY;
    if (!pickerDrag.active) {
      // 长按前就移动(滚动列表)→ 取消长按计时
      if (Math.abs(e.clientY - pickerDrag.y0) > 10) {
        clearTimeout(pickerDragTimer);
        pickerDrag = null;
      }
      return;
    }
    pickerApplyAtPoint();
  });
  const endDrag = () => { clearTimeout(pickerDragTimer); pickerDrag = null; pickerStopAutoScroll(); };
  // 连续模式期间阻止原生滚动(手指当画笔用,滚屏由边缘自动滚屏接管)
  el.addEventListener('touchmove', e => { if (pickerDrag && pickerDrag.active) e.preventDefault(); }, { passive: false });
  el.addEventListener('contextmenu', e => { if (pickerDrag && pickerDrag.active) e.preventDefault(); });
  // 长按后松手的那次 click 不当点按处理
  el.addEventListener('click', e => {
    if (pickerSuppressClick) {
      pickerSuppressClick = false;
      e.stopPropagation();
      e.preventDefault();
    }
  }, true);
  // 松手可能发生在容器外(顶栏等),挂 document 保证拖选一定结束
  document.addEventListener('pointerup', endDrag);
  document.addEventListener('pointercancel', endDrag);
}

/* 手指当前坐标处的行应用目标状态。手指压在吸顶头/固定底栏上时,
 * 采样点投影到列表可见带内——贴边自动滚屏时行从指下穿过也能被选中 */
function pickerSampleRow(x, y) {
  if (!document.elementFromPoint) return null;
  const probe = (px, py) => {
    const el = document.elementFromPoint(px, py);
    return (el && el.closest) ? el.closest('.picker-row') : null;
  };
  let row = probe(x, y);
  if (row) return row;
  const head = document.querySelector('.picker-head');
  const foot = document.querySelector('.picker-foot');
  const top = head ? head.getBoundingClientRect().bottom + 8 : 0;
  const bottom = foot ? foot.getBoundingClientRect().top - 8 : window.innerHeight;
  if (bottom <= top) return null;
  return probe(x, Math.min(bottom, Math.max(top, y)));
}

function pickerApplyAtPoint() {
  if (!pickerDrag || !pickerDrag.active) return;
  const row = pickerSampleRow(pickerDrag.x, pickerDrag.y);
  if (row && row.dataset.w) pickerApplyRow(row, pickerDrag.apply);
}

/* 纯函数:手指 y 坐标 → 自动滚屏速度(px/帧)。负=向上滚,正=向下滚,中段 0,越贴边越快 */
function pickerAutoScrollSpeed(y, viewportH, edge) {
  edge = edge || PICKER_EDGE;
  if (y < edge) return -(2 + 12 * (1 - y / edge));
  const gap = viewportH - y;
  if (gap < edge) return 2 + 12 * (1 - gap / edge);
  return 0;
}

/* 单帧自动滚屏:滚活动屏;向下拖到列表尽头自动加载下一批;返回是否发生了滚动 */
function pickerAutoScrollStep(sc) {
  if (!pickerDrag || !pickerDrag.active || !sc) return false;
  const v = pickerAutoScrollSpeed(pickerDrag.y, window.innerHeight);
  if (v === 0) return false;
  sc.scrollTop += v;
  if (v > 0 && sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 2) {
    const total = pickerPool().length;
    if (pickerLimit < total) pickerLimit = Math.min(total, pickerLimit + 200);
  }
  pickerApplyAtPoint();
  return true;
}

function pickerStartAutoScroll() {
  if (pickerRaf) return;
  const step = () => {
    if (!pickerDrag || !pickerDrag.active) { pickerRaf = 0; return; }
    pickerAutoScrollStep(document.querySelector('.screen.active'));
    pickerRaf = requestAnimationFrame(step);
  };
  pickerRaf = requestAnimationFrame(step);
}

function pickerStopAutoScroll() {
  if (pickerRaf) { cancelAnimationFrame(pickerRaf); pickerRaf = 0; }
}

function pickerRowPicked(row) {
  const list = state.settings[pickerKind + 'Words'];
  return !!(Array.isArray(list) && list.includes(row.dataset.w));
}

/* 连续模式下把一行设成目标状态(与当前状态不同才切换,复用单个切换逻辑) */
function pickerApplyRow(row, pick) {
  if (pickerRowPicked(row) !== pick) pickerToggleWord(row.dataset.w, row);
}

function onPickerSearch(v) {
  pickerSearch = v.trim();
  pickerLimit = 100;
  renderWordPicker();
  // 重渲染会重建输入框，恢复焦点和光标位置
  const inp = document.getElementById('pickerSearchInput');
  if (inp) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
}

function setPickerFilter(f) { pickerFilter = f; pickerLimit = 100; renderWordPicker(); }

function pickerToggleWord(w, rowEl) {
  const key = pickerKind + 'Words';
  if (!Array.isArray(state.settings[key])) state.settings[key] = [];
  const list = state.settings[key];
  const i = list.indexOf(w);
  const nowPicked = i < 0;
  if (nowPicked) list.push(w); else list.splice(i, 1);
  saveState();
  // 就地更新行样式与计数，不整页重渲染（保住滚动位置）
  if (rowEl) {
    rowEl.classList.toggle('picked', nowPicked);
    const chk = rowEl.querySelector('.pick-check');
    if (chk) chk.innerHTML = icon(nowPicked ? 'circle-check' : 'circle');
  }
  const cnt = document.getElementById('pickerCount');
  if (cnt) cnt.textContent = practicePicked(pickerKind).length;
  // 「已选」筛选下取消勾选 → 直接移除该行
  if (pickerFilter === 'picked' && !nowPicked && rowEl) rowEl.remove();
}

function pickerClear() {
  state.settings[pickerKind + 'Words'] = [];
  saveState();
  renderWordPicker();
}

/* 全选当前筛选/搜索结果(配合筛选可大批量选中) */
function pickerSelectAll() {
  const key = pickerKind + 'Words';
  const list = Array.isArray(state.settings[key]) ? state.settings[key] : (state.settings[key] = []);
  for (const w of pickerPool()) {
    if (!list.includes(w)) list.push(w);
  }
  saveState();
  renderWordPicker();
}

function pickerDone() {
  if (!pickerKind) return;
  pickerOpen = false;
  renderPracticeConfig(pickerKind);
  document.getElementById('topTitle').textContent = SCREEN_TITLES[PRACTICE_SCREENS[pickerKind]] || '';
}

/* 顶栏返回箭头统一入口:选词器打开时回配置页(上一级),其余回主菜单 */
function topBack() {
  if (pickerOpen) { pickerDone(); return; }
  goHome();
}

/* ============================================================
 * 听写（纯练习不改动学习进度，依赖系统 TTS）
 * 每词播两轮：每轮 = 英文单词读 2 次 + 汉语释义 1 次，
 * 两轮之间停顿可设（默认 1 秒）；支持判分/自查、循环、随机顺序、语速
 * ============================================================ */
/* 听写作答方式归一(judge判分/listen自查/auto自动轮播;旧 bool 存档已在 loadState 迁移) */
function normDictMode(v) {
  return ['judge', 'listen', 'auto'].includes(v) ? v : 'judge';
}

function renderDictConfig() {
  const el = document.getElementById('dictQuiz');
  if (!el) return;
  // Edge朗读/设备TTS 任一即可;微信/QQ 无 speechSynthesis 的环境靠 Edge 兜着,两者皆无才拦
  if (!canSpeakHere()) {
    el.innerHTML = `<div class="quiz-card session-done"><div class="icon">${icon('ear')}</div>
      <h2>当前浏览器不支持语音</h2><p>听力练习需要在线音源（需联网）或系统语音合成（speechSynthesis）支持。<br>当前环境两者皆无，请改用系统浏览器打开。</p></div>`;
    return;
  }
  const kind = normDictKind(state.settings.dictKind);   // write 听音写词 | pick 听音辨义
  const mode = normDictMode(state.settings.dictMode);
  const pool = practicePool('dict');
  const s = state.settings;
  const rate = s.dictRate || 0.9;
  const pause = s.dictPause == null ? 1 : s.dictPause;
  // 分组顺序:练习类型 → 该类型专属设置 → 共用范围/数量,底部固定开始栏(practiceFootHtml)
  el.innerHTML = `
    <div class="quiz-card" style="text-align:left;margin-bottom:100px">
      <span class="quiz-type">${icon('ear')} 听力练习</span>
      <p class="cfg-note"><b>听音写词</b>：播两轮（单词读 2 遍 + 汉译 1 遍）后输入提交；<b>听音辨义</b>：只听发音不给拼写，四选一中文释义。两类共用下面的范围/数量/自选词单，错词自动穿插重现；发音首次需联网，之后离线可用。</p>
      <div class="cfg-title">练习类型</div>
      <div class="cfg-chips">
        <button class="master-tab ${kind === 'write' ? 'active' : ''}" onclick="setPracticeCfg('dictKind','write')">${icon('pencil-line')} 听音写词</button>
        <button class="master-tab ${kind === 'pick' ? 'active' : ''}" onclick="setPracticeCfg('dictKind','pick')">${icon('volume-2')} 听音辨义</button>
      </div>
      ${kind === 'write' ? `
        <div class="cfg-title">作答方式</div>
        <div class="cfg-chips">
          <button class="master-tab ${mode === 'judge' ? 'active' : ''}" onclick="setPracticeCfg('dictMode','judge')">输入判分</button>
          <button class="master-tab ${mode === 'listen' ? 'active' : ''}" onclick="setPracticeCfg('dictMode','listen')">只听自查</button>
          <button class="master-tab ${mode === 'auto' ? 'active' : ''}" onclick="setPracticeCfg('dictMode','auto')">自动轮播</button>
        </div>
        <div class="cfg-title">两轮之间停顿</div>
        <div class="cfg-chips">${[0.5, 1, 2, 3].map(v =>
          `<button class="master-tab ${Math.abs(pause - v) < 0.01 ? 'active' : ''}" onclick="setPracticeCfg('dictPause',${v})">${v} 秒</button>`
        ).join('')}</div>
        <div class="cfg-title">播放顺序</div>
        <div class="cfg-chips">
          <button class="master-tab ${s.dictOrder === 'seq' ? 'active' : ''}" onclick="setPracticeCfg('dictOrder','seq')">${icon('list-ordered')} 顺序</button>
          <button class="master-tab ${s.dictOrder !== 'seq' ? 'active' : ''}" onclick="setPracticeCfg('dictOrder','random')">${icon('shuffle')} 随机</button>
        </div>
        <div class="cfg-title">循环播放</div>
        <div class="cfg-chips">
          <button class="master-tab ${s.dictLoop ? 'active' : ''}" onclick="setPracticeCfg('dictLoop',true)">开</button>
          <button class="master-tab ${!s.dictLoop ? 'active' : ''}" onclick="setPracticeCfg('dictLoop',false)">关</button>
        </div>
        <div class="cfg-title">语速 <span class="mt-cnt" id="rateLabel">${rate.toFixed(1)}x</span></div>
        <div class="rate-row">
          <input type="range" min="0.5" max="1.5" step="0.1" value="${rate}" oninput="onDictRate(this.value)">
        </div>` : `<p class="cfg-note">不显示单词拼写，堵住「靠字形认词」；四选一答完即判分，错词稍后穿插重现。</p>`}
      ${spellCfgHtml('dict')}
      ${pool.length ? '' : practiceEmptyHtml('dict')}
    </div>
    ${practiceFootHtml('dict')}
  `;
}

/* 听力练习类型归一:write 听音写词 / pick 听音辨义(旧档缺省 write) */
function normDictKind(v) {
  return v === 'pick' ? 'pick' : 'write';
}

/* 听力练习开始入口:按类型分发到听写会话/听音辨义会话 */
function startDictPractice() {
  if (normDictKind(state.settings.dictKind) === 'pick') startListen();
  else startDictation();
}

function onDictRate(v) {
  const r = Math.max(0.5, Math.min(1.5, parseFloat(v) || 0.9));
  state.settings.dictRate = r;
  saveState();
  const label = document.getElementById('rateLabel');
  if (label) label.textContent = r.toFixed(1) + 'x';
}

function startDictation() {
  const pool = practicePool('dict');
  if (!pool.length) return;
  const custom = normScope(state.settings.dictScope) === 'custom';
  const n = custom ? pool.length : Math.min(state.settings.dictCount || 10, pool.length);
  const picked = state.settings.dictOrder === 'seq' ? pool.slice(0, n) : shuffle(pool).slice(0, n);
  const mode = normDictMode(state.settings.dictMode);
  session = {
    mode: 'dict',
    phase: 'dictate',
    queue: picked,
    judge: mode === 'judge',
    auto: mode === 'auto',
    spellRetries: [],
    sinceSpellRetry: 0,
    idx: 0,
    correct: 0, wrong: 0,
    loopN: 1,
    gen: 0,          // 播报代际号：切词/重听/离开页面时 +1，旧播报链自动作废
    records: new Map(picked.map(w => [w, makeRecord()])),
  };
  renderDictWord();
}

/* 停止当前播报（作废播报链 + 掐掉在途 Edge 合成与在线音频 + 取消系统语音队列） */
function stopDictPlayback() {
  if (session && session.mode === 'dict') session.gen++;
  speakEpoch++;
  stopEdgeSynth();
  stopSpeakAudio();
  clearDictMediaSession();
  if (typeof window !== 'undefined' && window.speechSynthesis) {
    try { window.speechSynthesis.cancel(); } catch (e) { /* 忽略 */ }
  }
}

function dictStatus(t) {
  const st = document.getElementById('dictStatus');
  if (st) st.innerHTML = t;
}

/* 等待 utterance 播完（设备TTS兜底用）；部分环境 onend 不触发，用时长兜底 */
function speakAwait(text, lang, rate) {
  return new Promise(res => {
    try {
      const synth = window.speechSynthesis;
      if (synth.speaking || synth.pending) synth.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang;
      const v = resolveTTSVoice(/^zh/.test(lang) ? state.settings.ttsZhVoiceName : state.settings.ttsEngVoiceName, lang);
      if (v) { u.voice = v; u.lang = v.lang; }
      u.rate = rate;
      let done = false;
      const fin = () => { if (!done) { done = true; res(); } };
      u.onend = fin;
      u.onerror = fin;
      synth.speak(u);
      setTimeout(fin, Math.max(3000, text.length * 600));
    } catch (e) { res(); }
  });
}

/* 听写播报统一入口：Edge 朗读（若启用）→ 设备TTS，失败/关闭时降级并提示一次 */
let ttsFallbackWarned = false;
async function speakDictText(text, lang, rate) {
  const edgeRes = await edgePlayAwait(text, lang, rate);
  if (edgeRes === true || edgeRes === 'x') return;
  if (!ttsFallbackWarned && canUseEdgeVoice()) {
    ttsFallbackWarned = true;
    dictStatus(icon('volume-2') + ' Edge 朗读不可用，已切换设备语音');
  }
  await speakAwait(text, lang, rate);
}

function dictSleep(ms, sess, gen) {
  return new Promise(res => setTimeout(res, ms));
}

/* 锁屏媒体信息：<audio> 播放时系统把它当媒体流，锁屏界面显示当前单词 */
function updateDictMediaSession(word) {
  if (typeof navigator === 'undefined' || !navigator.mediaSession || typeof MediaMetadata === 'undefined') return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: word,
      artist: LIBS[libKey()].name + ' · 听写',
      album: '四级词汇通',
      artwork: [
        { src: './icons/icon-192.png', sizes: '192x192', type: 'image/png' },
        { src: './icons/icon-512.png', sizes: '512x512', type: 'image/png' },
      ],
    });
  } catch (e) { /* 忽略 */ }
}
function clearDictMediaSession() {
  if (typeof navigator === 'undefined' || !navigator.mediaSession) return;
  try { navigator.mediaSession.metadata = null; } catch (e) { /* 忽略 */ }
}

/* 预取下一个词的音频：Edge 音源预合成进两级缓存，切词/首听零等待 */
function prefetchDictAudio(word) {
  if (!canUseEdgeVoice()) return;
  try {
    const rate = state.settings.dictRate || 0.9;
    edgeSynthesize(word, edgeVoiceOf('en-US'), rate);
    edgeSynthesize(speakableDef(word) || word, edgeVoiceOf('zh-CN'), Math.min(1.2, rate + 0.1));
  } catch (e) { /* 忽略 */ }
}

/* 播一个词的两轮：每轮 = 单词 ×2 + 汉译 ×1，轮间停顿可设 */
async function playDictCycle(sess, gen) {
  const word = sess.word;
  const rate = state.settings.dictRate || 0.9;
  const pause = Math.max(0.5, (state.settings.dictPause == null ? 1 : state.settings.dictPause)) * 1000;
  dictStatus(icon('volume-2') + ' 正在播放…');
  for (let round = 1; round <= 2; round++) {
    await speakDictText(word, 'en-US', rate);
    if (session !== sess || sess.gen !== gen) return;
    await dictSleep(600, sess, gen);
    if (session !== sess || sess.gen !== gen) return;
    await speakDictText(word, 'en-US', rate);
    if (session !== sess || sess.gen !== gen) return;
    await dictSleep(500, sess, gen);
    if (session !== sess || sess.gen !== gen) return;
    await speakDictText(speakableDef(word) || word, 'zh-CN', Math.min(1.2, rate + 0.1));
    if (session !== sess || sess.gen !== gen) return;
    if (round === 1) {
      await dictSleep(pause, sess, gen);
      if (session !== sess || sess.gen !== gen) return;
    }
  }
  if (session !== sess || sess.gen !== gen) return;
  if (sess.judge) {
    dictStatus(icon('volume-2') + ' 播放完毕，输入后提交');
  } else if (sess.auto) {
    // 自动轮播:前两轮已播完单词×4+汉译×2,与其他模式节奏一致,不再额外强化,
    // 稍候自动切下一个词(单词全程显示在卡片上)
    const rec = sess.records.get(word) || makeRecord();
    rec.done = true;
    sess.records.set(word, rec);
    sess.correct++;
    dictStatus(icon('volume-2') + ' 即将下一个…');
    await dictSleep(Math.max(2000, pause * 2), sess, gen);
    if (session === sess && sess.gen === gen) dictNext();
  } else {
    dictStatus(icon('volume-2') + ' 播放完毕');
  }
}

function renderDictWord() {
  const el = document.getElementById('dictQuiz');
  const remaining = session.queue.filter(w => !(session.records.get(w) || makeRecord()).done);
  if (!remaining.length) {
    // 循环播放：整轮播完重置记录再来一轮；否则出完成页
    if (state.settings.dictLoop) {
      session.loopN++;
      session.records = new Map(session.queue.map(w => [w, makeRecord()]));
      session.idx = 0;
      session.spellRetries = [];
      session.sinceSpellRetry = 0;
      renderDictWord();
      return;
    }
    el.innerHTML = practiceDoneHtml('听写', '听写');
    return;
  }
  session.spellRetries = (session.spellRetries || []).filter(w => !(session.records.get(w) || makeRecord()).done);
  let word;
  if (session.judge && session.spellRetries.length && (session.sinceSpellRetry || 0) >= RETRY_INTERVAL) {
    word = session.spellRetries[0];
    session.sinceSpellRetry = 0;
    rotateSpellRetries();
  } else {
    const fresh = remaining.filter(w => !session.spellRetries.includes(w));
    const pool2 = fresh.length ? fresh : remaining;
    word = pool2[session.idx % pool2.length];
    session.sinceSpellRetry = (session.sinceSpellRetry || 0) + 1;
  }
  session.word = word;
  session.answered = false;
  prefetchUpcomingAudio();
  prefetchDictAudio(word);
  const loopNote = session.loopN > 1 ? `<div class="retry-note">循环第 ${session.loopN} 轮</div>` : '';
  const modeLabel = session.judge ? '判分' : (session.auto ? '自动轮播' : '只听自查');
  // 只听自查/自动轮播:单词和释义全程显示(边听边看)
  const showWord = session.judge ? '' : `
      <div class="quiz-prompt">${escapeHtml(word)}</div>
      <div class="dict-def-line">${escapeHtml(WORD_MAP.get(word) || '')}</div>`;
  const inputHtml = session.judge ? `
      <div class="spell-input-wrap">
        <input type="text" id="spellInput" class="spell-input" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="听音拼词">
        <button class="spell-check" onclick="dictCheck()">${icon('check')} 提交</button>
      </div>` : (session.auto ? `
      <div class="retry-note">自动轮播中 · 播完自动切下一个词</div>` : `
      <button class="next-btn" style="max-width:320px;margin:14px auto 0" onclick="dictListenNext()">下一个 →</button>`);
  el.innerHTML = `
    <div class="quiz-card">
      <span class="quiz-type">${icon('ear')} 听写 · ${modeLabel}</span>
      ${showWord}
      <div class="dict-status" id="dictStatus"><span data-icon="volume-2"></span> 准备播放…</div>
      <div class="show-ans-wrap"><button class="show-ans-btn" onclick="dictReplay()">${icon('volume-2')} 重听本词</button></div>
      ${inputHtml}
      <div class="progress-line">剩余 ${remaining.length} 词　·　✓ ${session.correct} ✗ ${session.wrong}
      　<button class="toolbar-btn" onclick="finishDictation()">结束</button></div>
      ${loopNote}
      <div id="spellFeedback"></div>
    </div>
  `;
  const sess = session;
  const gen = ++session.gen;
  updateDictMediaSession(word);
  playDictCycle(sess, gen);
  if (session.judge) {
    setTimeout(() => {
      const inp = document.getElementById('spellInput');
      if (inp) {
        inp.focus();
        inp.addEventListener('keydown', e => {
          if (e.key !== 'Enter') return;
          e.stopPropagation();
          if (session.answered) dictNext(); else dictCheck();
        });
      }
    }, 120);
  }
}

function dictReplay() {
  if (!session || session.mode !== 'dict' || session.answered) return;
  const sess = session;
  playDictCycle(sess, ++sess.gen);
}

/* 听写判分提交（听写纯练习：不改 stage/due，错词只在本会话内重现） */
function dictCheck() {
  if (!session || session.mode !== 'dict' || session.answered) return;
  session.answered = true;
  stopDictPlayback();
  const word = session.word;
  const val = ((document.getElementById('spellInput') && document.getElementById('spellInput').value) || '').trim().toLowerCase();
  const isCorrect = val === word.toLowerCase();
  const rec = session.records.get(word) || makeRecord();
  const fbEl = document.getElementById('spellFeedback');
  const card = fbEl.closest('.quiz-card');
  if (card) card.classList.add('with-ans');
  const inBook = curWords()[word] && curWords()[word].inBook;
  if (isCorrect) {
    rec.done = true;
    session.records.set(word, rec);
    session.correct++;
    session.spellRetries = (session.spellRetries || []).filter(w => w !== word);
    if (state.settings.autoSpeak) speakWord(word);
    fbEl.innerHTML = `
      <div class="feedback good">
        <div class="fb-title">${icon('circle-check')} 拼写正确！</div>
        <div class="ans-word">${escapeHtml(word)}</div>
        <div class="ans-def">${escapeHtml(WORD_MAP.get(word) || '')}</div>
      </div>
      <button class="next-btn" onclick="dictNext()">下一个 →</button>
    `;
  } else {
    rec.errors++;
    session.wrong++;
    session.records.set(word, rec);
    if (!session.spellRetries.includes(word)) session.spellRetries.push(word);
    session.sinceSpellRetry = 0;
    if (state.settings.autoSpeak) speakWord(word);   // 判分拼错时补听一遍正确发音
    fbEl.innerHTML = `
      <div class="feedback bad">
        <div class="fb-title">${icon('circle-x')} 拼错了，过几个词再考你</div>
        <div class="wrong-pair">
          <span class="wp-ans">${escapeHtml(word)}</span>
          <span class="wp-def">${escapeHtml(WORD_MAP.get(word) || '')}</span>
        </div>
        ${memoOf(word) ? `<div class="wrong-memo">${icon('lightbulb')} ${escapeHtml(memoOf(word))}</div>` : ''}
      </div>
      <div class="wrong-actions">
        <button class="book-toggle ${inBook ? 'in-book' : ''}" id="wrongBookBtn" onclick="toggleWrongBook('${escapeAttr(word)}')">
          ${inBook ? icon('bookmark-check') + ' 已在生词本' : icon('bookmark-plus') + ' 加入生词本'}
        </button>
        <button class="next-btn" onclick="dictNext()">下一个 →</button>
      </div>
    `;
  }
}

/* 只听自查:手动切下一个词(单词全程显示,无判分) */
function dictListenNext() {
  if (!session || session.mode !== 'dict') return;
  stopDictPlayback();
  session.idx++;
  renderDictWord();
}

function dictNext() {
  session.answered = false;
  session.idx++;
  renderDictWord();
}

/* 中途结束听写：出完成页（循环模式下退出用） */
function finishDictation() {
  stopDictPlayback();
  const el = document.getElementById('dictQuiz');
  el.innerHTML = practiceDoneHtml('听写', '听写');
}

/* ============================================================
 * 听音辨义（听力练习的类型之一，dictKind='pick'）
 * 只听发音四选一中文释义，纯练习不改动学习进度；与听写共用 screen-dictate
 * 出题复用 makeQuestion/pickDistractors；取词复用听写的 dictScope/Count/Words；
 * 错词穿插/答对即过规则与自由拼写一致；题干是音频，出词自动播报 + 可重听
 * ============================================================ */
function startListen() {
  const pool = practicePool('dict');
  if (!pool.length) return;
  const custom = normScope(state.settings.dictScope) === 'custom';
  const n = custom ? pool.length : Math.min(state.settings.dictCount || 10, pool.length);
  const picked = shuffle(pool).slice(0, n);   // 听音为主，顺序随机
  session = {
    mode: 'listen',
    phase: 'clist',           // 避开全局快捷键对识别阶段的接管
    queue: picked,
    spellRetries: [],
    sinceSpellRetry: 0,
    idx: 0,
    correct: 0, wrong: 0,
    records: new Map(picked.map(w => [w, makeRecord()])),
  };
  renderListenWord();
}

function renderListenWord() {
  const el = document.getElementById('dictQuiz');
  const remaining = session.queue.filter(w => !(session.records.get(w) || makeRecord()).done);
  if (!remaining.length) {
    el.innerHTML = practiceDoneHtml('听音辨义', '听音辨义');
    return;
  }
  // 错词穿插：每答 RETRY_INTERVAL 个词重现 1 个错词（与自由拼写一致）
  session.spellRetries = (session.spellRetries || []).filter(w => !(session.records.get(w) || makeRecord()).done);
  const retries = session.spellRetries;
  let word;
  if (retries.length && (session.sinceSpellRetry || 0) >= RETRY_INTERVAL) {
    word = retries[0];
    session.sinceSpellRetry = 0;
    rotateSpellRetries();
  } else {
    const fresh = remaining.filter(w => !retries.includes(w));
    const pool2 = fresh.length ? fresh : remaining;
    word = pool2[session.idx % pool2.length];
    session.sinceSpellRetry = (session.sinceSpellRetry || 0) + 1;
  }
  session.word = word;
  session.answered = false;
  session.q = makeQuestion(word);
  prefetchUpcomingAudio();
  const rec = session.records.get(word) || makeRecord();
  const retryNote = rec.errors > 0 ? `<div class="retry-note">重记词 · 答对 1 次即完成</div>` : '';
  const optionsHtml = session.q.options.map((o, i) =>
    `<button class="opt" data-ans="${o.isAnswer}" onclick="listenAnswer(${i}, this)">${escapeHtml(o.text)}</button>`
  ).join('');
  el.innerHTML = `
    <div class="quiz-card">
      <span class="quiz-type">${icon('volume-2')} 听音辨义</span>
      <div class="listen-prompt">
        <button class="speak-btn" title="重听" onclick="speakWord('${escapeAttr(word)}')">${icon('volume-2')}</button>
        <span class="listen-tip">听发音，选释义</span>
      </div>
      <div class="progress-line">剩余 ${remaining.length} 词　·　✓ ${session.correct} ✗ ${session.wrong}</div>
      <div class="options">${optionsHtml}</div>
      ${retryNote}
      <div id="listenFeedback"></div>
    </div>
  `;
  if (state.settings.autoSpeak) speakWord(word);
}

function listenAnswer(idx, btnEl) {
  if (session.answered) return;
  session.answered = true;
  const word = session.word;
  const isCorrect = session.q.options[idx].isAnswer;
  const rec = session.records.get(word) || makeRecord();
  const fbEl = document.getElementById('listenFeedback');
  const card = fbEl.closest('.quiz-card');
  if (card) card.classList.add('with-ans');
  document.querySelectorAll('#dictQuiz .opt').forEach(b => {
    if (b.dataset.ans === 'true') b.classList.add('correct');
  });
  if (!isCorrect && btnEl) btnEl.classList.add('wrong');
  const def = WORD_MAP.get(word) || '';
  if (isCorrect) {
    rec.done = true;
    session.records.set(word, rec);
    session.correct++;
    session.spellRetries = (session.spellRetries || []).filter(w => w !== word);
    if (state.settings.autoSpeak) speakWord(word);
    fbEl.innerHTML = `
      <div class="feedback good">
        <div class="fb-title">${icon('circle-check')} 答对了！</div>
        <div class="ans-word">${escapeHtml(word)}</div>
        <div class="ans-def">${escapeHtml(def)}</div>
      </div>
      <button class="next-btn" onclick="listenNext()">下一个 →</button>
    `;
  } else {
    rec.errors++;
    session.wrong++;
    session.records.set(word, rec);
    if (!session.spellRetries) session.spellRetries = [];
    if (!session.spellRetries.includes(word)) session.spellRetries.push(word);
    session.sinceSpellRetry = 0;
    if (state.settings.autoSpeak) speakWord(word);   // 揭底时补听一遍单词，音形义对上
    const inBook = curWords()[word] && curWords()[word].inBook;
    fbEl.innerHTML = `
      <div class="feedback bad">
        <div class="fb-title">${icon('circle-x')} 答错了，过几个词再考你</div>
        <div class="wrong-pair">
          <span class="wp-ans">${escapeHtml(word)}</span>
          <span class="wp-def">${escapeHtml(def)}</span>
        </div>
        ${memoOf(word) ? `<div class="wrong-memo">${icon('lightbulb')} ${escapeHtml(memoOf(word))}</div>` : ''}
      </div>
      <div class="wrong-actions">
        <button class="book-toggle ${inBook ? 'in-book' : ''}" id="wrongBookBtn" onclick="toggleWrongBook('${escapeAttr(word)}')">
          ${inBook ? icon('bookmark-check') + ' 已在生词本' : icon('bookmark-plus') + ' 加入生词本'}
        </button>
        <button class="next-btn" onclick="listenNext()">下一个 →</button>
      </div>
    `;
  }
}

function listenNext() {
  session.answered = false;
  session.idx++;
  renderListenWord();
}

/* ============================================================
 * 生词本
 * ============================================================ */
function renderBook() {
  const el = document.getElementById('bookList');
  const book = bookWords();
  if (!book.length) {
    el.innerHTML = '<div class="empty-tip">生词本是空的<br><br>答错或没记住的单词会自动加入这里</div>';
    return;
  }
  el.innerHTML = book.map(w =>
    `<div class="list-card"><div class="list-item">
      <span class="list-word">${escapeHtml(w)}</span>
      <span class="list-def">${escapeHtml(WORD_MAP.get(w))}</span>
      <button class="list-speak" title="发音" onclick="speakWord('${escapeAttr(w)}')">${icon('volume-2')}</button>
      ${memoOf(w) ? `<button class="list-memo-btn" title="巧记" onclick="toggleMemoRow('${escapeAttr(w)}', this)">${icon('lightbulb')}</button>` : ''}
      <button class="list-del" title="移出生词本" onclick="removeFromBook('${escapeAttr(w)}')">${icon('x')}</button>
    </div></div>`
  ).join('');
}

function removeFromBook(word) {
  toggleBook(word);
  renderBook();
  refreshHome();
}

/* ============================================================
 * 掌握情况
 * ============================================================ */
const MASTER_TABS = [
  { cls: 'learning', label: '学习中' },
  { cls: 'due', label: '待复习' },
  { cls: 'mastered', label: '已掌握' },
  { cls: 'leech', label: '顽固词' },
  { cls: 'unlearned', label: '未学习' },
];
let masterTab = 'learning';
let masterSearch = '';   // 分类内搜索关键词
let masterLimit = 100;   // 每次渲染条数上限（未学习分类可达 4543 条，全量渲染会卡）

function renderMaster() {
  const s = stats();
  document.getElementById('mUnlearned').textContent = s.unseen;
  document.getElementById('mLearning').textContent = s.learning;
  document.getElementById('mDue').textContent = s.due;
  document.getElementById('mMastered').textContent = s.mastered;

  // 顶部 tab
  document.getElementById('masterTabs').innerHTML = MASTER_TABS.map(t => {
    const n = classCount(t.cls);
    const act = masterTab === t.cls ? 'active' : '';
    return `<div class="master-tab ${act}" data-cls="${t.cls}" onclick="setMasterTab('${t.cls}')">
      ${t.label} <span class="mt-cnt">${n}</span>
    </div>`;
  }).join('');

  renderMasterList();
}

function setMasterTab(cls) {
  masterTab = cls;
  masterSearch = '';
  masterLimit = 100;
  renderMaster();
}

function onMasterSearch(v) {
  masterSearch = v.trim();
  masterLimit = 100;
  renderMasterList();
  // 重渲染会重建输入框，恢复焦点和光标位置
  const inp = document.getElementById('masterSearchInput');
  if (inp) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
}

function renderMasterList() {
  const el = document.getElementById('masterList');
  let words = wordsByClass(masterTab);
  const label = MASTER_TABS.find(t => t.cls === masterTab).label;
  const totalInClass = words.length;

  if (masterSearch) {
    const q = masterSearch.toLowerCase();
    words = words.filter(w =>
      w.toLowerCase().includes(q) || (WORD_MAP.get(w) || '').toLowerCase().includes(q)
    );
  }
  const shown = words.slice(0, masterLimit);

  if (!words.length) {
    el.innerHTML = `<div class="master-search-wrap"><input id="masterSearchInput" class="master-search" placeholder="搜索单词或释义…" value="${escapeHtml(masterSearch)}" oninput="onMasterSearch(this.value)"></div>
      <div class="empty-tip">${masterSearch ? `没有匹配「${escapeHtml(masterSearch)}」的单词` : `「${label}」分类暂无单词`}</div>`;
    return;
  }

  const rows = shown.map(w => {
    const st = wordStatus(w);
    const badgeCls = st.cls === 'mastered' ? 'ms-mastered' : (st.cls === 'due' ? 'ms-due' : 'ms-learning');
    const r = curWords()[w];
    // 顽固词标记：顽固词分类里显示答错次数，其他分类里追加「顽固」小徽章
    const leechBadge = masterTab === 'leech'
      ? `<span class="ms-badge ms-due">顽固 · 错${(r && r.lapses) || 0} 次</span>`
      : (r && r.leech ? '<span class="ms-badge ms-due">顽固</span>' : '');
    return `<div class="list-card"><div class="list-item">
      <span class="list-word">${escapeHtml(w)}</span>
      <span class="list-def">${escapeHtml(WORD_MAP.get(w))}</span>
      ${leechBadge}
      <span class="ms-badge ${badgeCls}">${st.label}</span>
      ${memoOf(w) ? `<button class="list-memo-btn" title="巧记" onclick="toggleMemoRow('${escapeAttr(w)}', this)">${icon('lightbulb')}</button>` : ''}
      <button class="list-del" title="重置此单词" onclick="confirmResetWord('${escapeAttr(w)}')">${icon('rotate-ccw')}</button>
    </div></div>`;
  }).join('');

  const moreBtn = words.length > shown.length
    ? `<div style="text-align:center;margin-top:10px"><button class="toolbar-btn" onclick="masterLimit += 200; renderMasterList()">显示更多（还有 ${words.length - shown.length} 个）</button></div>`
    : '';

  el.innerHTML = `
    <div class="master-search-wrap"><input id="masterSearchInput" class="master-search" placeholder="搜索单词或释义…" value="${escapeHtml(masterSearch)}" oninput="onMasterSearch(this.value)"></div>
    <div class="list-card master-toolbar">
      <span style="font-size:14px;color:var(--muted)">${label} · 共 ${totalInClass} 词${masterSearch ? ` · 匹配 ${words.length} 个` : ''}</span>
      <button class="toolbar-btn" onclick="confirmResetClass('${masterTab}')">重置本分类全部</button>
    </div>
    ${rows}
    ${moreBtn}
  `;
}

/* 重置单个单词 */
function confirmResetWord(word) {
  lastResetWord = word;
  document.getElementById('resetTitle').textContent = '重置这个单词？';
  document.getElementById('resetDesc').innerHTML = `「<b>${escapeHtml(word)}</b>」将回到未学习状态，复习进度清空。`;
  document.getElementById('resetModal').classList.add('show');
}

/* 重置整个分类 */
let lastResetClass = null;
let lastResetWord = null;
function confirmResetClass(cls) {
  lastResetClass = cls;
  const n = classCount(cls);
  const label = MASTER_TABS.find(t => t.cls === cls).label;
  document.getElementById('resetClassTitle').textContent = `重置「${label}」全部单词？`;
  document.getElementById('resetClassDesc').textContent = `将把 ${n} 个「${label}」单词全部重置为未学习状态，此操作不可恢复。`;
  document.getElementById('resetClassModal').classList.add('show');
}
function closeResetClass() { document.getElementById('resetClassModal').classList.remove('show'); }
function doResetClass() {
  if (lastResetClass) resetWordsByClass(lastResetClass);
  lastResetClass = null;
  closeResetClass();
  renderMaster();
  refreshHome();
}

/* ============================================================
 * 学习记录
 * ============================================================ */
let historyDay = null;   // 当前查看的日期 key
let historyFilter = 'all';   // 记录类型筛选:all/learned/reviewed/wrongs(切日期保留,方便逐天看同类)

function renderHistory() {
  // 默认选今天
  if (!historyDay) historyDay = dateKey();
  const days = Object.keys(state.history || {}).sort().reverse().slice(0, 30);   // 只显示最近 30 天，避免 tab 无限增长
  // 若当前查看的日期被截掉，回退到最近一天
  if (historyDay && !days.includes(historyDay)) historyDay = days[0] || dateKey();
  // 日期 tab:横向滑动条,短中文标签(今天/昨天/9月28日),选中项自动滚到可视区中间
  const fmtDay = (dk) => {
    if (dk === dateKey()) return '今天';
    if (dk === dateKey(Date.now() - DAY_MS)) return '昨天';
    const p = dk.split('-');
    return p.length === 3 ? `${+p[1]}月${+p[2]}日` : dk;
  };
  const tabsHtml = (days.length ? days : [dateKey()]).map(d => {
    const rec = (state.history && state.history[d]) || { learned: [], reviewed: [], wrongs: [] };
    const act = d === historyDay ? 'active' : '';
    const n = rec.learned.length + rec.reviewed.length;
    return `<button class="master-tab ${act}" onclick="setHistoryDay('${d}')">${fmtDay(d)}<span class="mt-cnt">${n}</span></button>`;
  }).join('');
  document.getElementById('historyDates').innerHTML = days.length
    ? `<div class="hist-dates">${tabsHtml}</div>`
    : '<p style="font-size:14px;color:var(--ink-soft)">还没有学习记录，开始学习吧</p>';
  const strip = document.querySelector('.hist-dates');
  if (strip && strip.querySelector) {
    const act = strip.querySelector('.master-tab.active');
    if (act && act.scrollIntoView) {
      try { act.scrollIntoView({ inline: 'center', block: 'nearest' }); } catch (e) { /* 旧浏览器忽略 */ }
    }
  }

  const rec = (state.history && state.history[historyDay]) || { learned: [], reviewed: [], wrongs: [] };
  document.getElementById('hLearned').textContent = rec.learned.length;
  document.getElementById('hReviewed').textContent = rec.reviewed.length;
  document.getElementById('hWrongs').textContent = rec.wrongs.length;
  renderHeatmap();
  renderHistoryDetail(rec);
}

/* ---------------- 学习热力图(GitHub 贡献图风格) + 连续学习 streak ----------------
 * 数据直接来自 state.history(永久保留)，纯渲染零状态。
 * 格子强度 = 当天新学+复习数(答错不计入颜色，避免"错得多颜色深"的负反馈误导)。
 * 点格子跳到学习记录对应日期(复用 setHistoryDay)。 */
const HEATMAP_WEEKS = 26;   // 近半年
function renderHeatmap() {
  const box = document.getElementById('heatmapBox');
  if (!box) return;
  const h = state.history || {};
  const actOf = dk => {
    const r = h[dk];
    if (!r) return 0;
    return (r.learned ? r.learned.length : 0) + (r.reviewed ? r.reviewed.length : 0);
  };
  const levelOf = n => n <= 0 ? 0 : (n < 10 ? 1 : (n < 30 ? 2 : (n < 60 ? 3 : 4)));
  // 起点 = 含「今天-(周数-1)*7 天」那一周的周日，最后一列是本周
  const DAY = 24 * 60 * 60 * 1000;
  const today0 = new Date(new Date().setHours(0, 0, 0, 0));
  const start = new Date(today0.getTime() - (HEATMAP_WEEKS - 1) * 7 * DAY);
  start.setDate(start.getDate() - start.getDay());   // 回到当周周日
  const CELL = 12, GAP = 3;
  let rects = '';
  for (let col = 0; col < HEATMAP_WEEKS; col++) {
    for (let row = 0; row < 7; row++) {
      const d = new Date(start.getTime() + (col * 7 + row) * DAY);
      if (d > today0) continue;   // 未来的日子不画
      const dk = dateKey(d.getTime());
      const n = actOf(dk);
      const x = col * (CELL + GAP), y = row * (CELL + GAP);
      rects += `<rect class="hm-cell hm-${levelOf(n)}" x="${x}" y="${y}" width="${CELL}" height="${CELL}" rx="3" data-dk="${dk}"`
        + `><title>${dk} · 新学+复习 ${n} 词${n ? '，点看记录' : ''}</title></rect>`;
    }
  }
  const w = HEATMAP_WEEKS * (CELL + GAP) - GAP, ht = 7 * (CELL + GAP) - GAP;
  box.innerHTML = `<div class="hm-scroll"><svg class="hm-svg" width="${w}" height="${ht}" viewBox="0 0 ${w} ${ht}" onclick="heatmapClick(event)">${rects}</svg></div>`;
  document.getElementById('streakLine').textContent = `连续学习 ${streakInfo()} 天`;
}

/* 热力图点击 → 跳到该天记录(event.target 为 rect) */
function heatmapClick(e) {
  const dk = e.target && e.target.dataset && e.target.dataset.dk;
  if (dk) setHistoryDay(dk);
}

function setHistoryDay(day) {
  historyDay = day;
  renderHistory();
}

const HISTORY_FILTERS = [
  { key: 'all', label: '全部' },
  { key: 'learned', label: '新学' },
  { key: 'reviewed', label: '复习' },
  { key: 'wrongs', label: '答错' },
];

function setHistoryFilter(f) {
  historyFilter = f;
  renderHistory();
}

function renderHistoryDetail(rec) {
  const el = document.getElementById('historyDetail');
  const dayLabel = historyDay === dateKey() ? '今天' : historyDay;
  const total = rec.learned.length + rec.reviewed.length + rec.wrongs.length;
  // 类型筛选 chips:新学/复习/答错分开看
  const chips = `<div class="cfg-chips" style="margin:14px 0 2px">${HISTORY_FILTERS.map(f =>
    `<button class="master-tab ${historyFilter === f.key ? 'active' : ''}" onclick="setHistoryFilter('${f.key}')">${f.label} <span class="mt-cnt">${f.key === 'all' ? total : rec[f.key].length}</span></button>`
  ).join('')}</div>`;
  const section = (title, list, cls) => {
    if (!list.length) return '';
    const rows = list.map(e => {
      // 条目兼容:[词库key, 单词] 新格式 / 旧版纯字符串(按词库包含关系归属)
      const norm = normHistEntry(e);
      const w = norm ? norm[1] : String(e);
      const lib = norm ? norm[0] : null;
      const libTag = lib ? `<span class="dict-lib">${escapeHtml(LIBS[lib].name.replace('词汇', ''))}</span>` : '';
      const def = lib ? defInLib(lib, w) : (WORD_MAP.get(w) || '');
      return `<div class="list-card"><div class="list-item">
        <span class="list-word">${escapeHtml(w)}</span>
        ${libTag}
        <span class="list-def">${escapeHtml(def)}</span>
        <button class="list-speak" title="发音" onclick="speakWord('${escapeAttr(w)}')">${icon('volume-2')}</button>
        <span class="ms-badge ${cls}">${title}</span>
      </div></div>`;
    }).join('');
    return `<h3 style="font-family:var(--serif);font-size:15px;color:var(--ink-blue);margin:16px 0 8px">${title}（${list.length}）</h3>${rows}`;
  };
  const picked = HISTORY_FILTERS.find(f => f.key === historyFilter) || HISTORY_FILTERS[0];
  const body = picked.key === 'all'
    ? section('新学', rec.learned, 'ms-learning')
      + section('复习', rec.reviewed, 'ms-mastered')
      + section('答错', rec.wrongs, 'ms-due')
    : section(picked.label, rec[picked.key], picked.key === 'learned' ? 'ms-learning' : (picked.key === 'reviewed' ? 'ms-mastered' : 'ms-due'));
  const emptyTip = total === 0
    ? `<div class="empty-tip">${dayLabel}没有学习活动</div>`
    : (!body ? `<div class="empty-tip">${dayLabel}没有「${picked.label}」记录</div>` : '');
  el.innerHTML = chips + body + emptyTip;
}

/* ---------------- 图标 ----------------
 * icons.js 的 ICONS(Lucide SVG,stroke=currentColor 随 CSS 变色)
 * icon(name) 返回加 class="ic" 的 svg 字符串;静态 HTML 用 data-icon + renderIcons() 填充
 */
function icon(name) {
  const svg = (typeof ICONS !== 'undefined' && ICONS[name]) || '';
  return svg ? svg.replace('<svg ', '<svg class="ic" ') : '';
}

function renderIcons() {
  document.querySelectorAll('[data-icon]').forEach(el => { el.innerHTML = icon(el.dataset.icon); });
}

/* ---------------- 工具 ---------------- */
function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function escapeAttr(s) {
  return String(s).replace(/['\\]/g, c => '\\' + c);
}

/* ---------------- 桌面端键盘快捷键 ----------------
 * 识别阶段：数字键 1-4 选选项；出反馈后 Enter 进下一个
 * 拼写阶段：出反馈后 Enter 进下一个（输入框内的 Enter 由输入框自身处理）
 */
document.addEventListener('keydown', e => {
  if (!session) return;
  if (document.querySelector('.modal-mask.show')) return;   // 弹窗打开时不响应
  const tag = (e.target && e.target.tagName) || '';
  const inInput = tag === 'INPUT' || tag === 'TEXTAREA';

  if (session.phase === 'recognize') {
    if (!session.answered && !inInput) {
      const n = parseInt(e.key, 10);
      if (n >= 1 && n <= 4) {
        const opts = document.querySelectorAll('#screen-study .opt, #screen-review .opt');
        if (opts[n - 1]) opts[n - 1].click();
      }
    } else if (session.answered && e.key === 'Enter' && !inInput) {
      advanceAfterWrong();
    }
  } else if (session.phase === 'spell') {
    if (session.answered && e.key === 'Enter' && !inInput) {
      const good = document.querySelector('#spellFeedback .feedback.good');
      if (good) nextSpell(); else advanceSpellAfterWrong();
    }
  } else if (session.phase === 'clist') {
    // 听音辨义:数字键 1-4 选选项;出反馈后 Enter 进下一个
    if (!session.answered && !inInput) {
      const n = parseInt(e.key, 10);
      if (n >= 1 && n <= 4) {
        const opts = document.querySelectorAll('#screen-dictate .opt');
        if (opts[n - 1]) opts[n - 1].click();
      }
    } else if (session.answered && e.key === 'Enter' && !inInput) {
      listenNext();
    }
  }
});

/* ---------------- 快速复习 / 进度重建(清档补救工具升级) ----------------
 * 两个入口共用一套配置页与快扫会话:
 *   主页「快速复习」= 纯练习模式,认识/不认识只计次,不写任何用户数据;
 *   设置「进度快速重建」= 重建模式,写入学习进度(认识=stage2/2天后,不认识=stage1/明天来)。
 * 配置页可选题库(全局切换)+范围(含自选词单,复用拼写/听写的选词器);即标即存随时续扫。 */
let quickMode = 'practice';   // 'practice' 纯练习 | 'rebuild' 写入进度
let quickRebuild = null;      // 会话 {list, i, known, unknown, write}

function quickRemaining() {
  return unseenWords().length;
}

function openQuickPractice() { quickMode = 'practice'; go('screen-quick'); }
function openQuickRebuild() { quickMode = 'rebuild'; go('screen-quick'); }
function setQuickMode(v) {
  if (v !== 'practice' && v !== 'rebuild') return;
  quickMode = v;
  renderQuickConfig();
}

function renderQuickConfig() {
  const el = document.getElementById('quickQuiz');
  if (!el) return;
  const mode = quickMode;
  const pool = practicePool('quick');
  // 重建模式只扫还没有学习记录的词(已排期的不重复打扰)
  const sweep = mode === 'rebuild' ? pool.filter(w => !curWords()[w]) : pool;
  const libChips = Object.keys(LIBS).map(k =>
    `<button class="master-tab ${k === libKey() ? 'active' : ''}" onclick="setLibrary('${k}');renderQuickConfig()">${escapeHtml(LIBS[k].name)}</button>`).join('');
  el.innerHTML = `
    <div class="quiz-card" style="text-align:left;margin-bottom:100px">
      <span class="quiz-type">${icon('sparkles')} 快速复习</span>
      <p class="cfg-note">一屏一词,认识/不认识点一下。${mode === 'rebuild' ? '<b>重建模式会写入学习进度</b>:认识按 2 天后排期,不认识明天再来;只扫还没有记录的词。' : '<b>纯练习不改任何学习数据</b>,放心扫。'}</p>
      <div class="cfg-title">模式</div>
      <div class="cfg-chips">
        <button class="master-tab ${mode === 'practice' ? 'active' : ''}" onclick="setQuickMode('practice')">复习练习(不改数据)</button>
        <button class="master-tab ${mode === 'rebuild' ? 'active' : ''}" onclick="setQuickMode('rebuild')">进度重建(写入)</button>
      </div>
      <div class="cfg-title">题库</div>
      <div class="cfg-chips" style="margin-bottom:2px">${libChips}</div>
      ${scopeCfgHtml('quick')}
      ${sweep.length ? '' : practiceEmptyHtml('quick')}
    </div>
    <div class="practice-foot">
      <span class="picker-count">共 <b>${sweep.length}</b> 词</span>
      <button class="next-btn" id="quickStartBtn" onclick="startQuickSweep()" ${sweep.length ? '' : 'disabled'}>开始${mode === 'rebuild' ? '重建' : '复习'}</button>
    </div>`;
}

function startQuickSweep() {
  let list = practicePool('quick');
  if (quickMode === 'rebuild') list = list.filter(w => !curWords()[w]);
  if (!list.length) return;
  quickRebuild = { list: shuffle(list), i: 0, known: 0, unknown: 0, write: quickMode === 'rebuild' };
  go('screen-study');
  renderQuickRebuild();
}

/* 快扫发音：卡片上的小喇叭（不依赖 session，与学词页 speakCurrent 分开） */
function speakQuickWord() {
  const q = quickRebuild;
  if (q && q.list[q.i]) speakWord(q.list[q.i]);
}

/* 快扫预取：把后面几个词的音频提前合成好（快扫没有 session，prefetchUpcomingAudio 不覆盖这里） */
function prefetchQuickAudio() {
  if (!canUseEdgeVoice() || !quickRebuild) return;
  const q = quickRebuild;
  for (const w of q.list.slice(q.i + 1, q.i + 1 + PREFETCH_AHEAD)) {
    edgePrefetch(w, edgeVoiceOf('en-US'), 0.9);
  }
}

function renderQuickRebuild() {
  const el = document.getElementById('studyQuiz');
  if (!el) return;
  const q = quickRebuild;
  if (!q) return;
  if (q.i >= q.list.length) {
    el.innerHTML = `
      <div class="quiz-card session-done">
        <div class="icon">${icon('circle-check')}</div>
        <h2>${q.write ? '这一轮扫完了' : '本轮结束'}</h2>
        <p>认识 ${q.known} 词 · 不认识 ${q.unknown} 词<br>${q.write
          ? '不认识的词明天会出现在复习里,反复过几轮就补回来了。'
          : '纯练习,学习数据没有任何变化。'}</p>
        <button class="next-btn" onclick="startQuickSweep()">再来一轮</button>
        <button class="btn-ghost" style="width:100%;margin-top:10px;padding:12px;border-radius:12px" onclick="quickExit()">完成,回主页</button>
      </div>`;
    return;
  }
  const w = q.list[q.i];
  const def = WORD_MAP.get(w) || '';
  const speakBtn = canSpeakHere() ? `<button class="speak-btn" title="发音" onclick="speakQuickWord()">${icon('volume-2')}</button>` : '';
  el.innerHTML = `
    <div class="quiz-card">
      <span class="quiz-type">${icon('sparkles')} ${q.write ? '进度重建' : '快速复习'} ${q.i + 1} / ${q.list.length}</span>
      <p class="quiz-prompt">${escapeHtml(w)}${speakBtn}</p>
      <p style="text-align:center;color:var(--muted);font-size:15px;margin:0 0 8px">${escapeHtml(def)}</p>
      <p style="text-align:center;color:var(--ink-soft);font-size:12px;margin:0 0 6px">${q.write
        ? '这个词你之前学过吗？认识=按 2 天后排期，不认识=明天再来'
        : '这个词认识吗？（纯练习，不影响进度）'}</p>
      <div class="wrong-actions">
        <button class="next-btn" style="background:var(--amber)" onclick="quickAnswer(false)">不认识</button>
        <button class="next-btn" style="background:var(--green)" onclick="quickAnswer(true)">认识</button>
      </div>
      <div class="wrong-actions" style="margin-top:0">
        <button class="btn-ghost" style="flex:1;padding:10px 0;border-radius:12px" onclick="quickSkip()">跳过</button>
        <button class="btn-ghost" style="flex:1;padding:10px 0;border-radius:12px" onclick="quickExit()">结束</button>
      </div>
    </div>`;
  prefetchQuickAudio();
  if (state.settings.autoSpeak) speakWord(w);
}

function quickAnswer(known) {
  const q = quickRebuild;
  if (!q) return;
  const w = q.list[q.i];
  if (q.write) quickMark(w, known);
  if (known) q.known++; else q.unknown++;
  q.i++;
  renderQuickRebuild();
}

function quickSkip() {
  const q = quickRebuild;
  if (!q) return;
  q.i++;
  renderQuickRebuild();
}

function quickExit() {
  quickRebuild = null;
  goHome();
}

/* ---------------- 初始化 ---------------- */
renderIcons();
refreshHome();
refreshSettings();

/* ---------------- 数据诊断面板(2026-10-02 清档事故排查工具) ----------------
 * 展示:SW 缓存版本 / 原始存档大小与解析状态 / 词记录数 / 历史天数 / 备份键。
 * 只读不改,用于远程判断"进度为空"是代码没更新还是存档真丢了 */
function renderDiag() {
  const el = document.getElementById('diagBody');
  if (!el) return;
  let raw = null;
  try { raw = localStorage.getItem(STATE_KEY); } catch (e) { /* 忽略 */ }
  const rawLen = raw ? raw.length : 0;
  let words = 0, days = 0, lib = '-', parseOk = !!raw;
  if (raw) {
    try {
      const s = JSON.parse(raw);
      lib = (s.settings && s.settings.lib) || '-';
      const lw = (s.libs && s.libs[lib] && s.libs[lib].words) || {};
      words = Object.keys(lw).length;
      days = Object.keys(s.history || {}).length;
    } catch (e) { parseOk = false; }
  }
  const hasBackup = !!localStorage.getItem(STATE_KEY + '_backup');
  const hasSnap = !!localStorage.getItem('cet4_session_snapshot_v1');
  const swc = (typeof navigator !== 'undefined' && navigator.serviceWorker) ? navigator.serviceWorker.controller : null;
  const swName = swc ? (swc.scriptURL.split('/').pop() || '?') : '未注册';
  el.innerHTML =
    'SW：<b>' + escapeHtml(swName) + '</b>　（这是手机当前实际运行的版本）<br>' +
    '存档：' + (raw ? rawLen + ' 字符 · 解析' + (parseOk ? '正常' : '<b style="color:var(--pen-red)">失败</b>') : '<b style="color:var(--pen-red)">不存在</b>') + '<br>' +
    '词记录（' + escapeHtml(lib) + '）：<b>' + words + '</b> 个　历史：<b>' + days + '</b> 天<br>' +
    '损坏备份键：' + (hasBackup ? '有' : '无') + '　会话快照：' + (hasSnap ? '有' : '无');
  if (window.caches && caches.keys) {
    caches.keys().then(ks => {
      const tag = document.getElementById('diagBody');
      if (!tag) return;
      const hit = ks.find(k => k.indexOf('cet4-vocab-') === 0);
      if (hit) tag.innerHTML = '缓存：<b>' + escapeHtml(hit.replace('cet4-vocab-', '')) + '</b><br>' + tag.innerHTML;
    }).catch(() => {});
  }
}

/* 强制更新:注销 SW+清代码缓存后重载。只碰程序缓存,localStorage 学习数据不受影响 */
function forceSwUpdate() {
  if (!confirm('将注销缓存并重新拉取最新版代码，学习数据不受影响。继续？')) return;
  const done = () => location.reload();
  const sw = (typeof navigator !== 'undefined') ? navigator.serviceWorker : null;
  if (sw) {
    sw.getRegistrations()
      .then(rs => Promise.all(rs.map(r => r.unregister())))
      .then(() => (window.caches && caches.keys ? caches.keys() : Promise.resolve([])))
      .then(ks => Promise.all(ks.map(k => caches.delete(k))))
      .then(done)
      .catch(done);
  } else {
    done();
  }
}

/* 强制更新:注销 SW+清代码缓存后重载。只碰程序缓存,localStorage 学习数据不受影响 */
function forceSwUpdate() {
  if (!confirm('将注销缓存并重新拉取最新版代码，学习数据不受影响。继续？')) return;
  const done = () => location.reload();
  if (navigator.serviceWorker) {
    navigator.serviceWorker.getRegistrations()
      .then(rs => Promise.all(rs.map(r => r.unregister())))
      .then(() => (window.caches && caches.keys ? caches.keys() : Promise.resolve([])))
      .then(ks => Promise.all(ks.map(k => caches.delete(k))))
      .then(done)
      .catch(done);
  } else {
    done();
  }
}
